package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.Role;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface RoleRepository extends JpaRepository<Role, Integer> {

	@Query("select ur from Role ur where ur.roleId=:roleId")
	Role findRoleByRoleId(@Param("roleId") Integer roleId);
	
	@Query("select ur from Role ur where ur.isActive=:isActive")
	List<Role> findAllRole(@Param("isActive") boolean isActive);

	@Query("select ur from Role ur where ur.roleName=:roleName")
	Role findRoleByRoleName(@Param("roleName") String roleName);

}
