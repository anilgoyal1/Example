package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.Branch;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BranchRepository extends JpaRepository<Branch, String> {

	// List<Branch>
	// findAllBranchesByLongitudeIsNotNullAndLatitudeIsNotNullAndBranchTypeIn(
	// Collection<String> branchType);

	@Query("select cn from Branch cn where cn.branchCode=:branchCode")
	Branch findByBranchCode(@Param("branchCode") String String);

	@Query("select cn from Branch cn where cn.branchId=:branchId")
	Branch findByBranchByBranchId(@Param("branchId") Long branchId);

	@Query("select cn from Branch cn where cn.isActive=:isActive")
	List<Branch> findAllBranch(@Param("isActive") boolean isActive);

}
