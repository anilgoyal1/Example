package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.State;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface StateRepository extends JpaRepository<State, Integer> {

	@Query("select cn from State cn where cn.isActive=:isActive")
	List<State> findAllState(@Param("isActive") boolean isActive);

	@Query("select cn from State cn where cn.stateCode=:stateCode")
	State findStateByStateCode(@Param("stateCode") String stateCode);

	@Query("select cn from State cn where cn.stateId=:stateId")
	State findStateByStateId(@Param("stateId") Integer stateId);

}