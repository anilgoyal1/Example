package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.DeviceMaster;
import net.atos.iot.entity.RuleConfig;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface RuleConfigRepository extends JpaRepository<RuleConfig, String> {

	@Query("select rc from RuleConfig rc ")
	List<RuleConfig> findAllActiveRule();

	@Query("select rc from RuleConfig rc where rc.ruleCode=:ruleCode")
	RuleConfig findRuleByRuleCode(@Param("ruleCode") String ruleCode);
	
	
	

}
