package net.atos.iot.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Table(uniqueConstraints = { @UniqueConstraint(columnNames = "simulationName") })
@Entity
public class EdgeGatewaySimulation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6141405888972115585L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "simulationName")
	private String simulationName;

	private Integer tenantId;

	private Integer minTemperature;

	private Integer maxTemperature;

	private Integer minHumidity;

	private Integer maxHumidity;

	@ElementCollection
	private List<String> deviceIds;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSimulationName() {
		return simulationName;
	}

	public void setSimulationName(String simulationName) {
		this.simulationName = simulationName;
	}

	public Integer getTenantId() {
		return tenantId;
	}

	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}

	public List<String> getDeviceIds() {
		return deviceIds;
	}

	public void setDeviceIds(List<String> deviceIds) {
		this.deviceIds = deviceIds;
	}

	public Integer getMinTemperature() {
		return minTemperature;
	}

	public void setMinTemperature(Integer minTemperature) {
		this.minTemperature = minTemperature;
	}

	public Integer getMaxTemperature() {
		return maxTemperature;
	}

	public void setMaxTemperature(Integer maxTemperature) {
		this.maxTemperature = maxTemperature;
	}

	public Integer getMinHumidity() {
		return minHumidity;
	}

	public void setMinHumidity(Integer minHumidity) {
		this.minHumidity = minHumidity;
	}

	public Integer getMaxHumidity() {
		return maxHumidity;
	}

	public void setMaxHumidity(Integer maxHumidity) {
		this.maxHumidity = maxHumidity;
	}
	
	
	

}
