package net.atos.iot.repository;

import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.entity.Ticket;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface TicketRepository extends JpaRepository<Ticket, Long> {

	@Query("select t from Ticket t where t.deviceId=:deviceId")
	List<Ticket> findByDeviceId(@Param("deviceId") String deviceId);

	@Query("select t from Ticket t where t.ticketStatus=:ticketStatus")
	List<Ticket> findTicketByStatus(@Param("ticketStatus") String ticketStatus);

	@Query("select t from Ticket t where t.ticketStatus=:ticketStatus and  t.deviceId=:deviceId")
	List<Ticket> findTicketByStatusAndDeviceId(
			@Param("ticketStatus") String ticketStatus,
			@Param("deviceId") String deviceId);

	@Query("select t from Ticket t where t.ticketStatus!=:ticketStatus and  t.deviceId=:deviceId and t.alertType=:alertType")
	List<Ticket> findNotClosedTicketByStatusAndDeviceId(
			@Param("ticketStatus") String ticketStatus,
			@Param("deviceId") String deviceId,
			@Param("alertType") String alertType);

	@Query("select t from Ticket t where t.ticketId=:ticketId ")
	Ticket findTicketByTicketId(@Param("ticketId") Long ticketId);

	@Query("select t from Ticket t where t.ticketStatus!=:ticketStatus ")
	List<Ticket> getActiveTickets(@Param("ticketStatus") String ticketStatus);

	@Query("select t from Ticket t where t.ticketStatus=:ticketStatus and t.deviceId in (:ids)")
	List<Ticket> findTicketByStatusAndDeviceIds(
			@Param("ticketStatus") String ticketStatus,
			@Param("ids") List<String> ids);

	@Query("select t from Ticket t where t.ticketStatus  NOT IN (:ticketStatus) and  t.deviceId=:deviceId and t.ticketType=:ticketType and t.alertType=:alertType")
	List<Ticket> findNotClosedTicketByTicketTypeAndTicketStatusAndDeviceId(
			@Param("ticketStatus")  List<String> ticketStatus,
			@Param("deviceId") String deviceId,
			@Param("alertType") String alertType,
			@Param("ticketType") String ticketType);

	@Query("select t from Ticket t where t.deviceId=:deviceId and t.ticketStatus NOT IN (:ticketStatus) and t.ticketId!=:ticketId")
	List<Ticket> getTicketsByNotInStatusAndDeviceIdAndTicketId(
			@Param("ticketStatus") List<String> ticketStatus,
			@Param("deviceId") String deviceId, @Param("ticketId") Long ticketId);

	@Query("select t from Ticket t where  t.deviceId in (:ids)")
	List<Ticket> findTicketByTenantId(@Param("ids") List<String> ids);

	@Query("select t from Ticket t where  t.ticketType=:ticketType and t.deviceId=:deviceId and  t.ticketStatus!=:ticketStatus ")
	List<Ticket> getOpenTicketByDeviceIdAndTicketType(
			@Param("deviceId") String deviceId,@Param("ticketType") String ticketType,@Param("ticketStatus") String ticketStatus);
	
	
	@Query("select t from Ticket t where t.ticketStatus NOT IN (:ticketStatus) and  t.deviceId=:deviceId  ")
	List<Ticket> getTicketsByNotInStatusAndByDeviceId(
			@Param("ticketStatus")  List<String> ticketStatus ,
			@Param("deviceId") String deviceId);
	
	
	@Modifying
	@Transactional
	@Query("delete from Ticket  where deviceId in (:deviceIds) ")
	void deleteTicketsByDeviceIds(
			@Param("deviceIds") List<String> deviceIds);
	
	@Query("select t from Ticket t where t.ticketStatus not in (:ticketStatus) ")
	List<Ticket> getTicketSWhereStatusNotIn(@Param("ticketStatus") List <String> ticketStatus);


}
