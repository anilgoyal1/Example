package net.atos.iot.repository;

import net.atos.iot.entity.TicketRootCauseMaster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface TicketRootCauseRepository extends
		JpaRepository<TicketRootCauseMaster, Integer> {

}
