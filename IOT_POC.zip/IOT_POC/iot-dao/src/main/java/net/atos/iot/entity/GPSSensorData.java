package net.atos.iot.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gps_sensorData")
public class GPSSensorData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8043292407801282994L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

	@Column(name = "device_id")
	private String deviceId;

	/**
	 * 
	 * { "DeviceId": "100", "Simulated": 1, "ReceivedTime":
	 * "2017-06-13T08:08:52.334Z", "Long": "0", "Lat": "0", "Speed": 30,
	 * "Heading": 34.68145000875885, "State": "normal", "Description":
	 * "Car id: BUS-1" }
	 */

	@Column(name = "Simulated")
	private String simulated;

	private Long tripId;

	@Column(name = "ReceivedTime")
	private Date receivedTime;

	@Column(name = "Longitude")
	private double longitude;

	@Column(name = "Latitude")
	private double latitude;

	@Column(name = "Speed")
	private double speed;

	@Column(name = "Heading")
	private double heading;

	@Column(name = "state")
	private String state;

	@Column(name = "description")
	private String description;

	@Column(name = "createdDate ")
	Date createdDate;

	@Column(name = "alertType")
	String alertType;

	private String driverName;

	private String licensePlate;

	private String fuelLevel;

	private String tripStatus;

	private Double engineLoad;

	private Double shortTermFuel;

	private Double longTermFuel;

	private Double engineRPM;

	private Double mAFAirFlow;

	private Double throttlePosition;

	private Double engineStartFrom;

	private Double distanceTraveledWithLightOn;

	private Double relThottlePos;

	private Double ambientAirTemp;

	private Double engineFuelRate;

	public Double getEngineFuelRate() {
		return engineFuelRate;
	}

	public void setEngineFuelRate(Double engineFuelRate) {
		this.engineFuelRate = engineFuelRate;
	}

	public Double getEngineLoad() {
		return engineLoad;
	}

	public void setEngineLoad(Double engineLoad) {
		this.engineLoad = engineLoad;
	}

	public Double getShortTermFuel() {
		return shortTermFuel;
	}

	public void setShortTermFuel(Double shortTermFuel) {
		this.shortTermFuel = shortTermFuel;
	}

	public Double getLongTermFuel() {
		return longTermFuel;
	}

	public void setLongTermFuel(Double longTermFuel) {
		this.longTermFuel = longTermFuel;
	}

	public Double getEngineRPM() {
		return engineRPM;
	}

	public void setEngineRPM(Double engineRPM) {
		this.engineRPM = engineRPM;
	}

	public Double getmAFAirFlow() {
		return mAFAirFlow;
	}

	public void setmAFAirFlow(Double mAFAirFlow) {
		this.mAFAirFlow = mAFAirFlow;
	}

	public Double getThrottlePosition() {
		return throttlePosition;
	}

	public void setThrottlePosition(Double throttlePosition) {
		this.throttlePosition = throttlePosition;
	}

	public Double getEngineStartFrom() {
		return engineStartFrom;
	}

	public void setEngineStartFrom(Double engineStartFrom) {
		this.engineStartFrom = engineStartFrom;
	}

	public Double getDistanceTraveledWithLightOn() {
		return distanceTraveledWithLightOn;
	}

	public void setDistanceTraveledWithLightOn(
			Double distanceTraveledWithLightOn) {
		this.distanceTraveledWithLightOn = distanceTraveledWithLightOn;
	}

	public Double getRelThottlePos() {
		return relThottlePos;
	}

	public void setRelThottlePos(Double relThottlePos) {
		this.relThottlePos = relThottlePos;
	}

	public Double getAmbientAirTemp() {
		return ambientAirTemp;
	}

	public void setAmbientAirTemp(Double ambientAirTemp) {
		this.ambientAirTemp = ambientAirTemp;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getLicensePlate() {
		return licensePlate;
	}

	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	public String getFuelLevel() {
		return fuelLevel;
	}

	public void setFuelLevel(String fuelLevel) {
		this.fuelLevel = fuelLevel;
	}

	public String getTripStatus() {
		return tripStatus;
	}

	public void setTripStatus(String tripStatus) {
		this.tripStatus = tripStatus;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getSimulated() {
		return simulated;
	}

	public void setSimulated(String simulated) {
		this.simulated = simulated;
	}

	public Date getReceivedTime() {
		return receivedTime;
	}

	public void setReceivedTime(Date receivedTime) {
		this.receivedTime = receivedTime;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public double getHeading() {
		return heading;
	}

	public void setHeading(double heading) {
		this.heading = heading;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public Long getTripId() {
		return tripId;
	}

	public void setTripId(Long tripId) {
		this.tripId = tripId;
	}

	

}
