package net.atos.iot.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent class for the rule_config database table.
 * 
 */
@Entity
@Table(name = "rule_config")
public class RuleConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "rule_code")
	private String ruleCode;

	@ManyToMany(mappedBy = "ruleConfigs")
	private Set<DeviceMaster> devices = new HashSet<DeviceMaster>(0);

	public Set<DeviceMaster> getDevices() {
		return devices;
	}

	public void setDevices(Set<DeviceMaster> devices) {
		this.devices = devices;
	}

	@Column(name = "param_max_val")
	private String paramMaxVal;

	@Column(name = "param_min_val")
	private String paramMinVal;

	@Column(name = "param_name")
	private String paramName;

	private boolean isActive;

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean active) {
		this.isActive = active;
	}

	public String getRuleCode() {
		return ruleCode;
	}

	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}

	public String getParamMaxVal() {
		return paramMaxVal;
	}

	public void setParamMaxVal(String paramMaxVal) {
		this.paramMaxVal = paramMaxVal;
	}

	public String getParamMinVal() {
		return paramMinVal;
	}

	public void setParamMinVal(String paramMinVal) {
		this.paramMinVal = paramMinVal;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

}