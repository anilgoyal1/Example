package net.atos.iot.repository;

import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.entity.DeviceMaster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DeviceMasterRepository extends
		JpaRepository<DeviceMaster, String> {

	List<DeviceMaster> findAllByApplianceId(String applianceId);

	@Query("select dm from DeviceMaster dm where dm.deviceId=:deviceId")
	DeviceMaster getDeviceByDeviceId(@Param("deviceId") String deviceId);

	@Query("select dm from DeviceMaster dm")
	List<DeviceMaster> findAllByDevices();

	// List<DeviceMst> findAllByDeviceId(String deviceId);

	
	
	
	
	@Query("select dm from DeviceMaster dm inner join dm.tenant t where t.tenantId=:tenantId")
	public List<DeviceMaster> findDeviceByTenantId(
			@Param("tenantId") Integer tenantId);

	@Query("select dm from DeviceMaster dm inner join dm.tenant t inner join dm.deviceStatusMaster dsm where t.tenantId=:tenantId and dsm.statusName in (:status) ")
	public List<DeviceMaster> findDeviceByTenantIdAndStatus(
			@Param("tenantId") Integer tenantId,
			@Param("status") List<String> status);

	@Query("select dm.deviceId from DeviceMaster dm inner join dm.tenant t where t.tenantId=:tenantId")
	public List<String> findDeviceIdsTenantId(
			@Param("tenantId") Integer tenantId);
	
	@Query("select dm.deviceId from DeviceMaster dm inner join dm.tenant t where t.tenantId=:tenantId and dm.isSimulatedDevice=true")
	public List<String> findAllSimulatedDeviceByTenantId(
			@Param("tenantId") Integer tenantId);

	@Query("select dm from DeviceMaster dm  inner join dm.deviceStatusMaster dsm where dsm.statusName not in (:status) ")
	public List<DeviceMaster> findAllDeviceWhereStatusNotIn(
			@Param("status") List<String> status);

	@Query("delete from DeviceMaster where deviceId in (:deviceIds) ")
	@Transactional
	@Modifying
	void deleteDeviceMasterByDeviceIds(
			@Param("deviceIds") List<String> deviceIds);

}
