package net.atos.iot.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "device_mst")
public class DeviceMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "device_id")
	private String deviceId;

	@ManyToOne
	@JoinColumn(name = "tenant_id", referencedColumnName = "tenant_id")
	private Tenant tenant;

	@Column(name = "tenant_name")
	private String tenantName;

	@Column(name = "service_name")
	private String serviceName;

	@Column(name = "appliance_id")
	private String applianceId;

	@Column(name = "serial_number")
	private String serialNumber;

	@Column(name = "device_type")
	private String deviceType;

	@Column(name = "device_base_loc")
	private String deviceBaseLoc;

	@Column(name = "device_desc")
	private String deviceDesc;

	@Column(name = "isactive")
	private boolean isActive;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Date createdDate;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_date")
	private Date modifiedDate;

	@Column(name = "server_url")
	private String serverUrl;

	@Column(name = "server_port")
	private Integer serverPort;

	@Column(name = "communication_details")
	private String communicationDetails;

	@Column(name = "push_frequency")
	private long pushFrequency;

	@Column(name = "pull_frequency")
	private long pullFrequency;

	@Column(name = "sensor_type")
	private String sensorType;

	@OneToOne
	private DeviceStatusMaster deviceStatusMaster;

	@Column(name = "deviceLocationLongitude")
	private Double deviceLocationLongitude;

	@Column(name = "deviceLocationLatitude")
	private Double deviceLocationLatitude;

	@Column(name = "isSimulatedDevice")
	private boolean isSimulatedDevice;

	public boolean isSimulatedDevice() {
		return isSimulatedDevice;
	}

	public void setSimulatedDevice(boolean isSimulatedDevice) {
		this.isSimulatedDevice = isSimulatedDevice;
	}

	@ManyToMany(cascade=CascadeType.REMOVE)
	private Set<RuleConfig> ruleConfigs = new HashSet<RuleConfig>(0);

	public Set<RuleConfig> getRuleConfigs() {
		return ruleConfigs;
	}

	public void setRuleConfigs(Set<RuleConfig> ruleConfigs) {
		this.ruleConfigs = ruleConfigs;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public Tenant getTenant() {
		return tenant;
	}

	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getApplianceId() {
		return applianceId;
	}

	public void setApplianceId(String applianceId) {
		this.applianceId = applianceId;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceBaseLoc() {
		return deviceBaseLoc;
	}

	public void setDeviceBaseLoc(String deviceBaseLoc) {
		this.deviceBaseLoc = deviceBaseLoc;
	}

	public String getDeviceDesc() {
		return deviceDesc;
	}

	public void setDeviceDesc(String deviceDesc) {
		this.deviceDesc = deviceDesc;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getServerUrl() {
		return serverUrl;
	}

	public void setServerUrl(String serverUrl) {
		this.serverUrl = serverUrl;
	}

	public Integer getServerPort() {
		return serverPort;
	}

	public void setServerPort(Integer serverPort) {
		this.serverPort = serverPort;
	}

	public String getCommunicationDetails() {
		return communicationDetails;
	}

	public void setCommunicationDetails(String communicationDetails) {
		this.communicationDetails = communicationDetails;
	}

	public long getPushFrequency() {
		return pushFrequency;
	}

	public void setPushFrequency(long pushFrequency) {
		this.pushFrequency = pushFrequency;
	}

	public long getPullFrequency() {
		return pullFrequency;
	}

	public void setPullFrequency(long pullFrequency) {
		this.pullFrequency = pullFrequency;
	}

	public String getSensorType() {
		return sensorType;
	}

	public void setSensorType(String sensorType) {
		this.sensorType = sensorType;
	}

	public DeviceStatusMaster getDeviceStatusMaster() {
		return deviceStatusMaster;
	}

	public void setDeviceStatusMaster(DeviceStatusMaster deviceStatusMaster) {
		this.deviceStatusMaster = deviceStatusMaster;
	}

	public Double getDeviceLocationLongitude() {
		return deviceLocationLongitude;
	}

	public void setDeviceLocationLongitude(Double deviceLocationLongitude) {
		this.deviceLocationLongitude = deviceLocationLongitude;
	}

	public Double getDeviceLocationLatitude() {
		return deviceLocationLatitude;
	}

	public void setDeviceLocationLatitude(Double deviceLocationLatitude) {
		this.deviceLocationLatitude = deviceLocationLatitude;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

}
