package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.DeviceStatusMaster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface DeviceStatusMasterRepository extends
		JpaRepository<DeviceStatusMaster, Integer> {

	@Query("select cn from DeviceStatusMaster cn")
	List<DeviceStatusMaster> getAllDeviceStatusMaster();

	@Query("select cn from DeviceStatusMaster cn where cn.id=:id")
	DeviceStatusMaster getDeviceStatusMasterById(@Param("id") Integer id);
	
	
	@Query("select cn from DeviceStatusMaster cn where cn.statusName=:statusName")
	DeviceStatusMaster getDeviceStatusMasterIdByName(@Param("statusName") String statusName);
	
	
	
}
