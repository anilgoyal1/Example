package net.atos.iot.repository;

import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.entity.EdgeGatewaySimulation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EdgeGatewaySimulationRepository extends
		JpaRepository<EdgeGatewaySimulation, Integer> {

	@Query("select cn from EdgeGatewaySimulation cn  where cn.simulationName=:simulationName")
	EdgeGatewaySimulation findEdgeGatewaySimulationBySimulationName(
			@Param("simulationName") String simulationName);

	@Query("select cn from EdgeGatewaySimulation cn  where cn.tenantId=:tenantId")
	List<EdgeGatewaySimulation> findEdgeGatewaySimulationForTenant(
			@Param("tenantId") Integer tenantId);

	@Query("select cn from EdgeGatewaySimulation cn  where cn.deviceIds in (:deviceIds)")
	List<EdgeGatewaySimulation> findEdgeGatewaySimulationByDeviceIds(
			@Param("deviceIds") List<String> deviceIds);

	@Modifying
	@Transactional
	@Query("delete from EdgeGatewaySimulation where simulationName=:simulationName ")
	void deleteEdgeGatewaySimulationBySimulationName(
			@Param("simulationName") String simulationName);

}
