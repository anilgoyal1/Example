package net.atos.iot.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.entity.SensorData;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface SensorDataRepository extends JpaRepository<SensorData, Long> {

	@Query("select cn from SensorData cn where cn.deviceId=:deviceId")
	List<SensorData> findSensorDataByDeviceId(@Param("deviceId") String deviceId);

	@Query("SELECT cn from SensorData cn  where cn.deviceId=:deviceId And cn.createdDate BETWEEN :fromDate AND :toDate order by cn.createdDate ")
	List<SensorData> getSensorDataByDate(@Param("deviceId") String deviceId,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

	@Query("SELECT cn from SensorData cn  where cn.deviceId=:deviceId And cn.createdDate BETWEEN :fromDate AND :toDate order by cn.createdDate desc ")
	List<SensorData> getSensorDataByCreatedDateAndDeviceId(
			@Param("deviceId") String deviceId,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

	@Query("select cn from SensorData cn where cn.deviceId=:deviceId order by cn.createdDate desc ")
	List<SensorData> findSensorDataByDeviceIdInDescOrder(
			@Param("deviceId") String deviceId);
	
	@Modifying
	@Transactional
	@Query("delete from SensorData where deviceId in (:deviceIds) ")
	void deleteSensorDataByDeviceIds(
			@Param("deviceIds") List<String> deviceIds);

}
