package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.District;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface DistrictRepository extends JpaRepository<District, Integer> {

	@Query("select cn from District cn where cn.isActive=:isActive")
	List<District> getAllDistrict(@Param("isActive") boolean isActive);

	@Query("select cn from District cn where cn.districtCode=:districtCode")
	District findDistrictByDistrictCode(
			@Param("districtCode") Integer districtCode);

	@Query("select cn from District cn where cn.districtName=:districtName")
	District findDistrictByDistrictName(
			@Param("districtName") String districtName);

}