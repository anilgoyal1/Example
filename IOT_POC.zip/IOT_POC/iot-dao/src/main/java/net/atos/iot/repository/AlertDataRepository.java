package net.atos.iot.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.entity.AlertData;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AlertDataRepository extends JpaRepository<AlertData, Long> {

	@Query("select cn from AlertData cn where cn.deviceId=:deviceId")
	List<AlertData> findAlertDataByDeviceId(@Param("deviceId") String deviceId);

	@Query("select cn from AlertData cn where cn.level=:level")
	List<AlertData> findAlertDataByLevel(@Param("level") String level);

	@Query("SELECT cn from AlertData cn  where cn.deviceId=:deviceId And cn.createdDate BETWEEN :fromDate AND :toDate order by cn.createdDate desc ")
	List<AlertData> findAlertDataByDeviceIdAndCreatedDate(
			@Param("deviceId") String deviceId,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

	@Query("select cn from AlertData cn where cn.deviceId in (:ids)")
	List<AlertData> findAlertDataByDeviceIds(@Param("ids") List<String> ids);

	@Query("select cn from AlertData cn where cn.level=:level and cn.deviceId in (:ids) ")
	List<AlertData> getDeviceByLevelAndDeviceIds(@Param("level") String level,
			@Param("ids") List<String> ids);

	@Query("select distinct cn.alertType from AlertData cn ")
	List<String> getDistinctAlertType();

	@Query("SELECT cn from AlertData cn  where cn.deviceId=:deviceId And cn.createdDate BETWEEN :fromDate AND :toDate AND cn.alertType!=:alertType order by cn.createdDate desc ")
	List<AlertData> getAlertDataByDeviceIdAndExceptAlertType(
			@Param("deviceId") String deviceId,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate,
			@Param("alertType") String alertType);

	@Modifying
	@Transactional
	@Query("delete from AlertData  where deviceId IN (:deviceIds) ")
	void deleteAlertDataByDeviceIds(@Param("deviceIds") List<String> deviceIds);

}
