package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.Country;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface CountryRepository extends JpaRepository<Country, Integer> {

	@Query("select cn from Country cn where cn.isActive=:isActive")
	List<Country> findAllCountries(@Param("isActive") boolean countryCode);

	@Query("select cn from Country cn where cn.countryId=:countryId")
	Country findCountryByCountryId(@Param("countryId") Integer countryId);

	@Query("select cn from Country cn where cn.countryCode=:countryCode and cn.isActive=true")
	Country findCountryCodeByCoutryCode(@Param("countryCode") String countryCode);
	
	
	@Query("select cn from Country cn where cn.countryId=:countryId")
	Country findCountryCodeByCountryId(@Param("countryId") Integer countryId);

	@Query("select pd from Country pd where pd.countryId in (:ids) order by pd.countryId")
	List<Country> findContriesByIds(@Param("ids") List<Integer> ids);

}
