package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.Tenant;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface TenantRepository extends JpaRepository<Tenant, Integer> {

	@Query("select tn from Tenant tn where tn.tenantId=:tenantId	")
	Tenant findTenantByTenantId(@Param("tenantId") Integer tenantId);

	@Query("select tn from Tenant tn where tn.tenantName=:tenantName")
	Tenant findTenantByTenantName(@Param("tenantName") String tenantName);

	@Query("select tn from Tenant tn where tn.isActive=:isActive")
	List<Tenant> findTenats(@Param("isActive") boolean isActive);
}
