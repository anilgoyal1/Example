package net.atos.iot.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.entity.GPSSensorData;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface GPSSensorDataRepository extends
		JpaRepository<GPSSensorData, Long> {

	@Query("select cn from GPSSensorData cn where cn.deviceId=:deviceId order by cn.createdDate desc")
	List<GPSSensorData> findGPSSensorDataByDeviceId(
			@Param("deviceId") String deviceId);

	@Query("SELECT cn from GPSSensorData cn  where cn.deviceId=:deviceId And cn.createdDate BETWEEN :fromDate AND :toDate order by cn.createdDate ")
	List<GPSSensorData> findGPSSensorDataByDeviceIdAndDate(@Param("deviceId") String deviceId,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

	@Query("SELECT cn from GPSSensorData cn  where cn.deviceId=:deviceId And cn.createdDate BETWEEN :fromDate AND :toDate order by cn.createdDate desc ")
	List<GPSSensorData> getGPSSensorDataByCreatedDateAndDeviceId(
			@Param("deviceId") String deviceId,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);
	
	
	@Query("select cn from GPSSensorData cn where cn.tripId=:tripId order by cn.createdDate desc")
	List<GPSSensorData> findGPSSensorDataByTripId(
			@Param("tripId") Long tripId);
	
	@Modifying
	@Transactional
	@Query("delete from GPSSensorData  where deviceId in (:deviceIds) ")
	void deleteGPSSensorDataByDeviceIds(
			@Param("deviceIds") List<String> deviceIds);

}
