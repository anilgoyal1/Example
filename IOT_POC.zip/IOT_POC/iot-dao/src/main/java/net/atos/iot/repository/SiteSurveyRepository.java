package net.atos.iot.repository;

import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.entity.SiteSurvey;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SiteSurveyRepository extends JpaRepository<SiteSurvey, Long> {

	@Query("select ss from SiteSurvey ss ")
	List<SiteSurvey> getAllSiteSurvey();

	@Query("select ss from SiteSurvey ss where ss.surveyId=:surveyId ")
	SiteSurvey getSiteSurveyBySurveyId(@Param("surveyId") long surveyId);

	@Query("select ss from SiteSurvey ss inner join ss.deviceMaster dm where dm.deviceId in (:deviceIds) ")
	public List<SiteSurvey> findSiteSurveyByDeviceIds(
			@Param("deviceIds") List<String> deviceIds);

	@Query("select ss from SiteSurvey ss inner join ss.deviceMaster dm where dm.deviceId=:deviceId ")
	public SiteSurvey findSiteSurveyByDeviceId(
			@Param("deviceId") String deviceId);

	@Transactional
	@Modifying
	@Query("delete  from SiteSurvey where deviceMaster.deviceId=:deviceId) ")
	public void deleteSiteSurveyByDeviceIds(
			@Param("deviceId") String deviceId);

}
