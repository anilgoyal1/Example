package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.Region;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface RegionRepository extends JpaRepository<Region, Integer> {

	@Query("select r from Region r")
	List<Region> getAllRegions();

	Region findByRegionCode(String regionCode);

	@Query("select rg from Region rg where rg.regionCode=:regionCode")
	Region findRegionByRegionCode(@Param("regionCode") String regionCode);

	@Query("select rg from Region rg where rg.regionId=:regionId and rg.isActive=true")
	Region findRegionByRegionId(@Param("regionId") Integer regionId);

	@Query("select pd from Region pd where pd.regionId in (:ids) order by pd.regionId")
	List<Region> findRegionsByIds(@Param("ids") List<Integer> ids);

}