package net.atos.iot.repository;

import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.entity.TripMaster;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface TripMasterRepository extends JpaRepository<TripMaster, Long> {

	@Query("select dm from TripMaster dm where dm.tripId=:tripId")
	TripMaster getTripByTripId(@Param("tripId") long tripId);
	
	@Query("select dm from TripMaster dm where dm.tripStatus=:tripStatus")
	List<TripMaster> getTripByTripStatus(@Param("tripStatus") String tripStatus);
	
	@Modifying
	@Transactional
	@Query("delete from TripMaster  where deviceId IN (:deviceIds) ")
	void deleteTripMasterByDeviceIds(@Param("deviceIds") List<String> deviceIds);
}
