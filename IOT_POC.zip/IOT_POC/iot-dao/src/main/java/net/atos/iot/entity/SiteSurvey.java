package net.atos.iot.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class SiteSurvey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3244860774580201957L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long surveyId;

	@OneToOne
	@JoinColumn(name = "deviceId")
	DeviceMaster deviceMaster;

	@Column(name = "networkConnectivitCheck")
	String networkConnectivitCheck;

	@Column(name = "networkType")
	String networkType;

	@Column(name = "siteName")
	String siteName;

	@Column(name = "address")
	String address;

	@Column(name = "phone")
	String phone;

	@Column(name = "roomName")
	String roomName;

	@Column(name = "exactLocation")
	String exactLocation;

	@Column(name = "ipAddressofDevice")
	String ipAddressofDevice;

	@Column(name = "hasRemoteConnectivityWithEdgeGatway")
	String hasRemoteConnectivityWithEdgeGatway;

	@Column(name = "createDate")
	Date createDate;

	@Column(name = "createdBy")
	String createdBy;

	@Column(name = "modifiedDate")
	String modifiedDate;

	@Column(name = "assingedTo")
	String assingedTo;

	@Column(name = "assingedDate")
	Date assingedDate;

	@Column(name = "completedBy")
	String completedBy;

	@Column(name = "completedDate")
	Date completedDate;

	@Column(name = "status")
	String status;

	public Long getSurveyId() {
		return surveyId;
	}

	public void setSurveyId(Long surveyId) {
		this.surveyId = surveyId;
	}

	public DeviceMaster getDeviceMaster() {
		return deviceMaster;
	}

	public void setDeviceMaster(DeviceMaster deviceMaster) {
		this.deviceMaster = deviceMaster;
	}

	public String getNetworkConnectivitCheck() {
		return networkConnectivitCheck;
	}

	public void setNetworkConnectivitCheck(String networkConnectivitCheck) {
		this.networkConnectivitCheck = networkConnectivitCheck;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getExactLocation() {
		return exactLocation;
	}

	public void setExactLocation(String exactLocation) {
		this.exactLocation = exactLocation;
	}

	public String getIpAddressofDevice() {
		return ipAddressofDevice;
	}

	public void setIpAddressofDevice(String ipAddressofDevice) {
		this.ipAddressofDevice = ipAddressofDevice;
	}

	public String getHasRemoteConnectivityWithEdgeGatway() {
		return hasRemoteConnectivityWithEdgeGatway;
	}

	public void setHasRemoteConnectivityWithEdgeGatway(
			String hasRemoteConnectivityWithEdgeGatway) {
		this.hasRemoteConnectivityWithEdgeGatway = hasRemoteConnectivityWithEdgeGatway;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getAssingedTo() {
		return assingedTo;
	}

	public void setAssingedTo(String assingedTo) {
		this.assingedTo = assingedTo;
	}

	public Date getAssingedDate() {
		return assingedDate;
	}

	public void setAssingedDate(Date assingedDate) {
		this.assingedDate = assingedDate;
	}

	public String getCompletedBy() {
		return completedBy;
	}

	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}

	public Date getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
