package net.atos.iot.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sensor_data")
public class SensorData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7047456147585819694L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "deviceId ")
	String deviceId;

	@Column(name = "simulated ")
	String simulated;

	@Column(name = "temperature ")
	Double temprature;

	@Column(name = "humidity ")
	Double humidity;

	@Column(name = "receivedTime ")
	Date receivedTime;

	@Column(name = "createdDate ")
	Date createdDate;

	@Column(name = "alertType")
	String alertType;

	Double hardDiskUsed;

	Double ramUsed;

	Double cpuUsed;

	public Double getHardDiskUsed() {
		return hardDiskUsed;
	}

	public void setHardDiskUsed(Double hardDiskUsed) {
		this.hardDiskUsed = hardDiskUsed;
	}

	public Double getRamUsed() {
		return ramUsed;
	}

	public void setRamUsed(Double ramUsed) {
		this.ramUsed = ramUsed;
	}

	public Double getCpuUsed() {
		return cpuUsed;
	}

	public void setCpuUsed(Double cpuUsed) {
		this.cpuUsed = cpuUsed;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSimulated() {
		return simulated;
	}

	public void setSimulated(String simulated) {
		this.simulated = simulated;
	}

	public Double getTemprature() {
		return temprature;
	}

	public void setTemprature(Double temprature) {
		this.temprature = temprature;
	}

	public Double getHumidity() {
		return humidity;
	}

	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public Date getReceivedTime() {
		return receivedTime;
	}

	public void setReceivedTime(Date receivedTime) {
		this.receivedTime = receivedTime;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
}
