package net.atos.iot.repository;

import java.util.List;

import net.atos.iot.entity.UserDetails;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface UserDetailsRepository extends JpaRepository<UserDetails, Integer> {

	@Query("select ur from UserDetails ur where ur.userId=:userId And  ur.isActive=:isActive")
	UserDetails findActiveUserDetailsByUserId(@Param("userId") String userId, @Param("isActive") boolean isActive);

	@Query("select ur from UserDetails ur where ur.userDetailsId=:userDetailsId And  ur.isActive=:isActive")
	UserDetails findActiveUserDetailsByUserDetailsId(@Param("userDetailsId") Integer userDetailsId,
			@Param("isActive") boolean isActive);

	@Query("select ur from UserDetails ur where ur.userDetailsId=:userDetailsId")
	UserDetails findUserDetailsByUserDetailsId(@Param("userDetailsId") Integer userDetailsId);

	@Query("select ur from UserDetails ur where ur.userId=:userId ")
	UserDetails findUserDetailsByUserId(@Param("userId") String userId);

	@Query("select ur from UserDetails ur where ur.isActive=:isActive")
	List<UserDetails> finalAllUsers(@Param("isActive") boolean isActive);
	
	
}
