/**
 *  Please dont change this class with common class AlertDataDTO
 */

package net.atos.iot;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AlertDataDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("DeviceId")
	String deviceId;
	
	@JsonProperty("Simulated")
	String simulated;
	
	@JsonProperty("ReceivedTime")
	String receivedTime;
	
	@JsonProperty("Temperature")
	float temperature;
	
	@JsonProperty("Humidity")
	float humidity;
	
	@JsonProperty("Description")
	String description;
	
	@JsonProperty("AlertType")
	String alertType;
	
	@JsonProperty("Level")
	String level;
	

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getSimulated() {
		return simulated;
	}

	public void setSimulated(String simulated) {
		this.simulated = simulated;
	}

	public String getReceivedTime() {
		return receivedTime;
	}

	public void setReceivedTime(String receivedTime) {
		this.receivedTime = receivedTime;
	}

	public float getTemperature() {
		return temperature;
	}

	public void setTemperature(float temperature) {
		this.temperature = temperature;
	}

	public float getHumidity() {
		return humidity;
	}

	public void setHumidity(float humidity) {
		this.humidity = humidity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

}
