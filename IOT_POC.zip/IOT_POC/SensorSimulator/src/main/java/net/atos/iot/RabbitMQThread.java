package net.atos.iot;

import java.text.ParseException;
import java.util.Random;

import com.fasterxml.jackson.databind.ObjectMapper;

public class RabbitMQThread extends Thread {

	private Integer minTemperature;

	private Integer maxTemperature;

	private Integer minHumidity;

	private Integer maxHumidity;

	private String sensorDataRoutingKey = "sensordata.*";

	private String alertDataRoutingKey = "techalerts.*";

	private String deviceId;

	Producer producer;

	public RabbitMQThread(String deviceId, Integer minTemperature,
			Integer maxTemperature, Integer minHumidity, Integer maxHumidity,
			Producer producer) {
		this.deviceId = deviceId;
		this.minTemperature = minTemperature;
		this.maxTemperature = maxTemperature;
		this.minHumidity = minHumidity;
		this.maxHumidity = maxHumidity;
		this.producer = producer;
	}

	@Override
	public void run() {
		while (true) {
			try {
				generateData();
				Thread.sleep(120000l);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	public String generateData() {
		Random random = new Random();
		float temperature = random.nextInt(maxTemperature - minTemperature)
				+ minTemperature;
		float humidity = random.nextInt(maxHumidity - minHumidity)
				+ minHumidity;
		float hDDUsed = (float) (random.nextFloat() * (56.5 - 15.5) + 15.5);
		float cPUUsed = random.nextFloat() * (25 - 15) + 15;
		float ramUsed = random.nextFloat() * (55 - 25) + 25;

		if (temperature <= 21 || temperature >= 28) {
			generateTemeratureAlert(deviceId, temperature, humidity, hDDUsed,
					ramUsed, cPUUsed);
		}
		if (humidity <= minHumidity || humidity >= maxHumidity) {
			generateHumidityAlert(deviceId, temperature, humidity, hDDUsed,
					ramUsed, cPUUsed);
		}

		return generateSensorData(deviceId, temperature, humidity, hDDUsed,
				ramUsed, cPUUsed);

	}

	private String generateSensorData(String deviceId2, float temperature,
			float humidity, float hDDUsed, float ramUsed, float cPUUsed) {
		SensorDataDTO sensorDataDTO = new SensorDataDTO();
		sensorDataDTO.setSimulated("1");
		sensorDataDTO.setcPUUsed(cPUUsed);
		sensorDataDTO.setTemperature(temperature);
		sensorDataDTO.setHumidity(humidity);
		sensorDataDTO.sethDDUsed(hDDUsed);
		sensorDataDTO.setrAMUsed(ramUsed);
		sensorDataDTO.setDeviceId(deviceId2);
		try {
			sensorDataDTO.setReceivedTime(DateUtil
					.createCurrentDateInISOFormat());
			// JSONObject json = new JSONObject(sensorDataDTO);
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(sensorDataDTO);
			sendDataToQueue(json.toString(), sensorDataRoutingKey);
			// producer.produceMsg(json.toString(), sensorDataRoutingKey);
		} catch (ParseException e) {
			System.out.println("error in date parsing " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception " + e.getMessage());
		}
		return "SUCCESS";
	}

	private String generateTemeratureAlert(String deviceId2, float temperature,
			float humidity, float hDDUsed, float ramUsed, float cPUUsed) {
		AlertDataDTO alertDataDTO = new AlertDataDTO();
		alertDataDTO.setDeviceId(deviceId2);
		alertDataDTO.setSimulated("1");
		alertDataDTO.setTemperature(temperature);
		alertDataDTO.setHumidity(humidity);
		if (temperature <= minTemperature) {
			alertDataDTO.setLevel("WARN");
			alertDataDTO
					.setDescription("Alert raised for temperature rule violation");
		}
		if (temperature >= maxTemperature) {
			alertDataDTO.setLevel("CRITICAL");
			alertDataDTO
					.setDescription("Alert raised for temperature rule violation");
		}
		alertDataDTO.setAlertType("TEMPERATURE_VIOLATION");
		try {
			alertDataDTO.setReceivedTime(DateUtil
					.createCurrentDateInISOFormat());
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(alertDataDTO);
			sendDataToQueue(json.toString(), alertDataRoutingKey);
			// producer.produceMsg(json, alertDataRoutingKey);
		} catch (ParseException e) {
			System.out.println("error in date parsing " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception " + e.getMessage());
		}

		return "SUCCESS";
	}

	private String generateHumidityAlert(String deviceId2, float temperature,
			float humidity, float hDDUsed, float ramUsed, float cPUUsed) {
		AlertDataDTO alertDataDTO = new AlertDataDTO();
		alertDataDTO.setDeviceId(deviceId2);
		alertDataDTO.setSimulated("1");
		alertDataDTO.setTemperature(temperature);
		alertDataDTO.setHumidity(humidity);
		if (humidity <= minHumidity) {
			alertDataDTO.setLevel("WARN");
			alertDataDTO
					.setDescription("Alert raised for humidity rule violation");
			alertDataDTO.setAlertType("HUMIDITY_VIOLATION");

		}
		if (humidity >= maxHumidity) {
			alertDataDTO.setLevel("CRITICAL");
			alertDataDTO
					.setDescription("Alert raised for humidity rule violation");
			alertDataDTO.setAlertType("HUMIDITY_VIOLATION");
		}

		try {
			alertDataDTO.setReceivedTime(DateUtil
					.createCurrentDateInISOFormat());
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(alertDataDTO);
			// System.out.println();
			sendDataToQueue(json.toString(), alertDataRoutingKey);
		} catch (ParseException e) {
			System.out.println("error in date parsing " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception " + e.getMessage());
		}
		return "SUCCESS";

	}

	private void sendDataToQueue(String json, String routingKey) {
		System.out.println("message " + json);
		producer.produceMsg(json, routingKey);
	}

}
