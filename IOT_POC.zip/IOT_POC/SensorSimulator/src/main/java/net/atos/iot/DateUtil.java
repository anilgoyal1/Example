package net.atos.iot;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class DateUtil {

	private static final Logger LOGGER = Logger.getLogger(DateUtil.class);

	private static final String UTC = "UTC";

	private static TimeZone tz = TimeZone.getTimeZone(UTC);

	public static final String ISODATE = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	private static final ThreadLocal<DateFormat> threadSafeDateFormat = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat(ISODATE);
		}
	};

	public static String convertDateToDateISODateString(Date sourse)
			throws ParseException {
		threadSafeDateFormat.get().setTimeZone(tz);
		String d = threadSafeDateFormat.get().format(sourse);
		return d;
	}

	public static String createCurrentDateInISOFormat() throws ParseException {
		String dateStr = null;
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		Date d = c.getTime();
		dateStr = convertDateToDateISODateString(d);
		return dateStr;
	}
}
