package net.atos.iot;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRabbitMqProducerApplication implements CommandLineRunner {

	@Value("${minTemperature}")
	private Integer minTemperature;

	@Value("${maxTemperature}")
	private Integer maxTemperature;

	@Value("${minHumidity}")
	private Integer minHumidity;

	@Value("${maxHumidity}")
	private Integer maxHumidity;

	@Value("${jsa.rabbitmq.sensorDataRoutingKey}")
	private String sensorDataRoutingKey;

	@Value("${jsa.rabbitmq.alertDataRoutingKey}")
	private String alertDataRoutingKey;

	@Autowired
	Producer producer;

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(
				SpringRabbitMqProducerApplication.class);

		app.run(args);
		System.out.println("main thread ended");
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("run method started");
		if (args != null && args.length >= 0) {
			// String devices =
			// "[Simulator_test1_BTIC-PUNE0, Simulator_test1_BTIC-PUNE1, Simulator_test1_BTIC-PUNE2, Simulator_test1_BTIC-PUNE3, Simulator_test1_BTIC-PUNE4, Simulator_test1_BTIC-PUNE5, Simulator_test1_BTIC-PUNE6, Simulator_test1_BTIC-PUNE7, Simulator_test1_BTIC-PUNE8, Simulator_test1_BTIC-PUNE9]";
			String devices = args[0];
			try {
				if (args[1] != null) {
					Integer minTemp = Integer.parseInt(args[1]);
					if (minTemp != null) {
						minTemperature = minTemp;
					}
				}
			} catch (Exception e) {
				System.out
						.println("Min temperature value not passed or invalid value");
			}
			try {
				if (args[2] != null) {
					Integer maxTemp = Integer.parseInt(args[2]);
					if (maxTemp != null) {
						maxTemperature = maxTemp;
					}
				}
			} catch (Exception e) {
				System.out
						.println("Max temperature value not passed or invalid value");
			}

			try {
				if (args[3] != null) {
					Integer minHum = Integer.parseInt(args[3]);
					if (minHum != null) {
						minHumidity = minHum;
					}
				}
			} catch (Exception e) {
				System.out
						.println("minHumidity value not passed or invalid value");
			}

			try {
				if (args[4] != null) {
					Integer maxHum = Integer.parseInt(args[4]);
					if (maxHum != null) {
						maxHumidity = maxHum;
					}
				}
			} catch (Exception e) {
				System.out
						.println("maxHumidity value not passed or invalid value");
			}

			System.out.println("minTemperature " + minTemperature);
			System.out.println("maxTemperature " + maxTemperature);
			System.out.println("minHumidity " + minHumidity);
			System.out.println("maxHumidity " + maxHumidity);
			System.out.println("arguments from docker  " + devices);
			if (devices != null && devices.contains("[")
					&& devices.contains("]")) {
				devices = devices.replace("[", "").replace("]", "");

				List<String> listOfDevices = Arrays.asList(devices.split(","));
				if (listOfDevices != null && listOfDevices.size() > 0) {
					for (String deviceId : listOfDevices) {
						System.out.println(deviceId.trim());
						new Thread(new RabbitMQThread(deviceId.trim(),
								minTemperature, maxTemperature, minHumidity,
								maxHumidity, producer)).start();

					}
				}
			}
		}
	}
}
