/**
 *  Please dont change this class with common class SensorDataDTO
 */
package net.atos.iot;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SensorDataDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8306656672372961953L;

	
	String Simulated;

	@JsonProperty("ReceivedTime")
	String receivedTime;

	@JsonProperty("Temperature")
	float temperature;

	@JsonProperty("Humidity")
	float humidity;

	@JsonProperty("HDDUsed")
	float hDDUsed;

	@JsonProperty("RAMUsed")
	float rAMUsed;

	@JsonProperty("CPUUsed")
	float cPUUsed;

	@JsonProperty("DeviceId")
	String deviceId;

	@JsonProperty("Simulated")
	public String getSimulated() {
		return Simulated;
	}

	public void setSimulated(String simulated) {
		Simulated = simulated;
	}

	public String getReceivedTime() {
		return receivedTime;
	}

	public void setReceivedTime(String receivedTime) {
		this.receivedTime = receivedTime;
	}

	public float getTemperature() {
		return temperature;
	}

	public void setTemperature(float temperature) {
		this.temperature = temperature;
	}

	public float getHumidity() {
		return humidity;
	}

	public void setHumidity(float humidity) {
		this.humidity = humidity;
	}

	public float gethDDUsed() {
		return hDDUsed;
	}

	public void sethDDUsed(float hDDUsed) {
		this.hDDUsed = hDDUsed;
	}

	public float getrAMUsed() {
		return rAMUsed;
	}

	public void setrAMUsed(float rAMUsed) {
		this.rAMUsed = rAMUsed;
	}

	public float getcPUUsed() {
		return cPUUsed;
	}

	public void setcPUUsed(float cPUUsed) {
		this.cPUUsed = cPUUsed;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

}
