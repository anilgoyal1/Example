package net.atos.iot.api;

import io.swagger.annotations.ApiParam;

import java.util.List;

import net.atos.iot.dto.RoleDTO;
import net.atos.iot.service.RoleService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RoleController {

	@Autowired
	RoleService userRoleServiceImpl;

	@CrossOrigin
	@GetMapping("/roles/{active}")
	public List<RoleDTO> getAllRoles(@PathVariable(value = "active") boolean active) {
		return userRoleServiceImpl.getAllRoleDtos(active);
	}

	@CrossOrigin
	@PostMapping("/createRole")
	public String createUserRole(@RequestBody @ApiParam(value="role dto") RoleDTO roleDto) {
		return userRoleServiceImpl.addRole(roleDto);
	}

	@CrossOrigin
	@PostMapping("/updateRole")
	public String updateRole(@RequestBody RoleDTO roleDto) {
		return userRoleServiceImpl.updateRole(roleDto);
	}

	@CrossOrigin
	@GetMapping("/deleteRole/{roleId}")
	public String deleteRole(@PathVariable("roleId") final int roleId) {
		return userRoleServiceImpl.deleteRole(roleId);
	}

	@CrossOrigin
	@GetMapping("/role/{roleId}")
	public RoleDTO getRole(@PathVariable("roleId") final int roleId) {
		return userRoleServiceImpl.getRoleDtoByRoleId(roleId);
	}

}
