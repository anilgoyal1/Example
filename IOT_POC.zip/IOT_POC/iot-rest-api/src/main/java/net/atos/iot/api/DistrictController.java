package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.DistrictDTO;
import net.atos.iot.service.DistrictService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class is used to handle the rest services related to District.
 * 
 * @author a602834
 *
 */
@RestController
public class DistrictController {

	private static final Logger LOGGER = Logger
			.getLogger(DistrictController.class);

	@Autowired
	@Qualifier(value = "districtServiceImpl")
	private DistrictService districtService;

	/**
	 * This method is used for getting the district list.
	 * 
	 * @return list of DistrictDTO
	 */
	@CrossOrigin
	@GetMapping(value = "/districts/{active}")
	public List<DistrictDTO> getAllDistrictList(
			@PathVariable("active") boolean active) {
		List<DistrictDTO> aldistrict = districtService.getDistricts(active);
		return aldistrict;
	}

	@CrossOrigin
	@GetMapping(value = "/getDistrictByDistrictCode/{districtCode}")
	public DistrictDTO getDistrictByDistrictCode(
			@PathVariable("districtCode") final Integer districtCode) {
		return districtService.getDistrictByDistrictCode(districtCode);
	}

	/**
	 * This method is used to save district.
	 * 
	 * @param district
	 * @return boolean value
	 */
	@CrossOrigin
	@PostMapping(value = "/saveDistrict")
	public String saveCountry(@RequestBody DistrictDTO district) {
		LOGGER.info("Savedistrict" + district);
		LOGGER.info(districtService);
		return districtService.saveDistricts(district);

	}
	
	@CrossOrigin
	@PostMapping(value = "/updateDistrict")
	public String updateDistrict(@RequestBody DistrictDTO district) {
		LOGGER.info("Savedistrict" + district);
		LOGGER.info(districtService);
		return districtService.updateDistrict(district);

	}
	
	
	

	/**
	 * This method is used to delete district
	 * 
	 * @param districtDto
	 * @return deleted District
	 */
	@CrossOrigin
	@GetMapping(value = "/deleteDistrict/{districtCode}")
	public String deleteDistrict(
			@PathVariable("districtCode") Integer districtCode) {
		return districtService.deleteDistrict(districtCode);

	}

}
