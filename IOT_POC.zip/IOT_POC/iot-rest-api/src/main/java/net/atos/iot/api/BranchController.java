package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.BranchDTO;
import net.atos.iot.service.BranchService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BranchController {

	private static final Logger LOGGER = Logger
			.getLogger(BranchController.class);

	@Autowired
	@Qualifier(value = "branchServiceImpl")
	private BranchService branchService;

	@CrossOrigin
	@GetMapping(value = "/branches/{active}")
	public List<BranchDTO> getAllBranchList(
			@PathVariable(value = "active") boolean active) {
		LOGGER.info("BranchController getBranchService ");
		List<BranchDTO> albranch = branchService.getBranches(active);
		return albranch;
	}

	@CrossOrigin
	@GetMapping(value = "/deleteBranch/{branchId}")
	public String deleteBranch(@PathVariable("branchId") final Long branchId) {
		return branchService.deleteBranch(branchId);
	}

	@CrossOrigin
	@GetMapping(value = "/getBranchByBranchCode/{branchCode}")
	public BranchDTO getBranchByBranchCode(
			@PathVariable("branchCode") final String branchCode) {
		return branchService.getBranchByBranchCode(branchCode);
	}

	@CrossOrigin
	@GetMapping(value = "/getBranchByBranchId/{branchId}")
	public BranchDTO getBranchByBranchId(
			@PathVariable("branchId") final Long branchId) {
		return branchService.getBranchByBranchId(branchId);
	}

	@CrossOrigin
	@PostMapping(value = "/saveBranch")
	public String saveBranch(@RequestBody BranchDTO branch) {
		return branchService.savebranches(branch);
	}

	@PostMapping(value = "/updateBranch")
	public String updateBranch(@RequestBody BranchDTO branch) {
		return branchService.updateBranch(branch);
	}

}
