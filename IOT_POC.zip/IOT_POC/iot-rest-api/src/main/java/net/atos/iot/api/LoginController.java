package net.atos.iot.api;

import net.atos.iot.dto.UserDetailsDTO;
import net.atos.iot.service.LoginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {

	@Autowired
	LoginService loginServiceImpl;

	@CrossOrigin
	@PostMapping("/login")
	public UserDetailsDTO login(@RequestParam("userId") final String userId,
			@RequestParam("password") final String password) {
		return loginServiceImpl.login(userId, password);
	}

}
