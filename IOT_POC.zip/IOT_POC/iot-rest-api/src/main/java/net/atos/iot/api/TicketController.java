package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.TicketDTO;
import net.atos.iot.service.TicketService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TicketController {

	private static final Logger LOGGER = Logger
			.getLogger(TicketController.class);

	@Autowired
	@Qualifier(value = "ticketServiceImpl")
	private TicketService ticketService;

	@CrossOrigin
	@PostMapping(value = "/createTicket")
	public String saveBranch(@RequestBody TicketDTO ticketDTO) {
		return ticketService.createTicket(ticketDTO);
	}

	@CrossOrigin
	@GetMapping(value = "/getTicketByDeviceAndStatus/{deviceId}/{status}")
	public List<TicketDTO> getTicketByDeviceAndStatus(
			@PathVariable(value = "deviceId") String deviceId,
			@PathVariable(value = "status") String status) {
		List<TicketDTO> ticketList = ticketService.getTicketByDeviceAndStatus(
				deviceId, status);
		return ticketList;
	}

	@CrossOrigin
	@GetMapping(value = "/getTicketByDeviceId/{deviceId}")
	public List<TicketDTO> getTicketByDeviceId(
			@PathVariable("deviceId") final String deviceId) {
		return ticketService.getTicketByDeviceId(deviceId);
	}

	@CrossOrigin
	@GetMapping(value = "/getTicketByStatus/{status}")
	public List<TicketDTO> getTicketByStatus(
			@PathVariable("status") final String status) {
		return ticketService.getTicketByStatus(status);
	}

	@CrossOrigin
	@PostMapping(value = "/updateTicket/{userId}")
	public String updateTicket(@PathVariable("userId") final String userId,
			@RequestBody TicketDTO ticketDTO) {
		return ticketService.updateTicket(ticketDTO,userId);
	}

	@CrossOrigin
	@GetMapping(value = "/getAllTicket")
	public List<TicketDTO> getAllTicket() {
		return ticketService.getAllTicket();
	}

	@CrossOrigin
	@GetMapping(value = "/getTicketByTicketId/{ticketId}")
	public TicketDTO getTicketByTicketId(
			@PathVariable("ticketId") final Long ticketId) {
		return ticketService.getTicketByTicketId(ticketId);
	}

	@CrossOrigin
	@GetMapping(value = "/getTicketByTenanatIdAndStatus/{tenantId}/{status}")
	public List<TicketDTO> getTicketByTenanatIdAndStatus(
			@PathVariable("tenantId") final Integer tenantId,
			@PathVariable("status") final String status) {
		return ticketService.getTicketByTenanatIdAndStatus(tenantId, status);
	}

	@CrossOrigin
	@GetMapping(value = "/getAllTicketTenantIdWise/{tenantId}")
	public List<TicketDTO> getAllTicketTenantIdWise(
			@PathVariable("tenantId") final Integer tenantId) {
		return ticketService.getAllTicketTenantIdWise(tenantId);
	}

	
	@CrossOrigin
	@PostMapping(value = "/getTicketCountForDashboard/{tenantId}")
	public String getTicketCountForDashboard(
			@PathVariable("tenantId") final Integer tenantId,
			@RequestBody(required = false) String filterData) {
		return ticketService.getTicketCountForDashboard(tenantId, filterData);
	}
	

	
	
	@CrossOrigin
	@PostMapping(value = "/createTicketTest")
	public String createTicketTest(@RequestBody TicketDTO ticketDTO) {
		return ticketService.createTicketForAishwarya(ticketDTO);
	}
}
