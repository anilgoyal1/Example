package net.atos.iot.api;

import net.atos.iot.dto.RabbitMQSenderDTO;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

@RestController
public class RabbitMQSender {

	private static final Logger LOGGER = Logger.getLogger(RabbitMQSender.class);

	@CrossOrigin
	@PostMapping(value = "/sendDataToQueue")
	public String sendDataToQueue(@RequestBody RabbitMQSenderDTO rabbitSender) {
		String strReturn = null;
		try {
			if (rabbitSender.getMessage() != null) {
				if (rabbitSender.getHost() != null
						&& rabbitSender.getPort() > 0) {
					if (rabbitSender.getExchangeType() != null
							&& rabbitSender.getQueueName() != null
							&& rabbitSender.getExchangeName() != null) {
						this.sendDataToQueue(rabbitSender.getMessage(),
								rabbitSender.getHost(), rabbitSender.getPort(),
								rabbitSender.getUserName(),
								rabbitSender.getPassword(),
								rabbitSender.getExchangeType(),
								rabbitSender.getExchangeName(),
								rabbitSender.getQueueName(),
								rabbitSender.getRoutKey());
						strReturn = "Sucessfully send Data to queue";
					} else {
						strReturn = "Please check queue name,Exchange name, Exchange type.";
					}
				} else {
					strReturn = "Please check host and port for queue.";
				}
			} else {
				strReturn = "Please send message content to for queue.";
			}
		} catch (Exception e) {
			LOGGER.error("e", e);
			return "Data not send to queue";
		}
		return strReturn;

	}

	private void sendDataToQueue(String json, String host, int port,
			String userName, String password, String exchangeType,
			String exchangeName, String queueName, String routKey) {
		Channel channel = null;
		Connection connection = null;
		try {
			// log.info(" in connection of queue ::"+json);
			ConnectionFactory factory = new ConnectionFactory();
			factory.setHost(host);
			factory.setPort(port);
			factory.setPassword(password);
			factory.setUsername(userName);
			connection = factory.newConnection();
			channel = connection.createChannel();
			// log.info(" connection done");
			// System.out.println(" connection done");
			channel.exchangeDeclare(exchangeName, exchangeType, true);
			channel.queueBind(queueName, exchangeName, routKey);
			channel.basicPublish(exchangeName, routKey, null, json.getBytes());
			// System.out.println(" [x] Sent '" + json + "'");
			// log.info(" [x] Sent '" + json + "'");

		} catch (Exception e) {
			LOGGER.error("error ", e);
		} finally {
			try {
				channel.close();
				connection.close();
			} catch (Exception e) {
				LOGGER.error("error ", e);
			}

		}

	}
}
