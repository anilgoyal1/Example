package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.GPSSensorDataDTO;
import net.atos.iot.service.GPSSensorDataService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GPSSensorDataController {

	@Autowired
	private GPSSensorDataService gpsSensorDataServiceImpl;

	@CrossOrigin
	@PostMapping("/getGPSSensorDataByTenantId/{tenantId}")
	public List<GPSSensorDataDTO> getGPSSensorDataByTenantId(
			@PathVariable("tenantId") final Integer tenantId,
			@RequestBody(required = false) String filterData) {
		List<GPSSensorDataDTO> alertData = gpsSensorDataServiceImpl
				.getGPSSensorDataByTenantId(tenantId, filterData);
		return alertData;
	}

	@CrossOrigin
	@PostMapping("/getGPSSensorDataByDeviceId/{deviceId}")
	public List<GPSSensorDataDTO> getGPSSensorDataByDeviceId(
			@PathVariable("deviceId") final String deviceId,
			@RequestBody(required = false) String filterData) {
		List<GPSSensorDataDTO> alertData = gpsSensorDataServiceImpl
				.getGPSGPSSensorDataByDeviceId(deviceId, filterData);
		return alertData;
	}

	@CrossOrigin
	@GetMapping("/getAllGPSSensorData")
	public List<GPSSensorDataDTO> getAllGPSSensorData() {
		List<GPSSensorDataDTO> alertData = gpsSensorDataServiceImpl
				.getAllGPSSensorData();
		return alertData;
	}

}
