package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.EdgeGatewaySimulationDTO;
import net.atos.iot.service.EdgeGatewaySimulationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EdgeGatewaySimulationController {

	@Autowired
	EdgeGatewaySimulationService edgeGatewaySimulationService;

	@CrossOrigin
	@PostMapping("/createEdgeGateWaySimulator/{noOfDevices}")
	public String createEdgeGateWaySimulator(
			@RequestBody EdgeGatewaySimulationDTO edgeGatewaySimulationDTO,
			@PathVariable("noOfDevices") int noOfDevices) {
		return edgeGatewaySimulationService.createSimulationDevicesMasterData(
				edgeGatewaySimulationDTO, noOfDevices);

	}

	@CrossOrigin
	@GetMapping("/getAllSEdgeGateWaySimulation")
	public List<EdgeGatewaySimulationDTO> getAllSEdgeGateWaySimulation() {
		return edgeGatewaySimulationService.getAllEdgeGatewaySimulationDTO();

	}

	@CrossOrigin
	@GetMapping("/getEdgeGateWaySimulationBySimulationName/{simulationName}")
	public EdgeGatewaySimulationDTO getEdgeGateWaySimulationBySimulationName(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.getEdgeGateWaySimulationBySimulationName(simulationName);

	}

	@CrossOrigin
	@GetMapping("/getEdgeGateWaySimulationByTenantId/{tenantId}")
	public List<EdgeGatewaySimulationDTO> getEdgeGateWaySimulationByTenantId(
			@PathVariable("tenantId") Integer tenantId) {
		return edgeGatewaySimulationService
				.getEdgeGateWaySimulationByTenantId(tenantId);

	}

	@CrossOrigin
	@GetMapping("/deleteEdgeGateWaySimulator/{simulationName}")
	public String deleteEdgeGateWaySimulator(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.removeSimulationDevicesMasterData(simulationName);

	}

}
