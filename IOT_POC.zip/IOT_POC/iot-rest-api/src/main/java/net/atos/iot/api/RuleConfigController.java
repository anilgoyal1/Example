package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.RuleConfigDTO;
import net.atos.iot.service.RuleConfigService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RuleConfigController {

	@Autowired
	private RuleConfigService ruleConfigService;

	@CrossOrigin
	@GetMapping("/getAllruleConfiguration")
	public List<RuleConfigDTO> getAllruleConfiguration() {
		return ruleConfigService.getAllRuleConfig();
	}

	@CrossOrigin
	@GetMapping("/getRuleConfigurationByRuleCode/{ruleCode}")
	public RuleConfigDTO getRuleConfigurationByRuleCode(
			@PathVariable(value = "ruleCode") String ruleCode) {
		return ruleConfigService.getAllruleConfigByRuleCode(ruleCode);
	}

	@CrossOrigin
	@PostMapping("/saveRuleConfiguration")
	public String saveRuleConfiguration(@RequestBody RuleConfigDTO ruleConfigDTO) {
		return ruleConfigService.addRuleConfig(ruleConfigDTO);
	}

	@CrossOrigin
	@GetMapping("/deleteRuleConfig/{ruleCode}")
	public String deleteRuleConfig(
			@PathVariable(value = "ruleCode") String ruleCode) {
		return ruleConfigService.deleteRuleConfig(ruleCode);
	}

	@CrossOrigin
	@PostMapping(value = "/updateRuleConfig")
	public String updateRuleConfigByRuleCode(
			@RequestBody RuleConfigDTO ruleConfigDTO) {
		return ruleConfigService.updateRuleConfig(ruleConfigDTO);
	}

}
