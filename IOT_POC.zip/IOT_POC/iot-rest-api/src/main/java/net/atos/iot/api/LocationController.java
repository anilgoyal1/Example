package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.LocationDTO;
import net.atos.iot.service.LocationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LocationController {

	@Autowired
	LocationService locationServiceImpl;

	@CrossOrigin
	@GetMapping("/getAllLocatons/{active}")
	public List<LocationDTO> getAllLocationList(
			@PathVariable(value = "active") boolean active) {
		List<LocationDTO> allLocation = locationServiceImpl
				.getAllLocation(active);
		return allLocation;
	}

	@CrossOrigin
	@PostMapping("/saveLocation")
	public String saveLocation(@RequestBody LocationDTO locationDto) {
		return locationServiceImpl.saveLocation(locationDto);
	}

	@CrossOrigin
	@PostMapping("/updateLocation")
	public String updateLocation(@RequestBody LocationDTO locationDto) {
		return locationServiceImpl.updateLocation(locationDto);
	}

	@CrossOrigin
	@GetMapping("/deleteLocation/{locationId}")
	public String deleteLocation(
			@PathVariable(value = "locationId") Long locationId) {
		return locationServiceImpl.deleteLocation(locationId);
	}

	@CrossOrigin
	@GetMapping(value = "/fetchAllLocByLocSubtype/{locSubtype}")
	public List<LocationDTO> fetchAllLocByLocSubtype(
			@PathVariable("locSubtype") final String locSubtype) {
		return locationServiceImpl.getAllLocationByLocSubtype(locSubtype);
	}

	@CrossOrigin
	@GetMapping(value = "/getLocationByLocCode/{locCode}")
	public LocationDTO getLocationByLocCode(
			@PathVariable("locCode") final String locCode) {
		return locationServiceImpl.getLocationByLocCode(locCode);
	}

	@CrossOrigin
	@GetMapping(value = "/getLocationByLocationId/{locationId}")
	public LocationDTO getLocationByLocationId(
			@PathVariable("locationId") final Long locationId) {
		return locationServiceImpl.getLocationByLocationId(locationId);
	}

}
