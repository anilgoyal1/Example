package net.atos.iot.api;

import java.util.List;
import java.util.Map;

import net.atos.iot.dto.TenantDTO;
import net.atos.iot.service.TenantService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TenantController {

	@Autowired
	private TenantService tenanatServiceImpl;

	@CrossOrigin
	@GetMapping("/tenants/{active}")
	public List<TenantDTO> getAllTenants(@PathVariable(value = "active") boolean active) {
		return tenanatServiceImpl.getAllTenants(active);
	}

	@CrossOrigin
	@GetMapping("/tenant/{tenantId}")
	public TenantDTO getTenant(@PathVariable("tenantId") Integer tenantId) {
		return tenanatServiceImpl.getTenantDTOById(tenantId);
	}

	@CrossOrigin
	@PostMapping("/createTenant")
	public String createTenant(@RequestBody TenantDTO tenantDTO) {
		return tenanatServiceImpl.createTenant(tenantDTO);
	}

	@CrossOrigin
	@DeleteMapping("/deleteTenant/{tenantId}")
	public String deleteTenant(@PathVariable("tenantId") Integer tenantId) {
		return tenanatServiceImpl.deleteTenant(tenantId);

	}

	@CrossOrigin
	@PostMapping("/updateTenant")
	public String updateTenant(@RequestBody TenantDTO tenantDto) {
		return tenanatServiceImpl.updateTenant(tenantDto);

	}

	@CrossOrigin
	@PostMapping("/assignContriesToTenant")
	public TenantDTO assignCountriesToTenat(@RequestBody Map<String, Object> hashMap) {
		return tenanatServiceImpl.assignCountriesToTenant(hashMap);
	}

	// implementation pending
	@CrossOrigin
	@PostMapping("/removeCountriesFromTenant")
	public TenantDTO removeCountriesFromTenant(@RequestBody Map<String, Object> hashMap) {
		return null;
	}
}
