package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.AlertDataDTO;
import net.atos.iot.service.AlertDataService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AlertDataController {

	@Autowired
	private AlertDataService alertDataService;

	@CrossOrigin
	@GetMapping("/getAllAlertData")
	public List<AlertDataDTO> getAlertData() {
		List<AlertDataDTO> alertData = alertDataService.getAllAlertData();
		return alertData;
	}

	@CrossOrigin
	@GetMapping("/getTotalDeviceCount")
	public String getTotalDeviceCount() {
		List<AlertDataDTO> alertData = alertDataService.getAllAlertData();
		List<AlertDataDTO> alertNormalData = alertDataService
				.getAlertDataByLevel("NORMAL");
		int toltaDevice = alertData.size();
		int normalDevice = alertNormalData.size();
		int otherDevice = toltaDevice - normalDevice;
		String strReturn = "{\"totalDevice=\":" + toltaDevice
				+ ",\"normalDevice=\":" + normalDevice + ",\"otherDevice\":"
				+ otherDevice + "}";
		return strReturn;
	}

	@CrossOrigin
	@GetMapping("/getTotalDeviceCountByTenantId/{tenantId}")
	public String getTotalDeviceCountByTenantId(
			@PathVariable("tenantId") final Integer tenantId) {
		List<AlertDataDTO> alertData = alertDataService
				.getAllAlertDataByTenantId(tenantId);
		List<AlertDataDTO> alertNormalData = alertDataService
				.getAllDataByLevelAndTenantId("NORMAL", tenantId);
		int toltaDevice = alertData.size();
		int normalDevice = alertNormalData.size();
		int otherDevice = toltaDevice - normalDevice;
		String strReturn = "{\"totalDevice=\":" + toltaDevice
				+ ",\"normalDevice=\":" + normalDevice + ",\"otherDevice\":"
				+ otherDevice + "}";
		return strReturn;
	}

	@CrossOrigin
	@GetMapping("/getAllAlertDataByTenantId/{tenantId}")
	public List<AlertDataDTO> getAllAlertDataByTenantId(
			@PathVariable("tenantId") final Integer tenantId) {
		List<AlertDataDTO> alertData = alertDataService
				.getAllAlertDataByTenantId(tenantId);
		return alertData;
	}

	@CrossOrigin
	@GetMapping("/getAllDistinctAlertType")
	public List<String> getAllDistinctAlertType() {
		return alertDataService.getAllDistinctAlertType();
	}

	@CrossOrigin
	@PostMapping("/getAlertData/{deviceId}")
	public String getAlertData(@PathVariable("deviceId") final String deviceId,
			@RequestBody(required = false) String filterData) {
		String alertData = alertDataService.getAlertData(deviceId,
				filterData);
		return alertData;
	}

	@CrossOrigin
	@PostMapping("/getAlertsDashBoard/{tenantId}")
	public String getAlertsDashBoard(
			@PathVariable("tenantId") final Integer tenantId,
			@RequestBody(required = false) String filterData) {
		return alertDataService.createAlertDataBashBoard(tenantId, filterData);

	}

}
