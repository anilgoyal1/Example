package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.RegionDTO;
import net.atos.iot.service.RegionService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class is used to handle the rest services related to Region.
 * 
 * @author a602834
 *
 */
@RestController
public class RegionController {

	private static final Logger logger = Logger
			.getLogger(RegionController.class);

	@Autowired
	@Qualifier(value = "regionServiceImpl")
	private RegionService regionService;

	/**
	 * This method is used to get the region list
	 * 
	 * @return list of RegionDTO
	 */
	@CrossOrigin
	@GetMapping(value = "/regionRetreive")
	public List<RegionDTO> getAllRegionList() {
		List<RegionDTO> alregion = regionService.getRegions();
		return alregion;
	}

	/**
	 * This method is used to save region.
	 * 
	 * @param region
	 * @return boolean value.
	 */
	@CrossOrigin
	@PostMapping(value = "/saveRegion")
	public String saveRegion(@RequestBody RegionDTO region) {
		return regionService.saveRegions(region);
	}

	/**
	 * This method is used to delete region.
	 * 
	 * @param regionDto
	 * @return deleted Region.
	 */
	@CrossOrigin
	@PostMapping(value = "/deleteRegion/{regionCode}")
	public String deleteRegion(@PathVariable("regionCode") String regionCode) {
		return regionService.deleteRegion(regionCode);

	}
	@CrossOrigin
	@GetMapping(value = "/getRegionByRegionCode/{regionCode}")
	public RegionDTO getRegionByRegionCode(
			@PathVariable("regionCode") final String regionCode) {
		return regionService.getRegionByRegionCode(regionCode);
	}

	@CrossOrigin
	@PostMapping(value = "/updateRegion")
	public String updateRegion(@RequestBody RegionDTO regionDto) {
		return regionService.updateRegion(regionDto);
	}
}
