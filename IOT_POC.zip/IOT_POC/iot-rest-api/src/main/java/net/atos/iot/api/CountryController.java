package net.atos.iot.api;

import java.util.List;
import java.util.Map;

import net.atos.iot.dto.CountryDTO;
import net.atos.iot.service.CountryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class CountryController {

	@Autowired
	@Qualifier(value = "countryServiceImpl")
	private CountryService countryService;

	@CrossOrigin
	@RequestMapping(value = "/countries/{active}", method = RequestMethod.GET)
	public @ResponseBody List<CountryDTO> getAllCountryList(
			@PathVariable(value = "active") boolean active) {
		List<CountryDTO> alcountry = countryService.getCountries(active);
		return alcountry;
	}

	@CrossOrigin
	@RequestMapping(value = "/country/{countryId}", method = RequestMethod.GET)
	public @ResponseBody CountryDTO getCountry(
			@PathVariable("countryId") final int countryId) {
		CountryDTO country = countryService.getCountryByCountryId(countryId);
		return country;
	}

	@CrossOrigin
	@RequestMapping(value = "/saveCountry", method = RequestMethod.POST)
	public @ResponseBody String saveCountry(@RequestBody CountryDTO country) {
		return countryService.saveCountry(country);
	}

	@CrossOrigin
	@RequestMapping(value = "/deleteCountry/{countryId}", method = RequestMethod.DELETE)
	public @ResponseBody String deleteCountry(
			@PathVariable("countryId") final int countryId) {
		return countryService.deleteCountry(countryId);
	}

	// testing pending
	@CrossOrigin
	@RequestMapping(value = "/updateCountry", method = RequestMethod.POST)
	public @ResponseBody String updateByTenantIdAndCountryCode(
			@RequestBody CountryDTO countryDTO) {
		return countryService.updateCountry(countryDTO);
	}

	@CrossOrigin
	@PostMapping("/assignRegionsToCountry")
	public @ResponseBody Integer assignRegionsToCountry(
			@RequestBody Map<String, Object> hashMap) {
		return countryService.assignRegionsToCountry(hashMap);
	}

	// implementation pending
	@CrossOrigin
	@PostMapping("/removeRegionsFromContries")
	public CountryDTO removeRegionsFromContries(
			@RequestBody Map<String, Object> hashMap) {
		return null;
	}

}
