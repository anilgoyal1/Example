package net.atos.iot.api;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.GPSSensorDataDTO;
import net.atos.iot.dto.SensorDataDTO;
import net.atos.iot.dto.TripMasterDTO;
import net.atos.iot.entity.DeviceMaster;
import net.atos.iot.entity.GPSSensorData;
import net.atos.iot.entity.Ticket;
import net.atos.iot.repository.DeviceMasterRepository;
import net.atos.iot.repository.DeviceStatusMasterRepository;
import net.atos.iot.repository.TicketRepository;
import net.atos.iot.service.AlertDataService;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.GPSSensorDataService;
import net.atos.iot.service.SensorDataService;
import net.atos.iot.service.TicketService;
import net.atos.iot.service.TripMasterService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.IotConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

@EnableScheduling
@Component
public class Scheduler {

	private static final Logger log = LoggerFactory.getLogger(Scheduler.class);

	@Value("${spring.rabbitmq.directExchangeName}")
	private String EXCHANGE_NAME;

	@Value("${spring.rabbitmq.host}")
	private String QUEUE_HOST;

	@Value("${spring.rabbitmq.port}")
	private Integer port;

	@Value("${spring.rabbitmq.username}")
	private String username;

	@Value("${spring.rabbitmq.password}")
	private String password;

	@Value("${sensorDataQueueName}")
	private String sensorDataQueueName;

	@Value("${alertDataQueueName}")
	private String alertDataQueueName;

	@Value("${technicalAlertQueueName}")
	private String technicalAlertQueueName;

	@Value("${EDGE_GATEWAY_HARDWARE_DAMAGE}")
	private String EDGE_GATEWAY_HARDWARE_DAMAGE;

	@Autowired
	@Qualifier(value = "deviceMasterServiceImpl")
	private DeviceMasterService deviceServiceImpl;

	@Autowired
	private AlertDataService alertDataService;

	@Autowired
	private SensorDataService sensorDataService;

	@Autowired
	private GPSSensorDataService gpsSensorDataServiceImpl;

	@Autowired
	private DeviceMasterRepository deviceMasterRepository;

	@Autowired
	private TicketService ticketServiceImpl;

	@Autowired
	private TicketRepository ticketDao;

	@Autowired
	private DeviceMasterRepository deviceMasterDao;

	@Autowired
	private DeviceStatusMasterRepository deviceStatusMasterDao;

	@Autowired
	private TripMasterService tripMasterService;

	@Autowired
	private GPSSensorDataService gpsSensorDataService;

	@Scheduled(fixedDelay = 900000)
	public void checkDeviceActivity() {
		System.out.println("checkDeviceActivity Schedular started");
		try {
			String[] deviceStasusToIgnore = { IotConstants.NewDeviceStatus,
					IotConstants.deadDeviceStatus,
					IotConstants.RejectedDeviceStatus };
			List<String> devieStatusListToIgnore = Arrays
					.asList(deviceStasusToIgnore);
			List<DeviceMaster> lstDeviceMstDto = deviceMasterRepository
					.findAllDeviceWhereStatusNotIn(devieStatusListToIgnore);
			
			Date fromDate = new Date();
			Date toDate = new Date();
			fromDate = DateUtil.convertDateAndTimeToBeginingOfDate(fromDate);
			toDate = DateUtil.convertDateAndTimeToEndOfDate(toDate);
			// log.info("From Date ::" + fromDate + "::ToDate::" + toDate);
			List<SensorDataDTO> sensorDataList = null;
			List<GPSSensorDataDTO> gpsSensorDataList = null;
			SimpleDateFormat format = new SimpleDateFormat(IotConstants.ISODATE);
			String currentTime = format.format(new Date());
			boolean createTicket = false;
			boolean skipOtherCheck = false;
			String json = null;
			if (lstDeviceMstDto != null) {
				for (DeviceMaster deviceMstDTO : lstDeviceMstDto) {
					if (deviceMstDTO.getDeviceStatusMaster() != null) {
						if (deviceMstDTO.getDeviceStatusMaster() != null) {
							String deviceStatus = deviceMstDTO
									.getDeviceStatusMaster().getStatusName();
							json = "{\"DeviceId\":\"#DeviceId#\",\"Simulated\":\"1\",\"Temperature\": 0.0,\"Humidity\": 0.0,\"ReceivedTime\":\"#ReceivedTime#\",\"Description\":\"Data not received from the device\",\"AlertType\":\""
									+ EDGE_GATEWAY_HARDWARE_DAMAGE + "\"}";
							String strDeviceId = deviceMstDTO.getDeviceId().trim();
							
							sensorDataList = sensorDataService
									.getSensorDataByCreatedDateAndDeviceId(
											strDeviceId, fromDate, toDate);
							gpsSensorDataList = gpsSensorDataServiceImpl
									.getGPSSensorDataByCreatedDateAndDeviceId(
											strDeviceId, fromDate, toDate);
							if (sensorDataList != null
									&& sensorDataList.size() > 0) {
								SensorDataDTO sensorDataDTO = sensorDataList
										.get(0);
								String sensorLastTime = format
										.format(sensorDataDTO.getCreatedDate());

								if (checkDateDifferece(currentTime,
										sensorLastTime)) {
									createTicket = true;
								} else {
									createTicket = false;
									skipOtherCheck = true;
								}
							} else {
								createTicket = true;
							}
							if (!skipOtherCheck) {
								if (createTicket && gpsSensorDataList != null
										&& gpsSensorDataList.size() > 0) {
									GPSSensorDataDTO gpsSensorData = gpsSensorDataList
											.get(0);
									String gpsSensorDateTime = format
											.format(gpsSensorData
													.getCreatedDate());
									if (checkDateDifferece(currentTime,
											gpsSensorDateTime)) {
										createTicket = true;
									} else {
										createTicket = false;
										skipOtherCheck = true;
									}
								} else {
									createTicket = true;
								}
							}

							if (createTicket
									&& !IotConstants.PROVISIONED_DEVICE_STATUS
											.equalsIgnoreCase(deviceStatus)) {
								json = json
										.replace("#DeviceId#", strDeviceId)
										.replace(
												"#ReceivedTime#",
												DateUtil.convertDateToDateISODateString(new Date()));
								trasnferDataToQueue(json);
							} else {
								if (!IotConstants.liveDeviceStatus
										.equalsIgnoreCase(deviceStatus)) {
									if((sensorDataList!=null && !sensorDataList.isEmpty())||(gpsSensorDataList!=null && !gpsSensorDataList.isEmpty())){
									closeTicketAndChangeDeviceStatus(strDeviceId);
									}
								}
							}
							sensorDataList = null;
							gpsSensorDataList = null;
							skipOtherCheck = false;

						}
					}
				}
			}
		} catch (Exception e) {
			log.error("scheduler Error", e);
		}
		System.out.println("checkDeviceActivity Schedular started");


	}

	private void trasnferDataToQueue(String json) {
		Channel channel = null;
		Connection connection = null;
		try {
			// log.info(" in connection of queue ::"+json);
			ConnectionFactory factory = new ConnectionFactory();
			factory.setHost(QUEUE_HOST);
			factory.setPort(port);
			factory.setPassword(password);
			factory.setUsername(username);
			connection = factory.newConnection();
			channel = connection.createChannel();
			// log.info(" connection done");
			// System.out.println(" connection done");
			channel.exchangeDeclare(EXCHANGE_NAME, "direct", true);
			channel.queueBind(technicalAlertQueueName, EXCHANGE_NAME,
					"techalerts.*.*");
			channel.basicPublish(EXCHANGE_NAME, "techalerts.*.*", null,
					json.getBytes());
			// System.out.println(" [x] Sent '" + json + "'");
			// log.info(" [x] Sent '" + json + "'");

		} catch (Exception e) {
			log.error("error ", e);
		} finally {
			try {
				channel.close();
				connection.close();
			} catch (Exception e) {
				log.error("error ", e);
			}

		}

	}

	private boolean checkDateDifferece(String fromDate, String toDate) {
		SimpleDateFormat format = new SimpleDateFormat(IotConstants.ISODATE);
		Date d1 = null;
		Date d2 = null;
		boolean isDiff = false;
		try {
			d1 = format.parse(fromDate);
			d2 = format.parse(toDate);
			long diff = d1.getTime() - d2.getTime();
			Long diffMinutes = diff / (60 * 1000) % 60;
			// log.info("time difference " + diffMinutes);
			if (diffMinutes >= 15L) {
				isDiff = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("", e);
		}
		return isDiff;

	}

	@Scheduled(fixedDelay = 900000)
	public void checkTicketViolation() {
		try {
			// log.info("checkActiveTicket");
			List<Ticket> ticketList = ticketServiceImpl.getActiveTicketEntity();
			if (ticketList != null && ticketList.size() > 0) {
				for (Ticket ticket : ticketList) {
					if (ticket.getTicketStatus() != null
							&& !ticket.getTicketStatus().equalsIgnoreCase(
									"Escalated")) {
						if (checkTicketDateDifferece(new Date(),
								ticket.getSlaTimeFrame())) {
							ticket.setTicketStatus("Escalated");
							ticket.setModifiedDate(new Date());
							ticket.setModifiedBy("SYSTEM");
							ticketServiceImpl.saveTicket(ticket);
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("e", e);
		}
	}

	@Scheduled(fixedDelay = 600000)
	public void checkTripRunningStatus() {
		try {
			List<TripMasterDTO> tripMasterDtos = tripMasterService
					.findAllTripsByTripStatus(IotConstants.TRIP_STARTED);
			if (tripMasterDtos != null && !tripMasterDtos.isEmpty()) {
				GPSSensorData gpsSensorData = null;
				Date createdDate = null;
				long timeDiffference = 0;
				for (TripMasterDTO tripMasterDTO : tripMasterDtos) {
					gpsSensorData = gpsSensorDataService
							.getGPSSensorDataByTripId(tripMasterDTO.getTripId());
					if (gpsSensorData != null) {
						createdDate = gpsSensorData.getCreatedDate();
						if (createdDate != null) {
							timeDiffference = DateUtil
									.differenceInMinute(createdDate,
											new Date());
							if (timeDiffference >= 10) {
								gpsSensorData.setTripStatus(IotConstants.ENDED);
								gpsSensorDataService
										.SaveGpsSensorData(gpsSensorData);
								tripMasterService.endTrip(tripMasterDTO
										.getTripId());
							}
						}
					}
				}

			}
		} catch (Exception e) {
			log.error("e", e);
		}
	}

	private void closeTicketAndChangeDeviceStatus(String strDeviceId) {
		List<Ticket> ticketDataList = null;
		Ticket tempTicket = null;
		try {
			List<Ticket> autoClosureTicketList=new ArrayList<Ticket>();
			List<Ticket> edgeGatewayNotRechableTickets = ticketServiceImpl
					.getOpenTicketByDeviceIdAndTicketType(strDeviceId,
							"EDGE_GATEWAY_NOT_REACHABLE");
			List<Ticket> sensorNotRechableTickets = ticketServiceImpl
					.getOpenTicketByDeviceIdAndTicketType(strDeviceId,
							IotConstants.SENSOR_NOT_REACHABLE);
			if(edgeGatewayNotRechableTickets!=null && edgeGatewayNotRechableTickets.size()>0){
				autoClosureTicketList.addAll(edgeGatewayNotRechableTickets);
			}
			if(sensorNotRechableTickets!=null && sensorNotRechableTickets.size()>0){
				autoClosureTicketList.addAll(sensorNotRechableTickets);
			}
			
			if (autoClosureTicketList != null) {
				ticketDataList = new ArrayList<Ticket>();
				for (Ticket ticket : autoClosureTicketList) {
					tempTicket = ticket;
					tempTicket.setCloseDate(new Date());
					tempTicket.setClosedBy("SYSTEM");
					tempTicket.setTicketStatus(IotConstants.ticketTypeClose);
					tempTicket.setRootCause("Network Failure");
					ticketDataList.add(tempTicket);
					ticketDao.save(ticketDataList);

				}

			}
			changeDeviceStatusToLive(strDeviceId);
		} catch (Exception e) {
			log.error("e", e);
		}

	}

	private void changeDeviceStatusToLive(String deviceId) {
		try {
			if (deviceId != null) {
				List<String> activeTicketStatus = new ArrayList<String>();
				activeTicketStatus.add(IotConstants.ticketTypeResolved);
				activeTicketStatus.add(IotConstants.ticketTypeClose);
				List<Ticket> activeTicket = ticketDao
						.getTicketsByNotInStatusAndByDeviceId(
								activeTicketStatus, deviceId);
				if (activeTicket != null && !activeTicket.isEmpty()) {
					return;
				}
				deviceServiceImpl.changeDeviceStatus(deviceId,
						IotConstants.liveDeviceStatus);

			}
		} catch (Exception e) {
			log.error("Error", e);
		}

	}

	private boolean checkTicketDateDifferece(Date fromDate, Date toDate) {
		boolean isDiff = false;
		try {
			long diff = fromDate.getTime() - toDate.getTime();
			Long diffMinutes = (diff / (60 * 1000)) % 60;
			if (diffMinutes >= 1) {
				isDiff = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("", e);
		}
		return isDiff;

	}
}
