package net.atos.iot.api;

import java.util.List;

import net.atos.iot.service.DataCleanUpService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataCleanUpController {

	@Autowired
	private DataCleanUpService dataCleanUpService;

	@CrossOrigin
	@GetMapping("/cleanDataByTenantId/{tenantId}")
	public String cleanDataByTenantId(@PathVariable("tenantId") Integer tenantId) {
		return dataCleanUpService.cleanDataByTenantId(tenantId);
	}

	//@CrossOrigin
	//@GetMapping("/cleanAllTenantData")
	public String cleanAllTenantData() {
		return dataCleanUpService.cleanDataForAllTenant();
	}

	@CrossOrigin
	@PostMapping("/cleanAllDataByDeviceIds")
	public String cleanAllDataByDeviceIds(@RequestBody List<String> deviceIds) {
		return dataCleanUpService.cleanAllDataByDeviceIds(deviceIds);
	}
	
	
	
}
