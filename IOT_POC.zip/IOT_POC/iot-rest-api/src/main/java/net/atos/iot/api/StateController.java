package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.StateDTO;
import net.atos.iot.service.StateService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * This class is used to handle the rest services related to State.
 * 
 * @author a602834
 *
 */
@RestController
public class StateController {

	private static final Logger LOGGER = Logger
			.getLogger(StateController.class);

	@Autowired
	@Qualifier(value = "stateServiceImpl")
	private StateService stateService;

	@CrossOrigin
	@GetMapping(value = "/stateRetreive/{active}")
	public List<StateDTO> getAllStateList(@PathVariable("active") boolean active) {
		List<StateDTO> alstate = stateService.getStates(active);
		return alstate;
	}

	@CrossOrigin
	@PostMapping(value = "/saveState")
	public String saveState(@RequestBody StateDTO state) {
		return stateService.saveStates(state);

	}

	@CrossOrigin
	@PostMapping(value = "/updateState")
	public String updateState(@RequestBody StateDTO state) {
		return stateService.updateState(state);

	}

	@CrossOrigin
	@GetMapping(value = "/deleteState/{stateId}")
	public String deleteSate(@PathVariable("stateId") Integer stateId) {
		return stateService.deleteState(stateId);

	}

	@CrossOrigin
	@GetMapping(value = "/getStateByStateByStateId/{stateId}")
	public StateDTO getStateByStateCode(
			@PathVariable("stateId") final Integer stateId) {
		return stateService.getStateByStateId(stateId);
	}

}
