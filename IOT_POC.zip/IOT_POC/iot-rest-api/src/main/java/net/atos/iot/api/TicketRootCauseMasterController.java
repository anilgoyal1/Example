package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.TicketRootCauseDTO;
import net.atos.iot.service.TicketRootCauseMasterService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TicketRootCauseMasterController {

	@Autowired
	private TicketRootCauseMasterService ticketRootCauseMasterService;
	
	@CrossOrigin
	@RequestMapping(value = "/addTicketRootCause", method = RequestMethod.POST)
	public @ResponseBody String endTrip(@RequestBody TicketRootCauseDTO ticketRootCauseDTO) {
		return ticketRootCauseMasterService.addTicketRootCause(ticketRootCauseDTO);
	}

	@CrossOrigin
	@RequestMapping(value = "/getAllTicketRootCause", method = RequestMethod.GET)
	public @ResponseBody List<TicketRootCauseDTO> getAllTicketRootCause() {
		return ticketRootCauseMasterService.getAllRootCauses();
	}
	@CrossOrigin
	@RequestMapping(value = "/deleteRootCauseById/{id}", method = RequestMethod.GET)
	public @ResponseBody String deleteRootCauseById(@PathVariable("id") Integer id) {
		return ticketRootCauseMasterService.deleteTicketRootCauase(id);
	}
}
