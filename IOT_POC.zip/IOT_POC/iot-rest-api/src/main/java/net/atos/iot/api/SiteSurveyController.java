package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.SiteSurveyDTO;
import net.atos.iot.service.SiteSurveyService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SiteSurveyController {

	@Autowired
	SiteSurveyService siteSurvey;

	@CrossOrigin
	@GetMapping("/getSiteSurveyByTenantId/{tenantId}")
	public List<SiteSurveyDTO> getSiteSurveyByTenantId(
			@PathVariable(value = "tenantId") Integer tenantId) {
		return siteSurvey.listSiteSurveyByTenantId(tenantId);
	}

	@CrossOrigin
	@GetMapping("/getAllSiteSurvey")
	public List<SiteSurveyDTO> getAllSiteSurvey() {
		return siteSurvey.listSiteSurveyDTO();
	}

	@CrossOrigin
	@PostMapping("/completeSiteSurvey")
	public String completeSiteSurvey(@RequestBody SiteSurveyDTO siteSurveyDTO) {
		return siteSurvey.completeSiteSurvey(siteSurveyDTO);
	}

}
