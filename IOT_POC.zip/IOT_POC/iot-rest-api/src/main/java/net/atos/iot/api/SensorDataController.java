package net.atos.iot.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import net.atos.iot.dto.SensorDataDTO;
import net.atos.iot.service.SensorDataService;

@RestController
public class SensorDataController {

	@Autowired
	private SensorDataService sensorDataService;

	@CrossOrigin
	@PostMapping("/getSensorData/{deviceId}")
	public List<SensorDataDTO> getSensorData(
			@PathVariable("deviceId") final String deviceId,
			@RequestBody(required = false) String filterData) {
		List<SensorDataDTO> sensorData = sensorDataService
				.getAllSensorDataByDeviceId(deviceId, filterData);
		return sensorData;
	}

	

	@CrossOrigin
	@GetMapping("/getSensorDataMonitoringByTenantId/{tenantId}")
	public List<SensorDataDTO> getSensorDataMonitoringByTenantId(
			@PathVariable("tenantId") final Integer tenantId) {
		return sensorDataService.getSensorDataMonitoringByTenantId(tenantId);
	}
	
	
	@CrossOrigin
	@GetMapping("/getSensorDataMonitoringByDeviceId/{deviceId}")
	public SensorDataDTO getSensorDataMonitoringByDeviceId(
			@PathVariable("deviceId") final String deviceId) {
		return sensorDataService.getSensorDataMonitoringByDeviceId(deviceId);
	}
	
	

	// UI specific webservice as needed by sonam and sumeet sir

	@CrossOrigin
	@PostMapping("/getSensorDataForGraphByTenantId/{tenantId}")
	public String getSensorDataForGraphByTenantId(
			@PathVariable("tenantId") final Integer tenantId,
			@RequestBody(required = false) String filterData) {
		String sensorData = sensorDataService.getSensorDataGraphByTenantId(
				tenantId, filterData);
		return sensorData;
	}

	@CrossOrigin
	@PostMapping("/getSensorDataGraphByDeviceId/{deviceId}")
	public String getSensorDataGraphByDeviceId(
			@PathVariable("deviceId") final String deviceId,
			@RequestBody(required = false) String filterData) {
		String sensorData = sensorDataService.getSensorDataGraphByDeviceId(
				deviceId, filterData);
		return sensorData;
	}
	
	
	@CrossOrigin
	@PostMapping("/getSensorDataGraphByDeviceIdNew/{deviceId}")
	public String getSensorDataGraphByDeviceIdNew(
			@PathVariable("deviceId") final String deviceId,
			@RequestBody(required = false) String filterData) {
		String sensorData = sensorDataService.getSensorDataGraphByDeviceIdNew(
				deviceId, filterData);
		return sensorData;
	}

	

}
