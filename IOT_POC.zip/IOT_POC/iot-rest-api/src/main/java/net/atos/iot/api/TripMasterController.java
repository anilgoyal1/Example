package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.TripMasterDTO;
import net.atos.iot.service.TripMasterService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class TripMasterController {

	@Autowired
	TripMasterService tripMasterService;

	@CrossOrigin
	@RequestMapping(value = "/startTrip", method = RequestMethod.POST)
	public @ResponseBody Long startTrip(@RequestBody TripMasterDTO tripMasterDTO) {
		return tripMasterService.startTrip(tripMasterDTO);
	}

	@CrossOrigin
	@RequestMapping(value = "/endTrip/{tripId}", method = RequestMethod.GET)
	public @ResponseBody String endTrip(@PathVariable Long tripId) {
		return tripMasterService.endTrip(tripId);
	}

	@CrossOrigin
	@RequestMapping(value = "/getTripByTripId/{tripId}", method = RequestMethod.GET)
	public @ResponseBody TripMasterDTO getTripByTripId(@PathVariable Long tripId) {
		return tripMasterService.getTripByTripId(tripId);
	}

	@CrossOrigin
	@RequestMapping(value = "/getAllTrips", method = RequestMethod.GET)
	public @ResponseBody List<TripMasterDTO> getAllTrips(
			@PathVariable Long tripId) {
		return tripMasterService.getAllTrips();
	}
}
