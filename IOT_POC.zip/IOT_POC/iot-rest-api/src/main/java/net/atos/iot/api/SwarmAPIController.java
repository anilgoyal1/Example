package net.atos.iot.api;

import net.atos.iot.service.EdgeGatewaySimulationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SwarmAPIController {

	@Autowired
	EdgeGatewaySimulationService edgeGatewaySimulationService;

	@CrossOrigin
	@GetMapping("/startSwarmContainerSimulation/{simulationName}")
	public String startSwarmContainerSimulation(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.startSwarmContainerBySimulationName(simulationName);

	}

	@CrossOrigin
	@GetMapping("/getSwarmContainerSimulationStatus/{simulationName}")
	public String getSwarmContainerSimulationStatus(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.getSwarmContainerSimulationStatusByName(simulationName);

	}

	/**
	 * This method delete the swarm Container
	 * 
	 * @param simulationName
	 * @return
	 */
	@CrossOrigin
	@GetMapping("/stopSwarmContainerSimulation/{simulationName}")
	public String stopSwarmContainerSimulation(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.stopSwarmContainerBySimulationName(simulationName);

	}

}
