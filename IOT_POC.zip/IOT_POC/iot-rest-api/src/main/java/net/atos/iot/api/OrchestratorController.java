package net.atos.iot.api;

import net.atos.iot.dto.CreateOrchestratedDeviceRequestDTO;
import net.atos.iot.service.OrchestratorService;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrchestratorController {

	private static final Logger logger = Logger
			.getLogger(OrchestratorController.class);

	@Autowired
	OrchestratorService orchestratorServiceImpl;

	@CrossOrigin
	@PostMapping("/createSimulatedDevices")
	public String createSimulatedDevices(
			@RequestBody CreateOrchestratedDeviceRequestDTO createOrchestratedDeviceRequestDTO) {
		String response = IotConstants.FAILURE;
		try {
			return orchestratorServiceImpl
					.createDevice(createOrchestratedDeviceRequestDTO);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return response;
	}
}
