package net.atos.iot.api;

import net.atos.iot.service.EdgeGatewaySimulationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DockerContainer {

	@Autowired
	EdgeGatewaySimulationService edgeGatewaySimulationService;

	@CrossOrigin
	@PostMapping("/createtDockerContainerBySimulationName/{simulationName}")
	public String createtDockerContainer(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.createtDockerContainer(simulationName);
	}

	@CrossOrigin
	@PostMapping("/createDockerContainerByDeviceId/{deviceId}")
	public String createDockerContainerByDeviceId(
			@PathVariable("deviceId") String deviceId) {
		return edgeGatewaySimulationService
				.createDockerContainerByDeviceId(deviceId);
	}

	@CrossOrigin
	@PostMapping("/startDockerContainerBySimulationName/{simulationName}")
	public String startDockerContainerByCotainerName(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.startDockerContainerByCotainerName(simulationName);

	}

	@CrossOrigin
	@PostMapping("/startDockerContainerByByDeviceId/{deviceId}")
	public String startDockerContainerByByDeviceId(
			@PathVariable("deviceId") String deviceId) {
		return edgeGatewaySimulationService
				.startDockerContainerByByDeviceId(deviceId);

	}

	@CrossOrigin
	@PostMapping("/stopDockerContainerBySimulationName/{simulationName}")
	public String stopDockerContainerByContainerName(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.stopDockerContainerByContainerName(simulationName);

	}

	@CrossOrigin
	@PostMapping("/stopDockerContainerByByDeviceId/{deviceId}")
	public String stopDockerContainerByByDeviceId(
			@PathVariable("deviceId") String deviceId) {
		return edgeGatewaySimulationService
				.stopDockerContainerByByDeviceId(deviceId);
	}

	@CrossOrigin
	@PostMapping("/deleteDockerContainerBySimulationName/{simulationName}")
	public String deleteDockerContainerBySimulationName(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.deleteDockerContainerBySimulationName(simulationName);

	}

	@CrossOrigin
	@PostMapping("/deleteDockerContainerByByDeviceId/{deviceId}")
	public String deleteDockerContainerByByDeviceId(
			@PathVariable("deviceId") String deviceId) {
		return edgeGatewaySimulationService
				.deleteDockerContainerByByDeviceId(deviceId);

	}

	/**
	 * Implementation part is pending
	 * 
	 * @param simulationName
	 * @return
	 */
	@CrossOrigin
	@GetMapping("/getDockerContainerSimulationStatus/{simulationName}")
	public String getDockerContainerSimulationStatus(
			@PathVariable("simulationName") String simulationName) {
		return edgeGatewaySimulationService
				.getDockerContainerSimulationStatus(simulationName);

	}
	
	
	/**
	 * Implementation part is pending
	 * 
	 * @param simulationName
	 * @return
	 */
	@CrossOrigin
	@GetMapping("/getDockerContainerStatusByDeviceId/{deviceId}")
	public String getDockerContainerStatusByDeviceId(
			@PathVariable("deviceId") String deviceId) {
		return edgeGatewaySimulationService
				.getDockerContainerStatusByDeviceId(deviceId);

	}

}
