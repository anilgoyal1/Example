package net.atos.iot.api;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IOTTestController {

	private static final Logger LOGGER = Logger
			.getLogger(IOTTestController.class);

	
	
	@CrossOrigin
	@GetMapping(value = "/testRest")
	public String testRest() {
		return performFunction(
				"http://115.112.94.57:8888/iot-mwp/getSensorDeviceStatusByTenantId/1",
				"GET", "");
	}

	public String performFunction(String uri, String method, String inputJSONStr) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String response = null;
		StringBuilder responsePost = new StringBuilder();
		System.getProperties().put("http.proxyHost", "10.90.35.2");
		System.getProperties().put("http.proxyPort", "8080");
		HttpURLConnection conn = null;
		try {
			URL url = new URL(uri);
			conn = (HttpURLConnection) url.openConnection();
			if ("POST".equalsIgnoreCase(method)) {
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				OutputStream os = conn.getOutputStream();
				os.write(inputJSONStr.getBytes());
				os.flush();
				if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
					throw new RuntimeException("Failed : HTTP error code:"
							+ conn.getResponseCode());
				}
				BufferedReader br = new BufferedReader(new InputStreamReader(
						conn.getInputStream()));
				String output;

				// System.out.println("Output from Server...................\n");
				while ((output = br.readLine()) != null) {
					// System.out.println(output);
					responsePost.append(output);
				}
				conn.disconnect();
				response = responsePost.toString();
			} else if ("GET".equalsIgnoreCase(method)) {
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/json");

				String output;
				StringBuilder strobj = new StringBuilder();

				BufferedReader br = new BufferedReader(new InputStreamReader(
						conn.getInputStream()));
				while ((output = br.readLine()) != null) {
					strobj.append(output);
				}
				if (strobj != null) {
					response = strobj.toString();
				}

				conn.disconnect();
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			System.getProperties().remove("http.proxyHost");
			System.getProperties().remove("http.proxyPort");
			System.getProperties().remove("http.proxyUser");
			System.getProperties().remove("http.proxyPassword");

			if (conn != null) {
				conn.disconnect();
			}
		}
		return response;
	}
}
