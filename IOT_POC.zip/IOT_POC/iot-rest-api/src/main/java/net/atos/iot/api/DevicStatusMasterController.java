package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.DeviceStatusMasterDTO;
import net.atos.iot.service.DeviceStatusMasterService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DevicStatusMasterController {

	@Autowired
	private DeviceStatusMasterService deviceStatusMasterService;

	@CrossOrigin
	@GetMapping(value = "/getAllDeviceStatusMaster")
	public List<DeviceStatusMasterDTO> getAllDeviceStatusMaster() {
		List<DeviceStatusMasterDTO> alDevice = deviceStatusMasterService
				.findAllDeviceStatusMaster();
		return alDevice;
	}

	@CrossOrigin
	@GetMapping(value = "/getDeviceStatusMasterById/{id}")
	public DeviceStatusMasterDTO getDeviceStatusMaster(
			@PathVariable("id") final Integer id) {
		DeviceStatusMasterDTO deviceStatusMasterDTO = deviceStatusMasterService
				.findDeviceStatusMasterById(id);
		return deviceStatusMasterDTO;
	}

	@CrossOrigin
	@GetMapping(value = "/getDeviceStatusMasterIdByName/{statusName}")
	public DeviceStatusMasterDTO getDeviceStatusMasterIdByName(
			@PathVariable("statusName") final String statusName) {
		DeviceStatusMasterDTO alDevice = deviceStatusMasterService
				.getDeviceStatusMasterIdByName(statusName);
		return alDevice;
	}
	
	
	@CrossOrigin
	@PostMapping(value = "/addDeviceStatusMaster")
	public String addDeviceStatusMaster(
			@RequestBody  DeviceStatusMasterDTO deviceStatusMasterDTO) {
		String response = deviceStatusMasterService
				.createDeviceStatusMaster(deviceStatusMasterDTO);
		return response;
	}
}
