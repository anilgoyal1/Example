
package net.atos.iot.api;

import java.util.List;

import net.atos.iot.dto.DeviceMasterDTO;
import net.atos.iot.dto.DeviceMasterDTOForApp;
import net.atos.iot.dto.DeviceRuleConfigDTO;
import net.atos.iot.service.DeviceMasterService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeviceController {

	private static final Logger LOGGER = Logger
			.getLogger(DeviceController.class);

	@Autowired
	@Qualifier(value = "deviceMasterServiceImpl")
	private DeviceMasterService deviceServiceImpl;

	@CrossOrigin
	@GetMapping(value = "/getAllDevice")
	public List<DeviceMasterDTO> getAllDevice() {
		LOGGER.info("DeviceController getAllDevice ");
		List<DeviceMasterDTO> alDevice = deviceServiceImpl.listOfDeviceMaster();
		return alDevice;
	}

	@CrossOrigin
	@GetMapping(value = "/getDeviceByDeviceId/{deviceId}")
	public DeviceMasterDTO getDeviceById(
			@PathVariable("deviceId") final String deviceId) {
		return deviceServiceImpl.getDeviceMasterByDeviceId(deviceId);
	}

	@CrossOrigin
	@PostMapping(value = "/createDevice")
	public String createDevice(@RequestBody DeviceMasterDTO deviceMstDTO) {
		return deviceServiceImpl.createDeviceMaster(deviceMstDTO);

	}

	@CrossOrigin
	@PostMapping(value = "/updateDevice")
	public String updateDevice(@RequestBody DeviceMasterDTO deviceMstDTO) {
		return deviceServiceImpl.updateDeviceMaster(deviceMstDTO);

	}

	@CrossOrigin
	@PostMapping(value = "/deleteDevice/{deviceId}")
	public String deleteDevice(@PathVariable("deviceId") final String deviceId) {
		return deviceServiceImpl.deleteDeviceMaster(deviceId);

	}

	@CrossOrigin
	@PostMapping(value = "/BindDeviceWithTenant")
	public String bindDeviceWithTenant(@RequestBody String inputString) {
		return deviceServiceImpl.bindDeviceWithTenant(inputString);

	}

	@CrossOrigin
	@PostMapping(value = "/assignRulesToDevice")
	public String bindDeviceWithRules(
			@RequestBody DeviceRuleConfigDTO deviceRuleConfigDTO) {
		return deviceServiceImpl.bindDeviceWithRules(deviceRuleConfigDTO);

	}

	@CrossOrigin
	@PostMapping(value = "/revokeRulesFromDevice")
	public String revokeRulesFromDevice(
			@RequestBody DeviceRuleConfigDTO deviceRuleConfigDTO) {
		return deviceServiceImpl.revokeRulesFromDevice(deviceRuleConfigDTO);

	}

	@CrossOrigin
	@GetMapping(value = "/getAllDeviceByTenantId/{tenantId}")
	public List<DeviceMasterDTO> getAllDeviceByTenantId(
			@PathVariable("tenantId") final Integer tenantId) {
		LOGGER.info("DeviceController getAllDeviceByTenantId ");
		List<DeviceMasterDTO> alDevice = deviceServiceImpl
				.getAllDeviceByTenantId(tenantId);
		return alDevice;
	}

	@CrossOrigin
	@GetMapping(value = "/getDeviceStatusCountByTenantId/{tenantId}")
	public String getDeviceStatusCountByTenantId(
			@PathVariable("tenantId") final Integer tenantId) {
		LOGGER.info("DeviceController getAllDeviceByTenantId ");
		String alDevice = deviceServiceImpl
				.getDeviceStatusCountByTenantId(tenantId);
		return alDevice;
	}
	
	
	@CrossOrigin
	@GetMapping(value = "/getDeviceListForApp")
	public List<DeviceMasterDTOForApp> getDeviceListForApp() {
		return  deviceServiceImpl
				.getDeviceListForApp();
	}
	
	
	
	

}
