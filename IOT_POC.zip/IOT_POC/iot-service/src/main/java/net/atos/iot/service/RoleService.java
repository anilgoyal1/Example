package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.RoleDTO;
import net.atos.iot.entity.Role;

public interface RoleService {

	String addRole(RoleDTO userRoleDto);

	String deleteRole(int roleId);

	List<RoleDTO> getAllRoleDtos(boolean active);

	RoleDTO getRoleDtoByRoleId(int roleId);

	String updateRole(RoleDTO roleDto);

	Integer getRoleIdByRoleName(String roleName);

	public String getUserIdByTenantIdAndRoleName(Integer tenantId,String roleName);

	Role findRoleByRoleId(int roleId);

}
