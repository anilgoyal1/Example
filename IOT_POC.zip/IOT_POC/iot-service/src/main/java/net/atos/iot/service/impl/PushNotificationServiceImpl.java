package net.atos.iot.service.impl;

import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.PushNotificationService;
import net.atos.iot.util.PushNotificationUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PushNotificationServiceImpl implements PushNotificationService {

	@Autowired
	PushNotificationUtil pushNotificationUtil;

	@Autowired
	DeviceMasterService deviceMasterServiceImpl;

	@Override
	public void sendNotficationByDeviceId(String deviceId,
			String notificationMessage) {
		pushNotificationUtil.sendPushNotification(
				deviceMasterServiceImpl.getTenantIdByDeviceId(deviceId),
				notificationMessage);
	}

	@Override
	public void sendNotificationByTenantId(Integer tenantId,
			String notificationMessage) {
		pushNotificationUtil
				.sendPushNotification(tenantId, notificationMessage);
	}

}
