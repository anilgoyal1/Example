package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.dto.CreateOrchestratedDeviceRequestDTO;
import net.atos.iot.entity.DeviceMaster;
import net.atos.iot.entity.DeviceStatusMaster;
import net.atos.iot.entity.Tenant;
import net.atos.iot.repository.DeviceMasterRepository;
import net.atos.iot.service.DeviceStatusMasterService;
import net.atos.iot.service.OrchestratorService;
import net.atos.iot.service.TenantService;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class OrchestratorServiceImpl implements OrchestratorService {

	private static final Logger logger = Logger
			.getLogger(OrchestratorServiceImpl.class);

	@Value("${simulatedDeviceNameInitialString}")
	private String simulatedDeviceNameInitialString;

	@Autowired
	DeviceMasterRepository deviceMasterDao;

	@Autowired
	TenantService tenantService;

	@Autowired
	DeviceStatusMasterService deviceStatusMasterService;

	// private static final String device_initial_id = "Simulator";

	@Override
	@Transactional
	public String createDevice(CreateOrchestratedDeviceRequestDTO requestDTO) {
		if (requestDTO != null) {
			int numberOfDevices = requestDTO.getNumberOfdevice();
			int tenantId = requestDTO.getTenantId();
			Tenant tenant = tenantService.getTenantByTenantId(tenantId);
			DeviceStatusMaster deviceStatusMaster = deviceStatusMasterService
					.getDeviceStatusMasterByStatusName(IotConstants.PROVISIONED_DEVICE_STATUS);
			if (tenant != null && tenantId > 0) {
				if (numberOfDevices > 0 && tenantId > 0) {
					List<DeviceMaster> deviceMasterList = new ArrayList<DeviceMaster>();
					DeviceMaster deviceMaster = null;
					for (int i = 0; i < numberOfDevices; i++) {
						deviceMaster = new DeviceMaster();
						deviceMaster
								.setDeviceId(simulatedDeviceNameInitialString
										.concat("_")
										.concat(tenant.getTenantName())
										.concat("_").concat(String.valueOf(i)));
						deviceMaster.setActive(true);
						deviceMaster.setDeviceStatusMaster(deviceStatusMaster);
						deviceMaster.setTenant(tenant);
						deviceMaster.setSimulatedDevice(true);
						deviceMaster.setCreatedDate(new Date());
						deviceMaster.setCreatedBy("System");

						deviceMaster.setDeviceType("Simulator");
						deviceMasterList.add(deviceMaster);

					}
					deviceMasterDao.save(deviceMasterList);
					return IotConstants.SUCCESS;
				}
			}
			return "Invalid tenant id ";
		}
		return IotConstants.SUCCESS;
	}

	@Override
	@Transactional
	public String createDeviceWithSimulationId(List<String> deviceIds,
			Integer tenantId) {
		if (deviceIds != null && deviceIds.size() > 0 && tenantId != null
				&& tenantId > 0) {
			DeviceStatusMaster deviceStatusMaster = deviceStatusMasterService
					.getDeviceStatusMasterByStatusName(IotConstants.PROVISIONED_DEVICE_STATUS);
			Tenant tenant = tenantService.getTenantByTenantId(tenantId);
			if (tenant != null && tenant.getTenantId() > 0) {
				List<DeviceMaster> deviceMasterList = new ArrayList<DeviceMaster>();
				DeviceMaster deviceMaster = null;
				for (String deviceId : deviceIds) {
					deviceMaster = new DeviceMaster();
					deviceMaster.setDeviceId(deviceId);
					deviceMaster.setActive(true);
					deviceMaster.setDeviceStatusMaster(deviceStatusMaster);
					deviceMaster.setTenant(tenant);
					deviceMaster.setSimulatedDevice(true);
					deviceMaster.setDeviceType("Simulated");
					deviceMaster
							.setDeviceLocationLatitude(tenant.getLatitude());
					deviceMaster.setDeviceLocationLongitude(tenant
							.getLongitude());
					deviceMasterList.add(deviceMaster);

				}
				deviceMasterDao.save(deviceMasterList);
				return IotConstants.SUCCESS;
			}
			return "Invalid tenant id ";
		}
		return IotConstants.SUCCESS;
	}
}
