package net.atos.iot.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.BranchDTO;
import net.atos.iot.entity.Branch;
import net.atos.iot.entity.District;
import net.atos.iot.repository.BranchRepository;
import net.atos.iot.repository.DistrictRepository;
import net.atos.iot.service.BranchService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 * This is a service class used for branch operations.
 * 
 * @author a602834
 *
 */
@Service
public class BranchServiceImpl implements BranchService {

	private final static Logger logger = Logger
			.getLogger(BranchServiceImpl.class);

	@Autowired
	private BranchRepository branchRepository;

	@Autowired
	private DistrictRepository districtRepository;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Transactional
	public List<BranchDTO> getBranches(boolean active) {
		List<BranchDTO> branchDtos = null;
		try {
			List<Branch> branchList = branchRepository.findAllBranch(active);
			if (branchList != null) {
				BranchDTO branchDto = null;
				branchDtos = new ArrayList<BranchDTO>();
				for (Branch branch : branchList) {
					branchDto = dMapper.map(branch, BranchDTO.class);
					branchDtos.add(branchDto);
				}
			}
		} catch (Exception e) {
			logger.error(e);
		}
		if (branchDtos == null) {
			branchDtos = new ArrayList<BranchDTO>();
		}
		return branchDtos;
	}

	@Override
	public String savebranches(BranchDTO branchDTO) {
		Branch branch = null;
		District district = null;
		try {

			if (branchDTO != null
					&& !StringUtils.isEmpty(branchDTO.getBranchCode())) {

				branch = branchRepository.findByBranchCode(branchDTO
						.getBranchCode());
				if (null == branch) {
					logger.info("No branch exists with branch code creating new branch");
					branch = dMapper.map(branchDTO, Branch.class);
					branch.setCreatedDate(new Timestamp(new Date().getTime()));
					branch.setModifiedDate(new Timestamp(new Date().getTime()));
					if (branchDTO.getDistrict() != null
							&& branchDTO.getDistrict().getDistrictCode() != null
							&& branchDTO.getDistrict().getDistrictCode() > 0) {
						Integer districtCode = branchDTO.getDistrict()
								.getDistrictCode();
						district = districtRepository
								.findDistrictByDistrictCode(districtCode);
						if (district != null) {
							branch.setDistrict(district);
						}

					}
					branch = branchRepository.saveAndFlush(branch);
					return IotConstants.SUCCESS;
				} else {
					return "branch code already Exists";
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
			e.printStackTrace();
		}
		return IotConstants.FAILURE;

	}

	@Override
	public String deleteBranch(Long branchId) {
		Branch branch = branchRepository.findByBranchByBranchId(branchId);
		if (null != branch) {
			branch.setActive(IotConstants.FALSE);
			branch.setModifiedDate((new Timestamp(new Date().getTime())));
			branchRepository.save(branch);
			return IotConstants.SUCCESS;
		}
		return IotConstants.FAILURE;
	}

	@Override
	public BranchDTO getBranchByBranchCode(String branchCode) {
		BranchDTO branchDTO = null;
		try {
			if (!StringUtils.isEmpty(branchCode)) {
				Branch branch = branchRepository.findByBranchCode(branchCode);
				if (branch != null) {
					branchDTO = dMapper.map(branch, BranchDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return branchDTO;
	}

	@Override
	public BranchDTO getBranchByBranchId(Long branchId) {
		BranchDTO branchDTO = null;
		try {
			if (branchId != null && branchId > 0) {
				Branch branch = branchRepository
						.findByBranchByBranchId(branchId);
				if (branch != null) {
					branchDTO = dMapper.map(branch, BranchDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return branchDTO;
	}

	@Override
	public String updateBranch(BranchDTO branchDto) {
		Branch branch = null;
		District district = null;
		try {
			if (branchDto != null && branchDto.getBranchId()!=null && branchDto.getBranchId() > 0) {
				branch = branchRepository.findByBranchByBranchId(branchDto
						.getBranchId());
				if (branch != null) {
					branch.setActive(branchDto.isActive());
					branch.setAddress1(branchDto.getAddress1());
					branch.setBranchCodeCust(branchDto.getBranchCodeCust());
					branch.setBranchName(branchDto.getBranchName());
					branch.setBranchType(branchDto.getBranchType());
					branch.setBranchSubtype(branchDto.getBranchSubtype());
					branch.setModifiedBy(branchDto.getModifiedBy());
					branch.setModifiedDate(new Timestamp(new Date().getTime()));
					branch.setBranchLatitude(branchDto.getBranchLatitude());
					branch.setBranchLongitude(branchDto.getBranchLongitude());
					if (branchDto.getDistrict() != null
							&& branchDto.getDistrict().getDistrictCode() != null
							&& branchDto.getDistrict().getDistrictCode() > 0) {
						Integer districtCode = branchDto.getDistrict()
								.getDistrictCode();
						district = districtRepository
								.findDistrictByDistrictCode(districtCode);
						if (district != null) {
							branch.setDistrict(district);
						}

					}
					branch = branchRepository.saveAndFlush(branch);
					return IotConstants.SUCCESS;
				} else {
					logger.info("branch does not existis");
					return IotConstants.FAILURE;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return null;
	}
}
