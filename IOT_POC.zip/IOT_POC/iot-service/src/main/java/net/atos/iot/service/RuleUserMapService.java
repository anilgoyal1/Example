package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.RuleUserMapDTO;

/**
 * This class is used for the crud operation of RuleUserMap
 * 
 * @author a569702
 *
 */
public interface RuleUserMapService {

	/**
	 * List all the RuleUserMap
	 * 
	 * @return list of RuleUserMapDTO
	 * @throws RulesException
	 *             an RuleException
	 */
	List<RuleUserMapDTO> listRuleUserMap();

	/**
	 * Save the list of RuleUserMapDTO
	 * 
	 * @param alRuleUserMapDTO
	 *            list of RuleUserMapDTO
	 * @return String of message
	 * @throws RulesException
	 *             an Exception
	 */
	String saveRuleUserMap(final List<RuleUserMapDTO> alRuleUserMapDTO);

	/**
	 * Delete the RuleUserMap
	 * 
	 * @param ruleCode
	 *            for the RuleUserMap to be delete
	 * @return String of message
	 * @throws RulesException
	 *             an Exception
	 */
	String deleteRuleUserMap(final Long id);

}
