package net.atos.iot.service;

import java.util.Date;
import java.util.List;

import net.atos.iot.dto.SensorDataDTO;

import org.json.JSONObject;

public interface SensorDataService {

	public List<SensorDataDTO> getAllSensorDataByDeviceId(String deviceId,
			String filterData);

	List<SensorDataDTO> getSensorDataByCreatedDateAndDeviceId(String deviceId,
			Date fromDate, Date toDate);


	List<SensorDataDTO> getSensorDataMonitoringByTenantId(Integer tenantId);

	String getSensorDataGraphByTenantId(final Integer tenantId,
			String filterData);
	
	String  getSensorDataGraphByDeviceId(final String deviceId,
			String filterData);
	
	String  getSensorDataGraphByDeviceIdNew(final String deviceId,
			String filterData);
	
	
	void deleteAllSensorDataByDeviceIds(List<String> deviceIds);

	public SensorDataDTO getSensorDataMonitoringByDeviceId(String deviceId);
	
	
}
