package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.StateDTO;

/**
 * This is a service interface used for State service operations.
 * 
 * @author a602834
 *
 */
public interface StateService {

	String saveStates(StateDTO state);

	/**
	 * This method is used to get State list.
	 * 
	 * @return list of StateDto.
	 */
	List<StateDTO> getStates(boolean active);

	/**
	 * This method is used to delete State.
	 * 
	 * @param stateDto
	 * @return deleted State.
	 */
	String deleteState(Integer stateId);

	StateDTO getStateByStateId(Integer stateId);

	String updateState(StateDTO stateDTO);

}