package net.atos.iot.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.atos.iot.dto.ContainerSpec;
import net.atos.iot.dto.SwarmApiDTO;
import net.atos.iot.dto.TaskTemplate;
import net.atos.iot.service.SwarmAPIService;
import net.atos.iot.util.IotConstants;
import net.atos.iot.util.PerformFunction;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SwarmAPIServiceImpl implements SwarmAPIService {

	private static final Logger logger = Logger
			.getLogger(SwarmAPIServiceImpl.class);

	@Autowired
	PerformFunction performFunction;

	@Value("${swarmAPIUrlEndPoint}")
	private String swarmAPIUrlEndPoint;

	@Value("${swarmApiImageName}")
	private String swarmApiImageName;

	@Value("${swarmContainerHostName}")
	private String swarmContainerHostName;

	@Override
	public void startSwarmContainer(String deviceIds, String simulationName,
			Integer minTemperature, Integer maxTemperature,
			Integer minHumidity, Integer maxHumidity)
			throws IOException {
		if (deviceIds != null && !deviceIds.isEmpty()) {
			ContainerSpec containerSpec = new ContainerSpec();
			containerSpec.setImage(swarmApiImageName);
			containerSpec.setHostname(swarmContainerHostName);
			List<String> args = new ArrayList<>();
			args.add(deviceIds);
			args.add(String.valueOf(minTemperature));
			args.add(String.valueOf(maxTemperature));
			args.add(String.valueOf(minHumidity));
			args.add(String.valueOf(maxHumidity));
			containerSpec.setArgs(args);
			TaskTemplate taskTemplate = new TaskTemplate();
			taskTemplate.setContainerSpec(containerSpec);
			SwarmApiDTO swarmApiDTO = new SwarmApiDTO();
			swarmApiDTO.setName(simulationName);
			swarmApiDTO.setTaskTemplate(taskTemplate);
			System.out.println("Swarm api dto " + new JSONObject(swarmApiDTO));
			String response = performFunction.performFunction(
					swarmAPIUrlEndPoint.concat("/create"), IotConstants.POST,
					new JSONObject(swarmApiDTO).toString());
			logger.info("response after calling create swarn docker  api "
					+ response);
		}
	}

	@Override
	public void deleteSwarmContainer(String simulationName) throws IOException {
		if (simulationName != null && !simulationName.isEmpty()) {
			String response = performFunction.performFunction(
					swarmAPIUrlEndPoint.concat("/").concat(simulationName),
					IotConstants.DELETE, null);
			logger.info("response after calling delete swarn docker  api "
					+ response);
		}

	}

	@Override
	public String checkStatusOfSwarmContainer(String simulationName)
			throws Exception {
		if (simulationName != null && !simulationName.isEmpty()) {
			String response = performFunction.performFunction(
					swarmAPIUrlEndPoint.concat("/").concat(simulationName),
					IotConstants.GET, null);
			logger.info("response after calling delete swarn docker  api "
					+ response);
			if (response.equalsIgnoreCase(IotConstants.SUCCESS)) {
				return "Running";
			} else {
				return "Stopped";
			}
		}
		return "Unknown";
	}

}
