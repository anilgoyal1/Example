package net.atos.iot.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import net.atos.iot.dto.DeviceMasterDTO;
import net.atos.iot.dto.SensorDataDTO;
import net.atos.iot.entity.SensorData;
import net.atos.iot.repository.SensorDataRepository;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.SensorDataService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SensorDataServiceImpl implements SensorDataService {

	private static final Logger logger = Logger
			.getLogger(SensorDataServiceImpl.class);

	@Autowired
	private SensorDataRepository sensorDataRepository;

	@Autowired
	DeviceMasterService deviceServiceImpl;

	private Mapper mapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Autowired
	private EntityManagerFactory emf;

	@Override
	public List<SensorDataDTO> getAllSensorDataByDeviceId(String deviceId,
			String filterData) {
		List<SensorData> sensorDataList = null;
		List<SensorDataDTO> sensorDataDTOList = null;
		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				if (filterData == null) {
					sensorDataList = sensorDataRepository
							.findSensorDataByDeviceId(deviceId);
				} else {

					sensorDataList = this.getSensorDataByDate(deviceId,
							filterData);
				}
				if (sensorDataList != null) {
					sensorDataDTOList = new ArrayList<SensorDataDTO>();
					SensorDataDTO sensorDataDTO = null;
					for (SensorData sensorData : sensorDataList) {
						sensorDataDTO = mapper.map(sensorData,
								SensorDataDTO.class);
						sensorDataDTOList.add(sensorDataDTO);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		if (sensorDataDTOList == null) {
			sensorDataDTOList = new ArrayList<SensorDataDTO>();
		}
		return sensorDataDTOList;
	}

	private List<SensorData> getSensorDataByDate(String deviceId,
			String filterData) {
		List<SensorData> sensorDataList = null;
		Date fromDate = null, toDate = null;
		String fromDateStr = null;
		String toDateStr = null;
		JSONObject reportInputJson = null;
		reportInputJson = new JSONObject(filterData);
		try {
			if (!reportInputJson.isNull(IotConstants.fromDate)) {
				fromDateStr = reportInputJson.getString(IotConstants.fromDate);
				fromDate = DateUtil.convertISOStringToLocalDate(fromDateStr);
				if (!reportInputJson.isNull(IotConstants.toDate)) {
					toDateStr = reportInputJson.getString(IotConstants.toDate);
					toDate = DateUtil.convertISOStringToLocalDate(toDateStr);
				}
				logger.info("sensor Data from Date" + fromDate);
				logger.info("sensor Data to Date" + toDate);

				sensorDataList = sensorDataRepository.getSensorDataByDate(
						deviceId, fromDate, toDate);

			}
		} catch (Exception e) {
		}
		return sensorDataList;
	}

	@Override
	public List<SensorDataDTO> getSensorDataByCreatedDateAndDeviceId(
			String deviceId, Date fromDate, Date toDate) {
		List<SensorData> sensorDataList = null;
		List<SensorDataDTO> sensorDataDTOList = null;

		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				sensorDataList = sensorDataRepository
						.getSensorDataByCreatedDateAndDeviceId(deviceId,
								fromDate, toDate);
			}
			if (sensorDataList != null) {
				sensorDataDTOList = new ArrayList<SensorDataDTO>();
				SensorDataDTO sensorDataDTO = null;
				for (SensorData sensorData : sensorDataList) {
					sensorDataDTO = mapper.map(sensorData, SensorDataDTO.class);
					sensorDataDTOList.add(sensorDataDTO);
				}
			}

		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		return sensorDataDTOList;
	}

	@Override
	public List<SensorDataDTO> getSensorDataMonitoringByTenantId(
			Integer tenantId) {
		List<SensorDataDTO> sensorDataDTOList = new ArrayList<SensorDataDTO>();
		SensorDataDTO sensorDataDTO = null;
		try {
			if (tenantId != null && tenantId > 0) {
				List<DeviceMasterDTO> listDeviceMstDto = deviceServiceImpl
						.getAllDeviceByTenantId(tenantId);
				if (listDeviceMstDto != null && !listDeviceMstDto.isEmpty()) {
					for (DeviceMasterDTO deviceMasterDTO : listDeviceMstDto) {
						List<SensorData> sensorDatalist = sensorDataRepository
								.findSensorDataByDeviceIdInDescOrder(deviceMasterDTO
										.getDeviceId());
						if (sensorDatalist != null && sensorDatalist.size() > 0) {
							SensorData sensorData = sensorDatalist.get(0);
							if (sensorData != null) {
								sensorDataDTO = mapper.map(sensorData,
										SensorDataDTO.class);
								if (sensorDataDTO != null) {
									sensorDataDTOList.add(sensorDataDTO);
								}
							}
						}
					}
				}
				// json.put("monitoringData", sensorDataList);
			} else {
				// return "invalid tenantId " + tenantId;
			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}

		return sensorDataDTOList;
	}

	@Override
	public String getSensorDataGraphByTenantId(Integer tenantId,
			String filterData) {
		JSONArray responseArray = new JSONArray();
		JSONObject graphData = null;
		Date toDate = null;
		Date fromDate = null;
		String toDateStr = null;
		String fromDateStr = null;

		try {
			if (tenantId != null && tenantId > 0) {
				List<String> deviceIdList = deviceServiceImpl
						.getDeviceIdsByTenantId(tenantId);
				// System.out.println(");
				if (deviceIdList != null && !deviceIdList.isEmpty()) {

					if (filterData != null) {
						if (filterData.contains(IotConstants.fromDate)
								&& filterData.contains(IotConstants.toDate)) {
							JSONObject json = new JSONObject(filterData);
							if (json != null) {
								try {
									fromDateStr = json
											.getString(IotConstants.fromDate);
									toDateStr = json
											.getString(IotConstants.toDate);
									fromDate = DateUtil
											.convertISOStringToLocalDate(fromDateStr);
									toDate = DateUtil
											.convertISOStringToLocalDate(toDateStr);
								} catch (Exception e) {
									logger.error("unparsable date");

								}
							}

						} else {
							return new JSONObject().put("Error",
									"Please put fromDate and ToDate")
									.toString();
						}
					}
					if (fromDate == null) {
						fromDate = DateUtil
								.convertDateAndTimeToBeginingOfDate(new Date());
					}
					if (toDate == null) {
						toDate = DateUtil
								.convertDateAndTimeToEndOfDate(new Date());
					}

					for (String deviceId : deviceIdList) {
						List<SensorData> sensorDataList = sensorDataRepository
								.getSensorDataByDate(deviceId, fromDate, toDate);
						if (sensorDataList != null) {
							graphData = prerpareGraphDataFormat(sensorDataList,
									deviceId);
							if (graphData != null) {
								responseArray.put(graphData);
							}

						}

					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		return responseArray.toString();
	}

	@Override
	public String getSensorDataGraphByDeviceId(String deviceId,
			String filterData) {
		String response = "{}";
		Date fromDate = null;
		Date toDate = null;
		String fromDateStr = null;
		String toDateStr = null;
		try {
			if (deviceId != null && !deviceId.isEmpty()) {

				if (filterData != null) {
					if (filterData.contains(IotConstants.fromDate)
							&& filterData.contains(IotConstants.toDate)) {
						JSONObject json = new JSONObject(filterData);
						if (json != null) {
							try {
								fromDateStr = json
										.getString(IotConstants.fromDate);
								toDateStr = json.getString(IotConstants.toDate);
								fromDate = DateUtil
										.convertISOStringToLocalDate(fromDateStr);
								toDate = DateUtil
										.convertISOStringToLocalDate(toDateStr);
							} catch (Exception e) {
								logger.error("unparsable date");

							}
						}

					} else {
						return new JSONObject().put("Error",
								"Please put fromDate and ToDate").toString();
					}
				}
				if (fromDate == null) {
					fromDate = DateUtil
							.convertDateAndTimeToBeginingOfDate(new Date());
				}
				if (toDate == null) {
					toDate = DateUtil.convertDateAndTimeToEndOfDate(new Date());
				}

				List<SensorData> sensorDataList = sensorDataRepository
						.getSensorDataByDate(deviceId, fromDate, toDate);
				if (sensorDataList != null) {

					return response = prerpareGraphDataFormat(sensorDataList,
							deviceId).toString();

				}

			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}

		return response;
	}

	private JSONObject prerpareGraphDataFormat(List<SensorData> sensorDataList,
			String deviceId) {
		JSONObject deviceJson = new JSONObject();
		List<String> temperatureArray = new ArrayList<String>();
		List<String> humidityArray = new ArrayList<String>();
		List<String> cpuArray = new ArrayList<String>();
		List<String> ramArray = new ArrayList<String>();
		List<String> hddArray = new ArrayList<String>();
		String humidity = null;
		String tempertature = null;
		String cpuUsed = null;
		String hddUsed = null;
		String ramUsed = null;
		Long receivedDate = null;
		String dataFormat = "{date,value}";
		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				for (SensorData sensorData : sensorDataList) {
					// minVal = a < b ? a : b;
					receivedDate = sensorData.getReceivedTime() != null ? sensorData
							.getReceivedTime().getTime() : 0;
					tempertature = sensorData.getTemprature() != null ? sensorData
							.getTemprature().toString() : null;
					humidity = sensorData.getHumidity() != null ? sensorData
							.getHumidity().toString() : null;
					cpuUsed = sensorData.getHumidity() != null ? sensorData
							.getCpuUsed().toString() : null;
					hddUsed = sensorData.getHumidity() != null ? sensorData
							.getHardDiskUsed().toString() : null;
					ramUsed = sensorData.getHumidity() != null ? sensorData
							.getRamUsed().toString() : null;
					temperatureArray.add(dataFormat.replace("date",
							receivedDate.toString()).replace("value",
							tempertature));
					humidityArray
							.add(dataFormat.replace("date",
									receivedDate.toString()).replace("value",
									humidity));
					cpuArray.add(dataFormat.replace("date",
							receivedDate.toString()).replace("value", cpuUsed));
					hddArray.add(dataFormat.replace("date",
							receivedDate.toString()).replace("value", hddUsed));
					ramArray.add(dataFormat.replace("date",
							receivedDate.toString()).replace("value", ramUsed));
				}

				JSONObject temp = new JSONObject();

				temp.put("temperature", temperatureArray);
				temp.put("humidity", humidityArray);
				temp.put("cpuUsed", cpuArray);
				temp.put("ramUsed", ramArray);
				temp.put("hddUsed", hddArray);
				deviceJson.put("deviceId", deviceId);
				deviceJson.put("data", temp);

			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}

		return deviceJson;
	}

	@Override
	public String getSensorDataGraphByDeviceIdNew(String deviceId,
			String filterData) {
		String response = "{}";
		Date fromDate = null;
		Date toDate = null;
		String fromDateStr = null;
		String toDateStr = null;
		long timeDifferenceInHrs = 0;
		List<SensorData> sensorDataList = null;
		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				if (filterData != null) {
					if (filterData.contains(IotConstants.fromDate)
							&& filterData.contains(IotConstants.toDate)) {
						JSONObject json = new JSONObject(filterData);
						if (json != null) {
							try {
								fromDateStr = json
										.getString(IotConstants.fromDate);
								toDateStr = json.getString(IotConstants.toDate);
								fromDate = DateUtil
										.convertISOStringToLocalDate(fromDateStr);
								toDate = DateUtil
										.convertISOStringToLocalDate(toDateStr);
							} catch (Exception e) {
								logger.error("unparsable date");

							}
						}

					} else {
						return new JSONObject().put("Error",
								"Please put fromDate and ToDate").toString();
					}
				}
				if (fromDate == null) {
					fromDate = DateUtil
							.convertDateAndTimeToBeginingOfDate(new Date());
				}
				if (toDate == null) {
					toDate = DateUtil.convertDateAndTimeToEndOfDate(new Date());
				}

				timeDifferenceInHrs = DateUtil.differenceInHours(fromDate,
						toDate);
				if (timeDifferenceInHrs <= 24) {
					sensorDataList = sensorDataRepository.getSensorDataByDate(
							deviceId, fromDate, toDate);
				} else if (timeDifferenceInHrs > 24
						&& timeDifferenceInHrs <= IotConstants.HOURS_IN_MONTHS) {
					return prepareAggregateSensorData(fromDate, toDate, "hour",
							deviceId);
				} else {
					return prepareAggregateSensorData(fromDate, toDate, "day",
							deviceId);
				}
				if (sensorDataList != null) {
					return response = prerpareGraphDataFormat(sensorDataList,
							deviceId).toString();

				}

			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}

		return response;
	}

	public String prepareAggregateSensorData(Date fromDate, Date toDate,
			String aggregateDuration, String deviceId) {
		List<Object[]> avgData = null;
		if (fromDate != null && toDate != null && deviceId != null
				&& deviceId.length() > 0) {
			EntityManager entityManager = null;

			StringBuilder sql = new StringBuilder();
			sql.append("select device_id, date_trunc(:aggregateDuration, created_date)as timestamp, ");
			sql.append(" avg(temperature) AS temperature, ");
			sql.append(" avg(humidity) As humidity,");
			sql.append("  avg(cpu_used) As cpu_used, ");
			sql.append(" avg(hard_disk_used) as hddused, ");
			sql.append(" avg(ram_used)as ram_used ");
			sql.append(" FROM sensor_data ");
			sql.append(" WHERE created_date between :fromDate and :toDate ");
			sql.append(" AND device_id =:deviceId ");
			sql.append(" GROUP BY timestamp ,device_id ");
			sql.append(" ORDER BY timestamp ");
			entityManager = emf.createEntityManager();
			Query query = entityManager.createNativeQuery(sql.toString());
			query.setParameter("aggregateDuration", aggregateDuration);
			query.setParameter("fromDate", fromDate);
			query.setParameter("deviceId", deviceId);
			query.setParameter("toDate", toDate);

			try {
				avgData = query.getResultList();
				return createGraphDataForUI(avgData);

			} catch (Exception e) {
				logger.error("Exception ", e);
			} finally {
				if (entityManager != null && entityManager.isOpen()) {
					entityManager.close();
				}
			}

		}

		return null;

	}

	private String createGraphDataForUI(List<Object[]> avgData) {
		String dataFormat = "{date,value}";
		JSONObject dataJson = new JSONObject();
		JSONObject attributeArray = new JSONObject();
		String timeStampStr = null;
		String temperatureStr = null;
		String humdityStr = null;
		String cpuUsedStr = null;
		String hddUsedStr = null;
		String ramUsedStr = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.s");
		String timeStamp = null;
		ArrayList<String> temperatureArray = new ArrayList<String>();
		ArrayList<String> humidityArray = new ArrayList<String>();
		ArrayList<String> hddUsedArray = new ArrayList<String>();
		ArrayList<String> ramUsedArray = new ArrayList<String>();
		ArrayList<String> cpuUsedArray = new ArrayList<String>();
		if (avgData != null) {
			for (Object[] obj : avgData) {
				if (obj.length > 6) {
					timeStampStr = obj[1].toString();
					try {
						timeStamp = sdf.parse(timeStampStr).getTime() + "";
						temperatureStr = obj[2].toString();
						humdityStr = obj[3].toString();
						cpuUsedStr = obj[4].toString();
						hddUsedStr = obj[5].toString();
						ramUsedStr = obj[6].toString();
						temperatureArray.add(dataFormat.replace("date",
								timeStamp).replace("value", temperatureStr));
						humidityArray.add(dataFormat.replace("date", timeStamp)
								.replace("value", humdityStr));
						hddUsedArray.add(dataFormat.replace("date", timeStamp)
								.replace("value", hddUsedStr));
						ramUsedArray.add(dataFormat.replace("date", timeStamp)
								.replace("value", ramUsedStr));
						cpuUsedArray.add(dataFormat.replace("date", timeStamp)
								.replace("value", cpuUsedStr));
						attributeArray.put("temperature", temperatureArray);
						attributeArray.put("humidity", humidityArray);
						attributeArray.put("hddUsed", hddUsedArray);
						attributeArray.put("cpuUsed", cpuUsedArray);
						attributeArray.put("ramUsed", ramUsedArray);
					} catch (ParseException e) {
						logger.info("unparsable date " + timeStampStr);
					}

				}
			}
			dataJson.put("data", attributeArray);
		}
		return dataJson.toString();
	}

	@Override
	public void deleteAllSensorDataByDeviceIds(List<String> deviceIds) {
		if (deviceIds != null && !deviceIds.isEmpty()) {
			sensorDataRepository.deleteSensorDataByDeviceIds(deviceIds);
		}
	}

	@Override
	public SensorDataDTO getSensorDataMonitoringByDeviceId(String deviceId) {
		SensorDataDTO sensorDataDTO = null;
		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				List<SensorData> sensorDatalist = sensorDataRepository
						.findSensorDataByDeviceIdInDescOrder(deviceId);
				if (sensorDatalist != null && sensorDatalist.size() > 0) {
					SensorData sensorData = sensorDatalist.get(0);
					if (sensorData != null) {
						sensorDataDTO = mapper.map(sensorData,
								SensorDataDTO.class);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		if (sensorDataDTO == null) {
			sensorDataDTO = new SensorDataDTO();
		}
		return sensorDataDTO;
	}

}
