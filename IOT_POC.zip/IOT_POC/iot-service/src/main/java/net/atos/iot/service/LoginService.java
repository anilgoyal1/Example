package net.atos.iot.service;

import net.atos.iot.dto.UserDetailsDTO;

public interface LoginService {

	UserDetailsDTO login(String userId, String password);

}
