package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.TicketDTO;
import net.atos.iot.entity.Ticket;

/**
 * This is a service interface used for Branch operations.
 * 
 * @author A596108
 *
 */
public interface TicketService {

	String createTicket(TicketDTO ticketDTO);

	List<TicketDTO> getTicketByDeviceAndStatus(String deviceId, String status);

	List<TicketDTO> getTicketByDeviceId(String deviceId);

	List<TicketDTO> getTicketByStatus(String status);

	List<TicketDTO> getAllTicket();

	String updateTicket(TicketDTO ticketDTO, String userId);

	List<TicketDTO> getActiveTicketDTO();

	List<TicketDTO> getTicketByTenanatIdAndStatus(Integer tenantId,
			String status);

	List<TicketDTO> getAllTicketTenantIdWise(Integer tenantId);

	TicketDTO getTicketByTicketId(Long ticketId);

	String getTicketCountForDashboard(Integer tenantId, String filterData);

	List<Ticket> getOpenTicketByDeviceIdAndTicketType(String deviceId,
			String typeType);

	List<Ticket> getActiveTicketEntity();

	public String saveTicket(Ticket ticket);
	
	void deleteAllTicketsByDeviceIds(List<String> deviceIds);
	
	void sendTicketStatusChangedNotification(Integer tenantId, String message);

	void sendTicketStatusChangedNotificationByDeviceId(String deviceId,
			String message);

	String createTicketForAishwarya(TicketDTO ticketDTO);
	

}
