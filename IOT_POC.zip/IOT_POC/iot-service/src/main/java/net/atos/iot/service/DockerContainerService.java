package net.atos.iot.service;

import java.io.IOException;

public interface DockerContainerService {

	public void startDockerContainer(String containerName) throws IOException;

	public void deleteDockerContainer(String containerName) throws IOException;

	public void checkStatusOfDockerContainer(String containerName)
			throws Exception;

	void createContainer(String simulationName) throws IOException;

	void stopDockerContainer(String containerName) throws IOException;

}
