package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.List;

import net.atos.iot.dto.TicketRootCauseDTO;
import net.atos.iot.entity.TicketRootCauseMaster;
import net.atos.iot.repository.TicketRootCauseRepository;
import net.atos.iot.service.TicketRootCauseMasterService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketRootCauseMasterServiceImpl implements
		TicketRootCauseMasterService {

	private static final Logger logger = Logger
			.getLogger(TicketRootCauseDTO.class);

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Autowired
	TicketRootCauseRepository ticketRootCauseRepo;

	@Override
	public List<TicketRootCauseDTO> getAllRootCauses() {
		List<TicketRootCauseDTO> listOfTicketRootCauseDTO = null;
		try {
			List<TicketRootCauseMaster> ticketRootCauseMasterList = ticketRootCauseRepo
					.findAll();
			if (ticketRootCauseMasterList != null
					&& !ticketRootCauseMasterList.isEmpty()) {
				listOfTicketRootCauseDTO = new ArrayList<TicketRootCauseDTO>();
				TicketRootCauseDTO ticketRootCauseDTO = null;
				for (TicketRootCauseMaster ticketRootCauseMaster : ticketRootCauseMasterList) {
					ticketRootCauseDTO = dMapper.map(ticketRootCauseMaster,
							TicketRootCauseDTO.class);
					listOfTicketRootCauseDTO.add(ticketRootCauseDTO);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return listOfTicketRootCauseDTO;
	}

	@Override
	public String addTicketRootCause(TicketRootCauseDTO rootCause) {
		TicketRootCauseMaster ticketRootCauseMaster = null;
		if (rootCause != null && rootCause.getRootCause() != null
				&& rootCause.getRootCause().length() > 0) {
			try {
				ticketRootCauseMaster = dMapper.map(rootCause,
						TicketRootCauseMaster.class);
				ticketRootCauseRepo.save(ticketRootCauseMaster);
				return IotConstants.SUCCESS;
			} catch (Exception e) {
				logger.error(IotConstants.Exception, e);
			}
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String deleteTicketRootCauase(Integer rootCauseId) {
		if (rootCauseId != null && rootCauseId > 0) {
			try {
				TicketRootCauseMaster ticketRootCauseMaster = ticketRootCauseRepo
						.findOne(rootCauseId);
				if (ticketRootCauseMaster != null) {
					ticketRootCauseRepo.delete(ticketRootCauseMaster);
					return IotConstants.SUCCESS;
				}
			} catch (Exception e) {
				logger.error(IotConstants.Exception, e);
				return IotConstants.FAILURE;

			}
		}
		return IotConstants.SUCCESS;
	}

}
