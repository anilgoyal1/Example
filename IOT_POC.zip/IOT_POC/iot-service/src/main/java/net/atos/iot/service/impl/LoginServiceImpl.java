package net.atos.iot.service.impl;

import net.atos.iot.dto.UserDetailsDTO;
import net.atos.iot.entity.UserDetails;
import net.atos.iot.repository.UserDetailsRepository;
import net.atos.iot.service.LoginService;
import net.atos.iot.util.Base64EncoderDecoder;
import net.atos.iot.util.DozerBeanMapperFactory;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements LoginService  {

	private static final Logger logger = Logger
			.getLogger(LoginServiceImpl.class);

	@Autowired
	UserDetailsRepository userDetailsDao;

	

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Override
	public UserDetailsDTO login(String userId, String password) {
		UserDetailsDTO userDetailsDto = null;
		if (userId != null && password != null && !userId.isEmpty()
				&& !password.isEmpty()) {
			UserDetails userDetail = userDetailsDao
					.findUserDetailsByUserId(userId);
			if (userDetail != null) {
				if (Base64EncoderDecoder.decodeString(userDetail.getPassword())
						.equals(password) && userDetail.isActive()) {
					userDetailsDto = dMapper.map(userDetail,
							UserDetailsDTO.class);
					
				}
			}
		}
		if (userDetailsDto == null) {
			userDetailsDto = new UserDetailsDTO();
		}
		return userDetailsDto;
	}

	/*
	public void createQueueForUser(UserDetailsDTO userDetailsDto) throws IOException, TimeoutException {
		String[] routingKeys = {
				userDetailsDto.getTenant().getTenantName(),
				IotConstants.PUSH_NOTIFICATION_ROUTING_KEY_FOR_BROADCAST_MESSAGE };
		endPoint.createQueueInExchangeWithRoutingKey(userDetailsDto.getUserId(),IotConstants.PUSH_NOTIFICATION_EXCHANGE_NAME,routingKeys);
	}*/

}
