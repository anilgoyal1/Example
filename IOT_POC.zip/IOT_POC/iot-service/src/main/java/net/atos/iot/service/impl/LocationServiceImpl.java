package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.BranchDTO;
import net.atos.iot.dto.LocationDTO;
import net.atos.iot.entity.Branch;
import net.atos.iot.entity.Location;
import net.atos.iot.repository.BranchRepository;
import net.atos.iot.repository.LocationRepository;
import net.atos.iot.service.LocationService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LocationServiceImpl implements LocationService {

	private static final Logger LOGGER = Logger
			.getLogger(LocationServiceImpl.class);

	@Autowired
	LocationRepository locationRepository;

	@Autowired
	BranchRepository branchRepository;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Override
	public List<LocationDTO> getAllLocation(boolean active) {
		List<Location> locations = null;
		List<LocationDTO> locationDtos = null;
		try {
			locations = locationRepository.getAllLocations(active);
			LOGGER.info("No. Of locations - " + locations.size());
			if (locations != null && !locations.isEmpty()) {
				locationDtos = new ArrayList<LocationDTO>();
				for (Location location : locations) {
					LocationDTO locationDTO = dMapper.map(location,
							LocationDTO.class);
					Branch branch = location.getBranch();
					if (branch != null) {
						BranchDTO branchDTO = dMapper.map(branch,
								BranchDTO.class);
						locationDTO.setBranch(branchDTO);
					}
					locationDtos.add(locationDTO);
				}
			}
		} catch (Exception e) {
			LOGGER.info(e);
		}

		if (locationDtos == null) {
			locationDtos = new ArrayList<LocationDTO>();
		}

		return locationDtos;
	}

	@Override
	public String saveLocation(LocationDTO locationDTO) {
		Location location = null;
		Branch branch = null;
		try {
			if (locationDTO != null) {
				location = locationRepository.findByLocCode(locationDTO
						.getLocCode());
				if (null == location) {
					System.out
							.println("No location exists creating new location - "
									+ location);
					location = dMapper.map(locationDTO, Location.class);
					location.setCreatedDate(new Date());
					location.setModifiedDate(new Date());
					if (locationDTO.getBranch() != null
							&& locationDTO.getBranch().getBranchId() != null) {
						Long branchId = locationDTO.getBranch().getBranchId();
						branch = branchRepository
								.findByBranchByBranchId(branchId);
						if (branch != null) {
							location.setBranch(branch);
						}
					}
					location = locationRepository.save(location);
					return IotConstants.SUCCESS;
				} else {
					LOGGER.info("location code already exists");
					return "location code alreay exists";
				}
			}
		} catch (Exception e) {
			LOGGER.info(e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String deleteLocation(Long locationId) {
		try {
			if (locationId != null && locationId > 0) {
				Location location = locationRepository
						.findLocationByLocationId(locationId);
				if (location != null) {
					location.setActive(IotConstants.FALSE);
					location.setModifiedDate(new Date());
					locationRepository.saveAndFlush(location);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public List<LocationDTO> getAllLocationByLocSubtype(String locSubtype) {
		List<Location> alLocations = null;
		List<LocationDTO> alLocationDTOs = null;
		if (StringUtils.isNotBlank(locSubtype)) {
			alLocations = locationRepository.findAllByLocSubtype(locSubtype);
			if (null != alLocations && !alLocations.isEmpty()) {
				alLocationDTOs = new ArrayList<LocationDTO>();
				for (Location location : alLocations) {
					alLocationDTOs
							.add(dMapper.map(location, LocationDTO.class));
				}
			}
		}
		return alLocationDTOs;
	}

	@Override
	public LocationDTO getLocationByLocCode(String locCode) {
		LocationDTO locationDTO = null;
		if (StringUtils.isNotBlank(locCode)) {
			Location location = locationRepository.findByLocCode(locCode);
			if (null != location) {
				locationDTO = dMapper.map(location, LocationDTO.class);
			}
		}
		return locationDTO;
	}

	@Override
	public LocationDTO getLocationByLocationId(Long locationId) {
		LocationDTO locationDTO = null;
		if (locationId != null && locationId > 0) {
			Location location = locationRepository
					.findLocationByLocationId(locationId);
			if (null != location) {
				locationDTO = dMapper.map(location, LocationDTO.class);
				
		
			}
		}
		return locationDTO;
	}

	@Override
	public String updateLocation(LocationDTO locationDTO) {
		try {
			if (locationDTO != null) {
				Location location = locationRepository
						.findLocationByLocationId((locationDTO.getLocationId()));
				if (location != null) {
					location.setActive(locationDTO.isActive());
					location.setLocCode(locationDTO.getLocCode());
					location.setLocCodeCust(locationDTO.getLocCodeCust());
					location.setLocName(locationDTO.getLocName());
					location.setLocType(locationDTO.getLocType());
					location.setLocSubtype(locationDTO.getLocSubtype());
					location.setLocInfo(locationDTO.getLocInfo());
					location.setModifiedBy(locationDTO.getModifiedBy());
					location.setModifiedDate(new Date());
					location.setAddress(locationDTO.getAddress());
					location.setLocationLatitude(locationDTO
							.getLocationLatitude());
					location.setLocationLongitude(locationDTO
							.getLocationLongitude());
					if (locationDTO.getBranch() != null
							&& locationDTO.getBranch().getBranchId() != null) {
						Long branchId = locationDTO.getBranch().getBranchId();
						Branch branch = branchRepository
								.findByBranchByBranchId(branchId);
						if (branch != null && branch.isActive()) {
							location.setBranch(branch);
						}
					}
					location = locationRepository.saveAndFlush(location);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}
}
