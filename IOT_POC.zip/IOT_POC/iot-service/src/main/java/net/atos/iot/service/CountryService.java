package net.atos.iot.service;

import java.util.List;
import java.util.Map;

import net.atos.iot.dto.CountryDTO;

/**
 * This is a service interface used for Country operations.
 * 
 * @author a602834
 * 
 */
public interface CountryService {

	/**
	 * This method is used to get Country list.
	 * 
	 * @return list of Country dto.
	 */
	List<CountryDTO> getCountries(boolean active);

	/**
	 * This method is used to save Country.
	 * 
	 * @param country
	 * @return saved Country.
	 */
	String saveCountry(CountryDTO country);

	/**
	 * This method is used to delete Country.
	 * 
	 * @param countryDto
	 * @return deleted Country.
	 */
	String deleteCountry(Integer countryId);

	CountryDTO getCountryByCountryId(Integer countryId);

	String updateCountry(CountryDTO countryDTO);

	Integer assignRegionsToCountry(Map<String, Object> hashMap);

}
