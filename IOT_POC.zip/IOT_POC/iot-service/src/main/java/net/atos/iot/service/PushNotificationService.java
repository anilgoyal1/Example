package net.atos.iot.service;

public interface PushNotificationService {

	void sendNotficationByDeviceId(String deviceId, String notificationMessage);

	void sendNotificationByTenantId(Integer tenantId, String notificationMessage);
}
