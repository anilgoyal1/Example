package net.atos.iot.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import net.atos.iot.dto.TenantDTO;
import net.atos.iot.entity.Country;
import net.atos.iot.entity.DeviceMaster;
import net.atos.iot.entity.Tenant;
import net.atos.iot.repository.CountryRepository;
import net.atos.iot.repository.DeviceMasterRepository;
import net.atos.iot.repository.TenantRepository;
import net.atos.iot.service.TenantService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TenantServiceImpl implements TenantService {

	@Autowired
	private TenantRepository tenantDao;

	@Autowired
	private CountryRepository countryDao;

	@Autowired
	private DeviceMasterRepository deviceMasterDao;

	private static final Logger logger = Logger
			.getLogger(TenantServiceImpl.class);

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Override
	public List<TenantDTO> getAllTenants(boolean active) {
		List<TenantDTO> listOfTenantDTO = null;
		try {
			List<Tenant> tenants = tenantDao.findTenats(active);
			if (tenants != null && !tenants.isEmpty()) {
				listOfTenantDTO = new ArrayList<TenantDTO>();
				TenantDTO tenantDto = null;
				for (Tenant tenant : tenants) {
					tenantDto = dMapper.map(tenant, TenantDTO.class);
					listOfTenantDTO.add(tenantDto);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return listOfTenantDTO;
	}

	@Override
	public TenantDTO getTenantDTOById(Integer tenantId) {
		TenantDTO tenantDTO = null;
		try {
			if (tenantId != null && tenantId > 0) {
				Tenant tenant = tenantDao.findTenantByTenantId(tenantId);
				if (tenant != null) {
					tenantDTO = dMapper.map(tenant, TenantDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return tenantDTO;
	}

	@Override
	public String createTenant(TenantDTO tenantDTO) {
		logger.info("inside createTenant Method");
		Tenant tenant = null;
		try {
			if (tenantDTO != null && tenantDTO.getTenantName() != null
					&& !tenantDTO.getTenantName().isEmpty()) {
				tenant = tenantDao.findTenantByTenantName(tenantDTO
						.getTenantName());
				if (tenant == null) {
					return createNewTenant(tenantDTO);
				} else {
					return "Tenant already Exists";
				}

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;

	}

	@Override
	public String updateTenant(TenantDTO tenantDto) {
		try {
			if (tenantDto != null && tenantDto.getTenantId() != null
					&& tenantDto.getTenantId() > 0) {
				Tenant tenant = tenantDao.findTenantByTenantId(tenantDto
						.getTenantId());
				if (tenant != null) {
					tenant.setModifiedDate(new Timestamp(new Date().getTime()));
					tenant.setModifiedBy(tenantDto.getModifiedBy());
					tenant.setActive(tenantDto.isActive());
					tenant.setContactNo(tenantDto.getContactNo());
					tenant.setEmailId(tenantDto.getEmailId());
					tenant.setServiceName(tenantDto.getServiceName());
					tenant.setTenantName(tenantDto.getTenantName());
					tenant = tenantDao.saveAndFlush(tenant);
					List<Integer> countryIdsList = tenantDto.getCountriesIds();
					if (countryIdsList != null && countryIdsList.size() > 0) {
						System.out
								.println("country DTO is not null and size is greater then zero");
						Set<Country> countryList = tenant.getCountry();
						Country country = null;
						for (Integer countryId : countryIdsList) {
							country = countryDao
									.findCountryByCountryId(countryId);
							if (country != null
									&& country.getCountryId() != null
									&& country.getCountryId() > 0) {
								countryList.add(country);
							} else {
								logger.info("country with countryId "
										+ countryId + " does not exists");
							}
						}
						if (countryList != null && !countryList.isEmpty()) {
							tenant.setCountry(countryList);
						}
					}

					tenant = tenantDao.saveAndFlush(tenant);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	private String createNewTenant(TenantDTO tenantDTO) {
		try {
			Set<Country> countryList = null;
			if (tenantDTO != null) {
				Tenant tenant = dMapper.map(tenantDTO, Tenant.class);
				tenant.setCreatedDate(new Timestamp(new Date().getTime()));
				List<Integer> countryIdsList = tenantDTO.getCountriesIds();
				if (countryIdsList != null && countryIdsList.size() > 0) {
					System.out
							.println("country DTO is not null and size is greater then zero");
					countryList = new HashSet<Country>();
					Country country = null;
					for (Integer countryId : countryIdsList) {
						country = countryDao.findCountryByCountryId(countryId);
						if (country != null && country.getCountryId() != null
								&& country.getCountryId() > 0) {
							countryList.add(country);
						} else {
							logger.info("country with countryId " + countryId
									+ " does not exists");
						}
					}
					if (countryList != null && !countryList.isEmpty()) {
						tenant.setCountry(countryList);
					}
				}

				tenant = tenantDao.saveAndFlush(tenant);
				return IotConstants.SUCCESS;
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String deleteTenant(Integer tenantId) {
		try {
			if (tenantId != null && tenantId > 0) {
				Tenant tenant = tenantDao.findTenantByTenantId(tenantId);

				if (tenant != null) {
					tenant.setActive(IotConstants.FALSE);
					tenant.setModifiedDate(new Timestamp(new Date().getTime()));
					tenantDao.saveAndFlush(tenant);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;
	}

	@Override
	@Transactional
	public TenantDTO assignCountriesToTenant(Map<String, Object> hashMap) {
		Integer tenantId = (Integer) hashMap.get("tenantId");
		@SuppressWarnings("unchecked")
		List<Integer> countriesIds = (List<Integer>) hashMap
				.get("countriesIds");
		return this.assignCountriesToTenant(countriesIds, tenantId);
	}

	private TenantDTO assignCountriesToTenant(List<Integer> countriesId,
			Integer tenantId) {
		TenantDTO tenantDto = null;
		try {
			if (tenantId > 0) {
				Tenant tenant = tenantDao.findTenantByTenantId(tenantId);
				List<Country> countries = countryDao
						.findContriesByIds(countriesId);
				if (countries != null && !countries.isEmpty()) {
					for (Country country : countries) {
						if (!tenant.getCountry().contains(country)
								&& country.isActive()) {
							tenant.getCountry().add(country);
						}
					}
					tenant = tenantDao.saveAndFlush(tenant);
					tenantDto = dMapper.map(tenant, TenantDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return tenantDto;
	}

	@Override
	public Tenant getTenantByTenantId(Integer tenantId) {
		Tenant tenant = null;
		try {
			if (tenantId != null && tenantId > 0) {
				tenant = tenantDao.findTenantByTenantId(tenantId);

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return tenant;
	}

	@Override
	public Integer getTenantIdByDeviceId(String deviceId) {
		Integer tenantId = null;
		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				DeviceMaster deviceMst = deviceMasterDao
						.getDeviceByDeviceId(deviceId);
				if (deviceMst != null) {
					Tenant tenant = deviceMst.getTenant();
					if (tenant != null && tenant.getTenantId() != null
							&& tenant.getTenantId() > 0) {
						tenantId = tenant.getTenantId();
					}
				}
			}
		} catch (Exception e) {
			logger.info("Exception ", e);
		}
		return tenantId;
	}
}
