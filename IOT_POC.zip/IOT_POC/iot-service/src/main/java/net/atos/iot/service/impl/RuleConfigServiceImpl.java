package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.atos.iot.dto.RuleConfigDTO;
import net.atos.iot.entity.DeviceMaster;
import net.atos.iot.entity.RuleConfig;
import net.atos.iot.repository.RuleConfigRepository;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.RuleConfigService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RuleConfigServiceImpl implements RuleConfigService {

	private static final Logger logger = Logger
			.getLogger(RuleConfigServiceImpl.class);

	@Autowired
	RuleConfigRepository ruleConfigDao;

	@Autowired
	DeviceMasterService deviceMasterService;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Override
	public List<RuleConfigDTO> getAllRuleConfig() {
		List<RuleConfig> ruleConfigList = null;
		List<RuleConfigDTO> ruleConfigDTOList = null;
		try {
			ruleConfigList = ruleConfigDao.findAllActiveRule();
			if (ruleConfigList != null) {
				ruleConfigDTOList = new ArrayList<RuleConfigDTO>();
				RuleConfigDTO ruleConfigDTO = null;
				Set<String> setOfDevices = null;
				for (RuleConfig ruleConfig : ruleConfigList) {
					ruleConfigDTO = dMapper
							.map(ruleConfig, RuleConfigDTO.class);
					if (ruleConfig.getDevices() != null
							&& ruleConfig.getDevices().size() > 0) {
						setOfDevices = new HashSet<String>();
						for (DeviceMaster deviceMaster : ruleConfig
								.getDevices()) {
							setOfDevices.add(deviceMaster.getDeviceId());
						}
						if (setOfDevices != null && setOfDevices.size() > 0) {
							ruleConfigDTO.setDevices(setOfDevices);
						}
					}
					if (ruleConfigDTO != null) {
						ruleConfigDTOList.add(ruleConfigDTO);
					}
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		if (ruleConfigDTOList == null) {
			ruleConfigDTOList = new ArrayList<RuleConfigDTO>(0);
		}
		return ruleConfigDTOList;
	}

	@Override
	public RuleConfigDTO getAllruleConfigByRuleCode(final String ruleCode) {
		RuleConfig ruleConfig = null;
		RuleConfigDTO ruleConfigDTO = null;
		Set<String> setOfDevices = null;
		try {
			ruleConfig = ruleConfigDao.findRuleByRuleCode(ruleCode);
			if (ruleConfig != null) {
				ruleConfigDTO = dMapper.map(ruleConfig, RuleConfigDTO.class);
				if (ruleConfigDTO != null && ruleConfig.getDevices() != null
						&& ruleConfig.getDevices().size() > 0) {
					setOfDevices = new HashSet<String>();
					for (DeviceMaster deviceMaster : ruleConfig.getDevices()) {
						setOfDevices.add(deviceMaster.getDeviceId());
					}
					if (setOfDevices != null && setOfDevices.size() > 0) {
						ruleConfigDTO.setDevices(setOfDevices);
					}
				}

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return ruleConfigDTO;
	}

	@Override
	public String addRuleConfig(RuleConfigDTO ruleConfigDTO) {

		try {
			if (ruleConfigDTO != null && ruleConfigDTO.getRuleCode() != null
					&& !ruleConfigDTO.getRuleCode().isEmpty()) {
				RuleConfig ruleConfig = ruleConfigDao
						.findRuleByRuleCode(ruleConfigDTO.getRuleCode());
				if (ruleConfig == null) {
					ruleConfig = dMapper.map(ruleConfigDTO, RuleConfig.class);
					if (ruleConfig != null) {
						ruleConfig = ruleConfigDao.save(ruleConfig);
						return IotConstants.SUCCESS;
					}
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;
	}

	@Override
	public String deleteRuleConfig(String ruleCode) {
		RuleConfig ruleConfig = null;
		try {
			ruleConfig = ruleConfigDao.findRuleByRuleCode(ruleCode);
			if (ruleConfig != null) {
				Set<DeviceMaster> deviceMasterList = ruleConfig.getDevices();
				if (deviceMasterList != null && !deviceMasterList.isEmpty()) {
					return "Rule is already mapped with other devices can not be deleted";
				} else {
					ruleConfigDao.delete(ruleConfig.getRuleCode());
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String updateRuleConfig(RuleConfigDTO ruleConfigDTO) {
		RuleConfig ruleConfig = null;
		RuleConfig updatedRuleConfig = null;
		try {
			if (ruleConfigDTO != null && ruleConfigDTO.getRuleCode() != null
					&& !ruleConfigDTO.getRuleCode().isEmpty()) {
				ruleConfig = ruleConfigDao.findRuleByRuleCode(ruleConfigDTO
						.getRuleCode());
				if (ruleConfig != null) {
					updatedRuleConfig = dMapper.map(ruleConfigDTO,
							RuleConfig.class);
					if (null != updatedRuleConfig) {
						updatedRuleConfig.setRuleCode(ruleConfig.getRuleCode());
						RuleConfig savedRuleConfig = ruleConfigDao
								.save(updatedRuleConfig);
						if (null != savedRuleConfig) {
							Set<DeviceMaster> devices = savedRuleConfig
									.getDevices();
							for (DeviceMaster deviceDTO : devices) {
								deviceMasterService
										.sendDataToDeviceConfigurationQueue(deviceDTO
												.getDeviceId());
							}

							return IotConstants.SUCCESS;
						}
					}

				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public RuleConfig getAllruleConfigEntityByRuleCode(String rule_code) {
		RuleConfig ruleConfig = null;
		try {
			ruleConfig = ruleConfigDao.findRuleByRuleCode(rule_code);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return ruleConfig;
	}

}
