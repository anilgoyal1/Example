
package net.atos.iot.mapper;


import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * The Class AspectJUtil.
 * 
 * @author a147726
 */
@Aspect
@Component
public class AspectJUtil {
    /** The logger. */
    private static final Logger LOGGER = Logger.getLogger(AspectJUtil.class);

    /**
     * Cloud pointcut.
     */
    @Pointcut(value = "within(net.atos.iot.*.*)  && !within(net.atos.iot.mapper.AspectJUtil)")
    public void cloudPointcut() {
	LOGGER.info("Cloud Point Cut Method");
    }

    /**
     * Log method entry.
     * 
     * @param joinPoint
     *            the join point
     */
    @Before("cloudPointcut()")
    public void logMethodEntry(final JoinPoint joinPoint) {
	final String name = joinPoint.getSignature().toLongString();
	final String logMessage = "Entering method " + name;
	logInfo(logMessage);
    }

    /**
     * Log method exit.
     * 
     * @param joinPoint
     *            the join point
     * @param result
     *            the result
     */
    @AfterReturning(pointcut = "cloudPointcut()", returning = "result")
    public void logMethodExit(final JoinPoint joinPoint, final Object result) {
	final String name = joinPoint.getSignature().toLongString();
	final String logMessage = "Exiting method " + name;
	logInfo(logMessage);
    }

    /**
     * Log method exception.
     * 
     * @param joinPoint
     *            the join point
     * @param exception
     *            the exception
     */
    @AfterThrowing(pointcut = "cloudPointcut()", throwing = "exception")
    public void logMethodException(final JoinPoint joinPoint,
	    final Throwable exception) {
	final String name = joinPoint.getSignature().toLongString();
	final String logMessage = "Exception in method " + name + " : ";
	logError(logMessage, exception);
    }

    /**
     * Log info.
     * 
     * @param logMessage
     *            the log message
     */
    public static void logInfo(final String logMessage) {
	LOGGER.info(logMessage);
    }

    /**
     * Log error.
     * 
     * @param logMessage
     *            the log message
     * @param exception
     *            the exception
     */
    public static void logError(final String logMessage,
	    final Throwable exception) {
	LOGGER.error(logMessage, exception);
    }
}
