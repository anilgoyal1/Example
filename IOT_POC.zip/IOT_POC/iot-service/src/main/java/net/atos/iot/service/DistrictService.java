package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.DistrictDTO;

/**
 * This is a service interface used for District service operations.
 * 
 * @author a602834
 *
 */
public interface DistrictService {

	/**
	 * This method is used to get District list.
	 * 
	 * @return list of DistrictDTO
	 */
	List<DistrictDTO> getDistricts(boolean active);

	/**
	 * This method is used to save District.
	 * 
	 * @param districtDto
	 * @return saved District.
	 */
	String saveDistricts(DistrictDTO districtDto);

	DistrictDTO getDistrictByDistrictCode(Integer districtCode);

	String deleteDistrict(Integer districtCode);

	String updateDistrict(DistrictDTO district);

}