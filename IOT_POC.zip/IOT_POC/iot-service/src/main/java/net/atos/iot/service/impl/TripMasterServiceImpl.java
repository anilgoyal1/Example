package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.TripMasterDTO;
import net.atos.iot.entity.TripMaster;
import net.atos.iot.repository.TripMasterRepository;
import net.atos.iot.service.TripMasterService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TripMasterServiceImpl implements TripMasterService {

	private static final Logger logger = Logger
			.getLogger(TripMasterServiceImpl.class);

	@Autowired
	private TripMasterRepository tripMasterDao;

	private Mapper mapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Override
	public Long startTrip(TripMasterDTO tripMasteDTO) {
		Long tripId = 0l;
		try {
			if (tripMasteDTO != null) {
				TripMaster tripMaster = mapper.map(tripMasteDTO,
						TripMaster.class);
				if (tripMaster != null) {
					tripMaster = tripMasterDao.save(tripMaster);
					if (tripMaster != null) {
						tripId = tripMaster.getTripId();
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}

		return tripId;
	}

	@Override
	public String endTrip(Long tripId) {
		Date startTime = null;
		Date endTime = null;
		long tripDuration = 0;
		long tripEstimationTime = 0;
		String tripFeedback = null;
		try {
			if (tripId != null && tripId > 0) {
				TripMaster tripMaster = tripMasterDao.getTripByTripId(tripId);
				if (tripMaster != null) {

					startTime = tripMaster.getTripStartTime();
					endTime = new Date();
					if (startTime != null) {
						tripEstimationTime = tripMaster
								.getEstimationTimeInMinute();
						tripDuration = DateUtil.differenceInMinute(
								startTime, endTime);
						if (tripDuration - 10 > tripEstimationTime) {
							tripFeedback = IotConstants.BEFORE_TIME;

						} else if (tripDuration > tripEstimationTime) {
							tripFeedback = IotConstants.ON_TIME;
						} else {
							tripFeedback = IotConstants.AFTER_TIME;
						}
					}
					tripMaster.setTripDurationInMinute(tripDuration);
					tripMaster.setTripStatus(IotConstants.ENDED);
					tripMaster.setTripFeedback(tripFeedback);
					tripMaster.setTripEndTime(new Date());
					if (tripMasterDao.save(tripMaster) != null) {
						return IotConstants.SUCCESS;
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}

		return IotConstants.FAILURE;

	}

	@Override
	public TripMasterDTO getTripByTripId(long tripId) {
		TripMasterDTO tripMasterDTO = null;
		if (tripId != 0) {
			try {
				TripMaster tripMaster = tripMasterDao.getTripByTripId(tripId);
				if (tripMaster != null) {
					tripMasterDTO = mapper.map(tripMaster, TripMasterDTO.class);
				}
			} catch (Exception e) {
				logger.error("Exception ", e);
			}

		}
		return tripMasterDTO;
	}

	@Override
	public List<TripMasterDTO> getAllTrips() {
		List<TripMasterDTO> tripMasterDTOList = null;
		try {
			List<TripMaster> tripMasterList = tripMasterDao.findAll();
			if (tripMasterList != null) {
				tripMasterDTOList = new ArrayList<>();
				TripMasterDTO tripMasterDTO = null;
				for (TripMaster tripMaster : tripMasterList) {
					tripMasterDTO = mapper.map(tripMaster, TripMasterDTO.class);
					if (tripMasterDTO != null) {
						tripMasterDTOList.add(tripMasterDTO);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		if (tripMasterDTOList == null) {
			tripMasterDTOList = new ArrayList<>();
		}
		return tripMasterDTOList;
	}

	@Override
	public List<TripMasterDTO> findAllTripsByTripStatus(String tripStatus) {
		List<TripMasterDTO> tripMasterDTOList = null;
		try {
			if (tripStatus != null && tripStatus.length() > 0) {
				List<TripMaster> tripMasterList = tripMasterDao
						.getTripByTripStatus(tripStatus);
				if (tripMasterList != null) {
					tripMasterDTOList = new ArrayList<>();
					TripMasterDTO tripMasterDTO = null;
					for (TripMaster tripMaster : tripMasterList) {
						tripMasterDTO = mapper.map(tripMaster,
								TripMasterDTO.class);
						if (tripMasterDTO != null) {
							tripMasterDTOList.add(tripMasterDTO);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		if (tripMasterDTOList == null) {
			tripMasterDTOList = new ArrayList<>();
		}
		return tripMasterDTOList;
	}

	@Override
	public void deleteTripsByDevicesIds(List<String> deviceIds) {
		if (deviceIds != null && deviceIds.size() > 0) {
			tripMasterDao.deleteTripMasterByDeviceIds(deviceIds);
		}
	}

}
