package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.CreateOrchestratedDeviceRequestDTO;

public interface OrchestratorService {

	public String createDevice(CreateOrchestratedDeviceRequestDTO requestDTO);

	String createDeviceWithSimulationId(List<String> deviceIds, Integer tenantId);
	
	
}
