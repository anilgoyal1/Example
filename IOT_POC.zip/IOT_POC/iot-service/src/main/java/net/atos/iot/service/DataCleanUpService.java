package net.atos.iot.service;

import java.util.List;

public interface DataCleanUpService {

	String cleanDataByTenantId(Integer tenantId);

	String cleanDataForAllTenant();

	String cleanAllDataByDeviceIds(List<String> deviceIds);


}
