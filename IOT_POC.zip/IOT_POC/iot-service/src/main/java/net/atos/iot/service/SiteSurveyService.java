package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.SiteSurveyDTO;

public interface SiteSurveyService {

	public String completeSiteSurvey(SiteSurveyDTO siteSurveyDTO);

	public List<SiteSurveyDTO> listSiteSurveyDTO();

	public String createSiteSurvey(SiteSurveyDTO siteSurveyDTO);

	public List<SiteSurveyDTO> listSiteSurveyByTenantId(Integer tenantId);

	public SiteSurveyDTO getSiteSurveyByDeviceId(String deviceId);

}
