package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.UserDetailsDTO;

public interface UserDetailsService {

	List<UserDetailsDTO> getAllUsers(boolean active);

	String createUser(UserDetailsDTO userDetailsDTO);

	UserDetailsDTO getUserDetailsByUserDetailsId(Integer userDetailsId);
	
	UserDetailsDTO getUserDetailsByUserId(String userId);

	String deleteUserDetails(Integer userDetailsId);

	String updateUserDetaills(UserDetailsDTO userDetailsDTO);

}
