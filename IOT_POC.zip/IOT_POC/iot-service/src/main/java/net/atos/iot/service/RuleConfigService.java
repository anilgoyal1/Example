package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.RuleConfigDTO;
import net.atos.iot.entity.RuleConfig;

public interface RuleConfigService {

	public List<RuleConfigDTO> getAllRuleConfig();

	public RuleConfigDTO getAllruleConfigByRuleCode(String rule_code);

	public String addRuleConfig(final RuleConfigDTO ruleConfigDTO);

	public String deleteRuleConfig(String ruleCode);

	public String updateRuleConfig(RuleConfigDTO ruleConfigDTO);
	
	public RuleConfig getAllruleConfigEntityByRuleCode(String rule_code);

}
