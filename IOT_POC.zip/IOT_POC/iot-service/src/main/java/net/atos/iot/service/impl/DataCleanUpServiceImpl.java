package net.atos.iot.service.impl;

import java.util.List;

import net.atos.iot.dto.TenantDTO;
import net.atos.iot.repository.DeviceMasterRepository;
import net.atos.iot.repository.SiteSurveyRepository;
import net.atos.iot.service.AlertDataService;
import net.atos.iot.service.DataCleanUpService;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.EdgeGatewaySimulationService;
import net.atos.iot.service.GPSSensorDataService;
import net.atos.iot.service.SensorDataService;
import net.atos.iot.service.TenantService;
import net.atos.iot.service.TicketService;
import net.atos.iot.service.TripMasterService;
import net.atos.iot.util.IotConstants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataCleanUpServiceImpl implements DataCleanUpService {

	@Autowired
	private TicketService ticketService;

	@Autowired
	private TripMasterService tripMasterService;

	@Autowired
	private GPSSensorDataService gpsSensorDataService;

	@Autowired
	private SensorDataService sensorDataService;

	@Autowired
	private AlertDataService alertDataService;

	@Autowired
	private DeviceMasterRepository deviceMasterDao;

	@Autowired
	private TenantService tenantService;

	@Autowired
	private SiteSurveyRepository siteSurveyDao;

	@Autowired
	private DeviceMasterService deviceMasterService;

	@Autowired
	EdgeGatewaySimulationService edgeGatewaySimulationService;

	@Override
	public String cleanDataByTenantId(Integer tenantId) {
		if (tenantId != null && tenantId > 0) {
			if (edgeGatewaySimulationService
					.checkRunningSimulationForTenant(tenantId)) {
				return "Simulation Already running for tenant please delete simulation first";
			}
			List<String> deviceIdList = deviceMasterDao
					.findAllSimulatedDeviceByTenantId(tenantId);
			if (deviceIdList != null && !deviceIdList.isEmpty()) {
				return cleanDataByDeviceIds(deviceIdList);
			}
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String cleanDataForAllTenant() {
		List<TenantDTO> tenants = tenantService.getAllTenants(true);
		if (tenants != null && !tenants.isEmpty()) {

			for (TenantDTO tenantDTO : tenants) {
				cleanDataByTenantId(tenantDTO.getTenantId());
			}
		}
		return IotConstants.SUCCESS;
	}

	@Override
	public String cleanAllDataByDeviceIds(List<String> deviceIds) {
		return cleanDataByDeviceIds(deviceIds);
	}

	private String cleanDataByDeviceIds(List<String> deviceIdList) {
		if (deviceIdList != null && deviceIdList.size() > 0) {
			sensorDataService.deleteAllSensorDataByDeviceIds(deviceIdList);
			alertDataService.deleteAlertDataByDeviceIds(deviceIdList);
			ticketService.deleteAllTicketsByDeviceIds(deviceIdList);
			gpsSensorDataService
					.deleteAllGPSSensorDataByDeviceIds(deviceIdList);
			tripMasterService.deleteTripsByDevicesIds(deviceIdList);
			for (String deviceId : deviceIdList) {
				siteSurveyDao.deleteSiteSurveyByDeviceIds(deviceId);
			}
			deviceMasterService.deleteDevicesByDeviceIds(deviceIdList);
			return IotConstants.SUCCESS;
		}
		return IotConstants.FAILURE;
	}

}
