package net.atos.iot.service;

import java.util.Date;
import java.util.List;

import net.atos.iot.dto.GPSSensorDataDTO;
import net.atos.iot.entity.GPSSensorData;

public interface GPSSensorDataService {

	public List<GPSSensorDataDTO> getGPSGPSSensorDataByDeviceId(
			String deviceId, String filterData);

	public List<GPSSensorDataDTO> getAllGPSSensorData();

	List<GPSSensorDataDTO> getGPSSensorDataByCreatedDateAndDeviceId(
			String deviceId, Date fromDate, Date toDate);

	List<GPSSensorDataDTO> getGPSSensorDataByTenantId(Integer tenantId,
			String filterData);

	GPSSensorData getGPSSensorDataByTripId(Long tripId);

	void SaveGpsSensorData(GPSSensorData sensorData);

	void deleteAllGPSSensorDataByDeviceIds(List<String> deviceIds);

}
