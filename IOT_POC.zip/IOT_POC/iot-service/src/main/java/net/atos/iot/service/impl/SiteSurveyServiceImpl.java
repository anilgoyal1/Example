package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.DeviceMasterDTO;
import net.atos.iot.dto.SiteSurveyDTO;
import net.atos.iot.entity.DeviceMaster;
import net.atos.iot.entity.SiteSurvey;
import net.atos.iot.repository.DeviceMasterRepository;
import net.atos.iot.repository.SiteSurveyRepository;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.DeviceStatusMasterService;
import net.atos.iot.service.SiteSurveyService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SiteSurveyServiceImpl implements SiteSurveyService {

	private static final Logger logger = Logger
			.getLogger(SiteSurveyServiceImpl.class);

	@Autowired
	private SiteSurveyRepository siteSurveyDao;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Autowired
	private DeviceMasterService deviceMasterSerivce;

	@Autowired
	private DeviceMasterRepository deviceMasterDao;;

	@Autowired
	private DeviceStatusMasterService deviceStatusMasterService;

	@Override
	public String completeSiteSurvey(SiteSurveyDTO siteSurveyDTO) {
		try {
			if (siteSurveyDTO != null) {
				if (siteSurveyDTO.getDeviceMaster() != null) {
					DeviceMasterDTO deviceMasterDTO = siteSurveyDTO
							.getDeviceMaster();

					SiteSurvey siteSurvey = siteSurveyDao
							.getSiteSurveyBySurveyId(siteSurveyDTO
									.getSurveyId());
					if (siteSurvey != null) {

						if (siteSurveyDTO.getNewStatus().equalsIgnoreCase(
								IotConstants.ticketTypeAssigned)) {
							return "Site Survey with Id "
									+ siteSurvey.getSurveyId()
									+ " is already assinged";
						}

						DeviceMaster deviceMaster = deviceMasterDao
								.getDeviceByDeviceId(deviceMasterDTO
										.getDeviceId());
						siteSurvey.setDeviceMaster(deviceMaster);
						siteSurvey.setStatus(siteSurveyDTO.getNewStatus());
						siteSurvey.setAddress(siteSurveyDTO.getAddress());

						siteSurvey.setCompletedBy(siteSurveyDTO
								.getCompletedBy());
						siteSurvey.setNetworkConnectivitCheck(siteSurveyDTO
								.getNetworkConnectivitCheck());
						siteSurvey.setNetworkType(siteSurveyDTO
								.getNetworkType());

						siteSurvey.setSiteName(siteSurveyDTO.getSiteName());
						siteSurvey.setPhone(siteSurveyDTO.getPhone());
						siteSurvey.setRoomName(siteSurveyDTO.getRoomName());
						siteSurvey.setExactLocation(siteSurveyDTO
								.getExactLocation());
						siteSurvey.setIpAddressofDevice(siteSurveyDTO
								.getIpAddressofDevice());
						siteSurvey
								.setHasRemoteConnectivityWithEdgeGatway(siteSurveyDTO
										.getHasRemoteConnectivityWithEdgeGatway());

						siteSurvey.setCompletedDate(new Date());
						siteSurveyDao.save(siteSurvey);
						return IotConstants.SUCCESS;
					}
				}

			}

		} catch (Exception e) {
			logger.error("Exception e", e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public List<SiteSurveyDTO> listSiteSurveyDTO() {
		List<SiteSurveyDTO> siteSurveyDTOList = null;
		try {
			List<SiteSurvey> siteSurveyList = siteSurveyDao.getAllSiteSurvey();
			if (siteSurveyList != null) {
				siteSurveyDTOList = new ArrayList<SiteSurveyDTO>();
				SiteSurveyDTO siteSurveyDTO = null;
				for (SiteSurvey siteSurvey : siteSurveyList) {
					siteSurveyDTO = dMapper
							.map(siteSurvey, SiteSurveyDTO.class);
					if (siteSurveyDTO != null) {
						siteSurveyDTOList.add(siteSurveyDTO);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception e");
		}

		if (siteSurveyDTOList == null) {
			siteSurveyDTOList = new ArrayList<SiteSurveyDTO>();
		}
		return siteSurveyDTOList;
	}

	@Override
	public String createSiteSurvey(SiteSurveyDTO siteSurveyDTO) {
		try {
			if (siteSurveyDTO != null) {
				if (siteSurveyDTO.getDeviceMaster() != null) {
					DeviceMasterDTO deviceMasterDTO = siteSurveyDTO
							.getDeviceMaster();
					if (deviceMasterDTO != null
							&& deviceMasterDTO.getDeviceId() != null
							&& !deviceMasterDTO.getDeviceId().isEmpty()) {
						SiteSurvey existingSiteSurvey = siteSurveyDao
								.findSiteSurveyByDeviceId(deviceMasterDTO
										.getDeviceId());
						if (existingSiteSurvey != null) {
							return "Site survey already exist for device "
									+ deviceMasterDTO.getDeviceId();
						}
					}
					SiteSurvey siteSurvey = dMapper.map(siteSurveyDTO,
							SiteSurvey.class);
					if (siteSurvey != null) {
						DeviceMaster deviceMaster = deviceMasterDao
								.getDeviceByDeviceId(deviceMasterDTO
										.getDeviceId());
						siteSurvey.setDeviceMaster(deviceMaster);
						siteSurveyDao.save(siteSurvey);
						return IotConstants.SUCCESS;

					}
				}

			}

		} catch (Exception e) {
			logger.error("Exception e");
		}
		return IotConstants.FAILURE;
	}

	@Override
	public List<SiteSurveyDTO> listSiteSurveyByTenantId(Integer tenantId) {
		List<SiteSurveyDTO> siteSurveyDTOList = null;
		try {

			if (tenantId != null && tenantId > 0) {
				List<String> deviceIds = deviceMasterSerivce
						.getDeviceIdsByTenantId(tenantId);
				System.out.println(deviceIds.toString());
				if (deviceIds != null && !deviceIds.isEmpty()) {
					List<SiteSurvey> siteSurveyList = siteSurveyDao
							.findSiteSurveyByDeviceIds(deviceIds);
					siteSurveyDTOList = new ArrayList<SiteSurveyDTO>();
					SiteSurveyDTO siteSurveyDTO = null;
					for (SiteSurvey siteSurvey : siteSurveyList) {
						siteSurveyDTO = dMapper.map(siteSurvey,
								SiteSurveyDTO.class);
						if (siteSurveyDTO != null) {
							siteSurveyDTOList.add(siteSurveyDTO);
						}
					}
				}

			}
		} catch (Exception e) {
			logger.error("Exception e");
		}

		if (siteSurveyDTOList == null) {
			siteSurveyDTOList = new ArrayList<SiteSurveyDTO>();
		}
		return siteSurveyDTOList;
	}

	@Override
	public SiteSurveyDTO getSiteSurveyByDeviceId(String deviceId) {
		SiteSurveyDTO siteSurveyDTO = null;
		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				SiteSurvey siteSurvey = siteSurveyDao
						.findSiteSurveyByDeviceId(deviceId);
				if (siteSurvey != null) {
					siteSurveyDTO = dMapper
							.map(siteSurvey, SiteSurveyDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error("Exception e");
		}
		return siteSurveyDTO;
	}

}
