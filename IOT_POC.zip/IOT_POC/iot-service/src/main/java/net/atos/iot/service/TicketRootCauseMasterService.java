package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.TicketRootCauseDTO;

public interface TicketRootCauseMasterService {

	List<TicketRootCauseDTO> getAllRootCauses();

	String addTicketRootCause(TicketRootCauseDTO ticketRootCauseDTO);

	String deleteTicketRootCauase(Integer rootCauseId);

}
