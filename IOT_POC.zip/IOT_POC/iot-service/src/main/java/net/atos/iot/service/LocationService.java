package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.LocationDTO;

public interface LocationService {

	public List<LocationDTO> getAllLocation(boolean active);

	public String saveLocation(LocationDTO locationDto);

	public List<LocationDTO> getAllLocationByLocSubtype(String locSubtype);

	public LocationDTO getLocationByLocCode(String locCode);

	String deleteLocation(Long locationId);

	public LocationDTO getLocationByLocationId(Long locationId);

	String updateLocation(LocationDTO locationDTO);

}
