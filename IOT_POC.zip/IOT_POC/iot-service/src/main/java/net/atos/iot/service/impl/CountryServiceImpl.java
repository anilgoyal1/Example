package net.atos.iot.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import net.atos.iot.dto.CountryDTO;
import net.atos.iot.entity.Country;
import net.atos.iot.entity.Region;
import net.atos.iot.repository.CountryRepository;
import net.atos.iot.repository.RegionRepository;
import net.atos.iot.service.CountryService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is a service class used for Country operations.
 * 
 * @author a602834
 *
 */
@Component("countryServiceImpl")
public class CountryServiceImpl implements CountryService {

	private static final Logger LOGGER = Logger
			.getLogger(CountryServiceImpl.class);

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private RegionRepository regionDao;

	private Mapper mapper = DozerBeanMapperFactory.getDozerBeanMapper();

	/*
	 * (non-Javadoc)
	 * 
	 * @see net.atos.soclomo.location.service.CountryService#getCountries()
	 */
	@Override
	@Transactional
	public List<CountryDTO> getCountries(boolean active) {
		List<CountryDTO> listOfCountries = null;
		try {
			List<Country> countries = countryRepository
					.findAllCountries(active);
			if (countries != null && !countries.isEmpty()) {
				CountryDTO countryDTO = null;
				listOfCountries = new ArrayList<CountryDTO>();
				for (Country country : countries) {
					countryDTO = mapper.map(country, CountryDTO.class);
					listOfCountries.add(countryDTO);
				}
			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		if (listOfCountries == null) {
			listOfCountries = new ArrayList<CountryDTO>(0);
		}
		return listOfCountries;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * net.atos.soclomo.location.service.CountryService#saveCountries(net.atos
	 * .soclomo.location.common.dto.CountryDTO)
	 */
	@Transactional
	@Override
	public String saveCountry(final CountryDTO countryDTO) {
		Country country = null;
		System.out.println("inside saveCountryMethod ");
		try {
			if (countryDTO != null && countryDTO.getCountryCode() != null) {
				country = countryRepository
						.findCountryCodeByCoutryCode(countryDTO
								.getCountryCode());
				if (null == country) {
					return addNewCountry(countryDTO);

				} else {
					return "country already exists";
				}
			}

		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	private String addNewCountry(CountryDTO countryDTO) {
		try {
			if (countryDTO != null) {
				Country country = mapper.map(countryDTO, Country.class);
				country.setCreatedDate(new Timestamp(new Date().getTime()));
				country = countryRepository.saveAndFlush(country);
				return IotConstants.SUCCESS;

			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;

	}

	@Override
	public String updateCountry(CountryDTO countryDTO) {
		try {
			if (countryDTO != null && countryDTO.getCountryCode() != null) {
				Country country = countryRepository
						.findCountryCodeByCountryId(countryDTO.getCountryId());
				if (country != null) {
					country.setModifiedDate(new Timestamp(new Date().getTime()));
					country.setModifiedBy(countryDTO.getModifiedBy());
					country.setActive(countryDTO.isActive());
					country.setCountryName(countryDTO.getCountryName());
					country.setCountryCode(countryDTO.getCountryCode());
					country = countryRepository.saveAndFlush(country);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String deleteCountry(Integer countryId) {
		try {
			if (countryId != null && countryId > 0) {
				Country country = countryRepository
						.findCountryByCountryId(countryId);
				if (country != null) {
					country.setActive(IotConstants.FALSE);
					country.setModifiedDate(new Timestamp(new Date().getTime()));
					countryRepository.save(country);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;

	}

	@Override
	public CountryDTO getCountryByCountryId(Integer countryId) {
		CountryDTO countryDTO = null;
		try {
			if (countryId != null && countryId > 0) {
				Country country = countryRepository
						.findCountryByCountryId(countryId);
				if (country != null) {
					countryDTO = mapper.map(country, CountryDTO.class);

				}
			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}

		return countryDTO;
	}

	@Override
	// public CountryDTO assignRegionsToCountry(Map<String, Object> hashMap) {
	public Integer assignRegionsToCountry(Map<String, Object> hashMap) {
		Integer countryId = (Integer) hashMap.get("countryId");
		@SuppressWarnings("unchecked")
		List<Integer> regionsIds = (List<Integer>) hashMap.get("regionsIdList");
		return this.assignRegionsToCountry(regionsIds, countryId);
	}

	// private CountryDTO assignRegionsToCountry(List<Integer> regionsIds,
	// Integer countryId) {
	@Transactional
	private Integer assignRegionsToCountry(List<Integer> regionsIds,
			Integer countryId) {
		CountryDTO countryDTO = null;
		try {
			if (countryId > 0) {
				Country country = countryRepository
						.findCountryByCountryId(countryId);
				if (country != null) {
					List<Region> regions = regionDao
							.findRegionsByIds(regionsIds);

					System.out.println("regions length from database "
							+ regions.size());

					if (country.getRegions() != null
							&& country.getRegions().size() > 0) {

						System.out.println("regions size is " + regions.size());
						for (Region region : regions) {
							System.out.println("===");
							if (!country.getRegions().contains(region)
									&& region.isActive()) {
								country.getRegions().add(region);
							}
						}

					} else {
						System.out.println("setting region list into country ");
						country.setCountryName("Test");
						country.getRegions().addAll(regions);
					}

					Integer test = countryRepository.saveAndFlush(country)
							.getCountryId();
					// country = countryRepository.saveAndFlush(country);
					return test;
					// countryDTO = mapper.map(country, CountryDTO.class);
				}
			} else {
				LOGGER.info("country is not avaiable ");
			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}

		return -1;
	}
}
