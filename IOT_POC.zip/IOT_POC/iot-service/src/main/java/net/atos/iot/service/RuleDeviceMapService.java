package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.RuleDeviceMapDTO;

public interface RuleDeviceMapService {

	List<RuleDeviceMapDTO> listRuleDeviceMap();

	String saveRuleDeviceMap(List<RuleDeviceMapDTO> ruleDeviceMapDTOs);

	String deleteRuleDeviceMap(String ruleCode, String deviceId);

	String updateRuleDeviceMapById(RuleDeviceMapDTO ruleDeviceMapDTO);

	RuleDeviceMapDTO getRuleDeviceMapById(Long id);

}
