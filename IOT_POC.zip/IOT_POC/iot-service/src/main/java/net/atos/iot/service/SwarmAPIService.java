package net.atos.iot.service;

import java.io.IOException;

public interface SwarmAPIService {

	public void startSwarmContainer(String deviceId, String simulationName,
			Integer minTemperature, Integer maxTemperature,
			Integer minHumidity, Integer maxHumidity) throws IOException;

	public void deleteSwarmContainer(String simulationName) throws IOException;

	public String checkStatusOfSwarmContainer(String simulationName)
			throws Exception;

}
