package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.BranchDTO;

/**
 * This is a service interface used for Branch operations.
 * 
 * @author A596108
 *
 */
public interface BranchService {

	/**
	 * This method is used to get Branch list.
	 * 
	 * @return list Branch dto.
	 */
	List<BranchDTO> getBranches(boolean active);

	/**
	 * This method is used to save the Branch.
	 * 
	 * @param branch
	 * @return saved Branch.
	 */
	String savebranches(BranchDTO branch);

	/**
	 * This method is used to delete branch.
	 * 
	 * @param branch
	 * @return deleted Branch
	 */
	String deleteBranch(Long branchId);

	BranchDTO getBranchByBranchCode(String branchCode);

	BranchDTO getBranchByBranchId(Long branchId);

	String updateBranch(BranchDTO branch);
}
