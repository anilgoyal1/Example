package net.atos.iot.service.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.DeviceMasterDTO;
import net.atos.iot.dto.GPSSensorDataDTO;
import net.atos.iot.entity.GPSSensorData;
import net.atos.iot.repository.GPSSensorDataRepository;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.GPSSensorDataService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GPSSensorDataServiceImpl implements GPSSensorDataService {

	private static final Logger logger = Logger
			.getLogger(GPSSensorDataServiceImpl.class);

	@Autowired
	private GPSSensorDataRepository gpsSensorDataRepository;

	@Autowired
	private DeviceMasterService deviceMasterService;

	private Mapper mapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Override
	public List<GPSSensorDataDTO> getGPSGPSSensorDataByDeviceId(
			String deviceId, String filterData) {
		List<GPSSensorData> gpsAlertDataList = null;
		List<GPSSensorDataDTO> gpsAlertDataDTOList = null;

		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				if (filterData == null) {
					gpsAlertDataList = gpsSensorDataRepository
							.findGPSSensorDataByDeviceId(deviceId);
				} else {

					gpsAlertDataList = this.getGPSAlertDataByDate(deviceId,
							filterData);
				}

				if (gpsAlertDataList != null) {
					gpsAlertDataDTOList = new ArrayList<GPSSensorDataDTO>();
					GPSSensorDataDTO alertDataDTO = null;
					for (GPSSensorData alertData : gpsAlertDataList) {
						alertDataDTO = mapper.map(alertData,
								GPSSensorDataDTO.class);
						gpsAlertDataDTOList.add(alertDataDTO);
					}
				}

			}
		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		if (gpsAlertDataDTOList == null) {
			gpsAlertDataDTOList = new ArrayList<GPSSensorDataDTO>();
		}
		return gpsAlertDataDTOList;
	}

	private List<GPSSensorData> getGPSAlertDataByDate(String deviceId,
			String filterData) {
		List<GPSSensorData> gpsAlertDataList = null;
		Date fromDate = null, toDate = null;
		String fromDateStr = null;
		String toDateStr = null;
		Calendar c = null;
		JSONObject reportInputJson = null;
		reportInputJson = new JSONObject(filterData);
		if (!reportInputJson.isNull(IotConstants.fromDate)) {
			fromDateStr = reportInputJson.getString(IotConstants.fromDate);
			try {
				fromDate = DateUtil.convertISOStringToLocalDate(fromDateStr);
			} catch (ParseException e) {
				logger.error("Exception ", e);
			}
			if (!reportInputJson.isNull(IotConstants.toDate)) {
				toDateStr = reportInputJson.getString(IotConstants.toDate);
				try {
					toDate = DateUtil.convertISOStringToLocalDate(toDateStr);
				} catch (ParseException e) {
					logger.error("Exception ", e);
				}

			}
			if (fromDate == null || toDate == null) {
				fromDate = DateUtil
						.convertDateAndTimeToBeginingOfDate(new Date());
				toDate = DateUtil.convertDateAndTimeToEndOfDate(new Date());
			}
			gpsAlertDataList = gpsSensorDataRepository
					.findGPSSensorDataByDeviceIdAndDate(deviceId, fromDate,
							toDate);

		}

		return gpsAlertDataList;
	}

	public List<GPSSensorDataDTO> getAllGPSSensorData() {
		List<GPSSensorData> gpsAlertDataList = null;
		List<GPSSensorDataDTO> gpsAlertDataDTOList = null;

		try {
			gpsAlertDataList = gpsSensorDataRepository.findAll();

			if (gpsAlertDataList != null) {
				gpsAlertDataDTOList = new ArrayList<GPSSensorDataDTO>();
				GPSSensorDataDTO alertDataDTO = null;
				for (GPSSensorData alertData : gpsAlertDataList) {
					alertDataDTO = mapper
							.map(alertData, GPSSensorDataDTO.class);
					gpsAlertDataDTOList.add(alertDataDTO);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("", e);
		}
		return gpsAlertDataDTOList;
	}

	@Override
	public List<GPSSensorDataDTO> getGPSSensorDataByCreatedDateAndDeviceId(
			String deviceId, Date fromDate, Date toDate) {
		List<GPSSensorData> gpsSensorDataList = null;
		List<GPSSensorDataDTO> gpsSensorDataDTOList = null;

		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				gpsSensorDataList = gpsSensorDataRepository
						.getGPSSensorDataByCreatedDateAndDeviceId(deviceId,
								fromDate, toDate);

				if (gpsSensorDataList != null) {
					gpsSensorDataDTOList = new ArrayList<GPSSensorDataDTO>();
					GPSSensorDataDTO sensorDataDTO = null;
					for (GPSSensorData sensorData : gpsSensorDataList) {
						sensorDataDTO = mapper.map(sensorData,
								GPSSensorDataDTO.class);
						gpsSensorDataDTOList.add(sensorDataDTO);
					}
				}
			}

		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		return gpsSensorDataDTOList;
	}

	@Override
	public List<GPSSensorDataDTO> getGPSSensorDataByTenantId(Integer tenantId,
			String filterData) {

		List<GPSSensorDataDTO> responseGPSSensorDTO = null;
		if (tenantId != null && tenantId > 0) {
			List<DeviceMasterDTO> deviceMasterList = deviceMasterService
					.getAllDeviceByTenantId(tenantId);
			if (deviceMasterList != null && !deviceMasterList.isEmpty()) {
				responseGPSSensorDTO = new ArrayList<GPSSensorDataDTO>();
				for (DeviceMasterDTO deviceMaster : deviceMasterList) {
					List<GPSSensorData> gpsSensorDataList = gpsSensorDataRepository
							.findGPSSensorDataByDeviceId(deviceMaster
									.getDeviceId());
					if (gpsSensorDataList != null
							&& !gpsSensorDataList.isEmpty()) {
						GPSSensorData gpsSensorData = gpsSensorDataList.get(0);
						GPSSensorDataDTO gpsSensorDataDTO = mapper.map(
								gpsSensorData, GPSSensorDataDTO.class);
						responseGPSSensorDTO.add(gpsSensorDataDTO);
					}
				}
			}
		}

		return responseGPSSensorDTO;
	}

	@Override
	public GPSSensorData getGPSSensorDataByTripId(Long tripId) {
		GPSSensorData gpsSensorData = null;
		if (tripId != null && tripId >= 0) {
			try {
				List<GPSSensorData> listOfGpsSensorData = gpsSensorDataRepository
						.findGPSSensorDataByTripId(tripId);
				if (listOfGpsSensorData != null
						&& listOfGpsSensorData.size() > 0) {
					gpsSensorData = listOfGpsSensorData.get(0);

				}
			} catch (Exception e) {
				logger.error("Exception ", e);
			}
		}
		return gpsSensorData;
	}

	@Override
	public void SaveGpsSensorData(GPSSensorData gpsSensorData) {
		if (gpsSensorData != null) {
			gpsSensorDataRepository.save(gpsSensorData);
		}
	}

	@Override
	public void deleteAllGPSSensorDataByDeviceIds(List<String> deviceIds) {
		if (deviceIds != null && !deviceIds.isEmpty()) {
			gpsSensorDataRepository.deleteGPSSensorDataByDeviceIds(deviceIds);
		}

	}

}
