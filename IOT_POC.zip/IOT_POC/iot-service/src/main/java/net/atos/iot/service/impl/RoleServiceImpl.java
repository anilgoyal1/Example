package net.atos.iot.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import net.atos.iot.dto.RoleDTO;
import net.atos.iot.entity.Role;
import net.atos.iot.repository.RoleRepository;
import net.atos.iot.service.RoleService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {

	private static final Logger logger = Logger
			.getLogger(RoleServiceImpl.class);

	@Autowired
	RoleRepository userRoleDao;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Autowired
	private EntityManagerFactory emf;

	@Override
	public String addRole(RoleDTO userRoleDto) {
		try {
			if (userRoleDto != null && userRoleDto.getRoleName() != null
					&& !userRoleDto.getRoleName().isEmpty()) {
				Role userRole = userRoleDao.findRoleByRoleName(userRoleDto
						.getRoleName());
				if (userRole == null) {
					return createNewRole(userRoleDto);
				} else {
					return "Role with role name " + userRoleDto.getRoleName()
							+ " already exisits";
				}

			}

		} catch (Exception e) {
			logger.error("Exception e");
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String updateRole(RoleDTO roleDto) {
		try {
			if (roleDto != null && roleDto.getRoleId() > 0) {
				Role userRole = userRoleDao.findRoleByRoleId(roleDto
						.getRoleId());
				if (userRole != null) {
					userRole.setModifiedDate(new Timestamp(new Date().getTime()));
					userRole.setModifiedBy(roleDto.getModifiedBy());
					userRole.setActive(roleDto.isActive());
					userRole.setRoleDescription(roleDto.getRoleDescription());
					userRole.setRoleName(roleDto.getRoleName());
					userRole = userRoleDao.saveAndFlush(userRole);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String deleteRole(int roleId) {
		if (roleId > 0) {
			Role role = userRoleDao.findRoleByRoleId(roleId);

			if (role != null) {
				role.setActive(IotConstants.FALSE);
				role.setModifiedDate(new Timestamp(new Date().getTime()));
				userRoleDao.saveAndFlush(role);
				return IotConstants.SUCCESS;

			}
		}
		return IotConstants.FAILURE;
	}

	@Override
	public List<RoleDTO> getAllRoleDtos(boolean active) {
		List<RoleDTO> roleDtoList = null;
		try {
			List<Role> roles = userRoleDao.findAllRole(active);
			if (roles != null && !roles.isEmpty()) {
				roleDtoList = new ArrayList<RoleDTO>();
				RoleDTO roleDto = null;
				for (Role role : roles) {
					roleDto = dMapper.map(role, RoleDTO.class);
					roleDtoList.add(roleDto);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (roleDtoList == null) {
			roleDtoList = new ArrayList<RoleDTO>();
		}
		return roleDtoList;

	}

	@Override
	public RoleDTO getRoleDtoByRoleId(int roleId) {
		RoleDTO roleDto = null;
		try {
			Role role = userRoleDao.findRoleByRoleId(roleId);
			if (role != null) {
				roleDto = dMapper.map(role, RoleDTO.class);
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return roleDto;
	}

	private String createNewRole(RoleDTO roleDto) {
		try {
			Role userRole = dMapper.map(roleDto, Role.class);
			if (userRole != null) {
				userRole.setCreatedDate(new Timestamp(new Date().getTime()));
				userRole.setCreatedBy(roleDto.getCreatedBy());
				userRole = userRoleDao.saveAndFlush(userRole);
			}
			return IotConstants.SUCCESS;
		} catch (Exception e) {
			logger.error("Exception ", e);
		}
		return IotConstants.FAILURE;
	}

	@Cacheable(value = "roleId")
	public Integer getRoleIdByRoleName(String roleName) {
		Integer roleId = null;
		try {
			if (roleName != null && !roleName.isEmpty()) {
				Role role = userRoleDao.findRoleByRoleName(roleName);
				if (role != null) {
					roleId = role.getRoleId();
				}
			}
		} catch (Exception e) {
			logger.info("Exception ", e);
		}
		return roleId;
	}

	@Cacheable(value = "userId")
	public String getUserIdByTenantIdAndRoleName(Integer tenantId,String roleName) {
		String userName = null;
		EntityManager entityManager = null;
		try {
			if (tenantId != null && tenantId > 0) {
				StringBuilder sql = new StringBuilder();
				sql.append("select user_id from user_details where role_id=:roleId And tenant_tenant_id=:tenantId");
				entityManager = emf.createEntityManager();
				Integer roleId = getRoleIdByRoleName(roleName);
				Query query = entityManager.createNativeQuery(sql.toString());
				query.setParameter("roleId", roleId);
				query.setParameter("tenantId", tenantId);
				List<String> userIdList = query.getResultList();
				if (userIdList != null && !userIdList.isEmpty()) {
					userName = userIdList.get(0);
				}
			}
		} catch (Exception e) {
			logger.info("Exception ", e);
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return userName;
	}

	@Override
	public Role findRoleByRoleId(int roleId) {
		Role role = null;
		try {
			role = userRoleDao.findRoleByRoleId(roleId);

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return role;
	}
}
