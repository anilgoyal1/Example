package net.atos.iot.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.RoleDTO;
import net.atos.iot.dto.TenantDTO;
import net.atos.iot.dto.UserDetailsDTO;
import net.atos.iot.entity.Role;
import net.atos.iot.entity.Tenant;
import net.atos.iot.entity.UserDetails;
import net.atos.iot.repository.UserDetailsRepository;
import net.atos.iot.service.RoleService;
import net.atos.iot.service.TenantService;
import net.atos.iot.service.UserDetailsService;
import net.atos.iot.util.Base64EncoderDecoder;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	UserDetailsRepository userDetailsDao;

	@Autowired
	RoleService roleServiceImpl;

	@Autowired
	TenantService tenantServiceImpl;

	private static final Logger logger = Logger
			.getLogger(UserDetailsServiceImpl.class);

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Override
	public List<UserDetailsDTO> getAllUsers(boolean active) {
		List<UserDetailsDTO> listOfUsers = null;
		try {
			List<UserDetails> userDetailsList = userDetailsDao
					.finalAllUsers(true);
			if (userDetailsList != null && !userDetailsList.isEmpty()) {
				listOfUsers = new ArrayList<UserDetailsDTO>();
				UserDetailsDTO userDetailsDto = null;
				for (UserDetails userDetail : userDetailsList) {
					userDetailsDto = dMapper.map(userDetail,
							UserDetailsDTO.class);
					listOfUsers.add(userDetailsDto);
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception);
		}
		if (listOfUsers == null) {
			listOfUsers = new ArrayList<UserDetailsDTO>();
		}
		return listOfUsers;
	}

	@Override
	public UserDetailsDTO getUserDetailsByUserDetailsId(Integer userDetailsId) {
		UserDetailsDTO userDetaisDTO = null;
		try {
			if (userDetailsId != null && userDetailsId > 0) {
				UserDetails userDetails = userDetailsDao
						.findActiveUserDetailsByUserDetailsId(userDetailsId,
								true);
				if (userDetails != null) {
					userDetaisDTO = dMapper.map(userDetails,
							UserDetailsDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return userDetaisDTO;
	}

	@Override
	public String deleteUserDetails(Integer userDetailsId) {
		try {
			if (userDetailsId != null && userDetailsId > 0) {
				UserDetails userDetails = userDetailsDao
						.findActiveUserDetailsByUserDetailsId(userDetailsId,
								true);
				if (userDetails != null) {
					userDetails.setActive(IotConstants.FALSE);
					userDetails.setModifiedDate(new Timestamp(new Date()
							.getTime()));
					userDetailsDao.save(userDetails);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;
	}

	@Override
	public String createUser(UserDetailsDTO userDetailsDto) {
		UserDetails userDetails = null;
		try {
			if (userDetailsDto != null && userDetailsDto.getUserId() != null
					&& !userDetailsDto.getUserId().isEmpty()) {
				userDetails = userDetailsDao
						.findUserDetailsByUserId(userDetailsDto.getUserId());
				if (userDetails == null) {
					return addNewUserDetails(userDetailsDto);
				} else {
					return "User Already Exists with Userid "
							+ userDetailsDto.getUserId();
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	private String addNewUserDetails(UserDetailsDTO userDetailsDto) {
		try {
			if (userDetailsDto != null) {
				UserDetails userDetails = dMapper.map(userDetailsDto,
						UserDetails.class);
				userDetails.setCreatedDate(new Timestamp(new Date().getTime()));
				userDetails.setPassword(Base64EncoderDecoder
						.encodeString(userDetails.getPassword()));
				RoleDTO roleDTO = userDetailsDto.getRole();
				if (roleDTO != null) {
					Role role = roleServiceImpl.findRoleByRoleId(roleDTO
							.getRoleId());
					if (role != null) {
						userDetails.setRole(role);
					}
				}

				TenantDTO tenantDto = userDetailsDto.getTenant();
				if (tenantDto != null) {
					Tenant tenant = tenantServiceImpl
							.getTenantByTenantId(tenantDto.getTenantId());
					if (tenant != null) {
						userDetails.setTenant(tenant);
					}

				}
				userDetails.setCreatedDate(new Timestamp(new Date().getTime()));
				logger.info("createUser : Successful End ");
				userDetailsDao.saveAndFlush(userDetails);
				return IotConstants.SUCCESS;
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;
	}

	@Override
	public String updateUserDetaills(UserDetailsDTO userDetailsDTO) {
		try {
			if (userDetailsDTO != null
					&& userDetailsDTO.getUserDetailsId() != null
					&& userDetailsDTO.getUserDetailsId() > 0) {
				UserDetails userDetails = userDetailsDao
						.findUserDetailsByUserDetailsId(userDetailsDTO
								.getUserDetailsId());
				if (userDetails != null) {
					userDetails.setActive(userDetailsDTO.isActive());
					userDetails.setModifiedBy(userDetailsDTO.getModifiedBy());
					userDetails.setAddress(userDetailsDTO.getAddress());
					userDetails.setEmail(userDetailsDTO.getEmail());
					userDetails.setFirstName(userDetailsDTO.getFirstName());
					userDetails.setLastName(userDetailsDTO.getLastName());
					userDetails.setMobile(userDetailsDTO.getMobile());
					userDetails.setPhone(userDetailsDTO.getPhone());
					userDetails.setUserId(userDetailsDTO.getUserId());
					RoleDTO roleDTO = userDetailsDTO.getRole();
					if (roleDTO != null) {
						Role role = roleServiceImpl.findRoleByRoleId(roleDTO
								.getRoleId());
						if (role != null) {
							userDetails.setRole(role);
						}
					}

					TenantDTO tenantDto = userDetailsDTO.getTenant();
					if (tenantDto != null) {
						Tenant tenant = tenantServiceImpl
								.getTenantByTenantId(tenantDto.getTenantId());
						if (tenant != null) {
							userDetails.setTenant(tenant);
						}

					}
					userDetailsDao.saveAndFlush(userDetails);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;
	}

	@Override
	public UserDetailsDTO getUserDetailsByUserId(String userId) {
		UserDetailsDTO userDetaisDTO = null;
		try {
			if (userId != null && !userId.isEmpty()) {
				UserDetails userDetails = userDetailsDao
						.findUserDetailsByUserId(userId);
				if (userDetails != null) {
					userDetaisDTO = dMapper.map(userDetails,
							UserDetailsDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return userDetaisDTO;
	}

}
