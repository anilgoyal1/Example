package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.CountryDTO;
import net.atos.iot.dto.RegionDTO;
import net.atos.iot.entity.Country;
import net.atos.iot.entity.Region;
import net.atos.iot.repository.CountryRepository;
import net.atos.iot.repository.RegionRepository;
import net.atos.iot.service.RegionService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is a service class used for Region operations.
 * 
 * @author a602834
 *
 */
@Component("regionServiceImpl")
public class RegionServiceImpl implements RegionService {

	private static final Logger logger = Logger
			.getLogger(RegionServiceImpl.class);

	@Autowired
	private RegionRepository regionRepository;

	@Autowired
	private CountryRepository countryRepository;

	private Mapper mapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Transactional
	public List<RegionDTO> getRegions() {
		List<Region> alRegions = null;
		List<RegionDTO> alRegionDTOs = null;
		try {
			alRegions = regionRepository.findAll();
			if (alRegions != null && !alRegions.isEmpty()) {
				alRegionDTOs = new ArrayList<RegionDTO>();
				try {
					for (Region region : alRegions) {
						RegionDTO regionDto = new RegionDTO();
						regionDto = mapper.map(region, RegionDTO.class);
						alRegionDTOs.add(regionDto);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return alRegionDTOs;
			}
		} catch (Exception e) {
			logger.error(e);
		}
		return alRegionDTOs;
	}

	@Transactional
	@Override
	public String saveRegions(RegionDTO regionDTO) {
		Region region = null;
		try {
			if (regionDTO != null && regionDTO.getRegionCode() != null
					&& !regionDTO.getRegionCode().isEmpty()) {
				region = regionRepository.findRegionByRegionCode(regionDTO
						.getRegionCode());
				if (region == null) {
					return createNewRegion(regionDTO);
				}

				else {
					logger.info("region code already exits ");
					return "region code already exists";
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Transactional
	@Override
	public String updateRegion(RegionDTO regionDTO) {
		try {
			if (regionDTO != null && regionDTO.getRegionId() != null
					&& regionDTO.getRegionId() > 0) {
				Region region = regionRepository.findRegionByRegionId(regionDTO
						.getRegionId());
				if (region != null) {
					region = mapper.map(regionDTO, Region.class);
					region.setModifiedDate(new Date());
					region.setModifiedBy(regionDTO.getModifiedBy());
					region.setActive(regionDTO.isActive());
					region.setRegionCode(regionDTO.getRegionCode());
					region.setRegionName(region.getRegionName());
					CountryDTO countryDto = regionDTO.getCountry();
					if (countryDto != null && countryDto.getCountryId() != null
							&& countryDto.getCountryId() > 0) {
						Country country = countryRepository
								.findCountryByCountryId(countryDto
										.getCountryId());
						if (country != null) {
							region.setCountry(country);
						}
					}
					region = regionRepository.saveAndFlush(region);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	private String createNewRegion(RegionDTO regionDTO) {
		try {
			if (regionDTO != null) {
				Region region = mapper.map(regionDTO, Region.class);
				if (region != null) {
					region.setCreatedDate(new Date());
					region.setModifiedDate(new Date());
					CountryDTO countryDto = regionDTO.getCountry();
					if (countryDto != null && countryDto.getCountryId() != null
							&& countryDto.getCountryId() > 0) {
						Country country = countryRepository
								.findCountryByCountryId(countryDto
										.getCountryId());
						if (country != null) {
							region.setCountry(country);
						}
					}
					region = regionRepository.saveAndFlush(region);
					return IotConstants.SUCCESS;
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String deleteRegion(String regionCode) {
		try {
			if (regionCode != null) {
				Region region = regionRepository.findByRegionCode(regionCode);
				if (region != null) {
					region.setActive(IotConstants.FALSE);
					regionRepository.save(region);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public RegionDTO getRegionByRegionCode(String regionCode) {
		RegionDTO regionDTO = null;
		try {
			if (regionCode != null) {
				Region region = regionRepository.findByRegionCode(regionCode);
				if (region != null) {
					regionDTO = mapper.map(region, RegionDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (regionDTO == null) {
			regionDTO = new RegionDTO();
		}
		return regionDTO;
	}

}
