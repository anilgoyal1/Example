package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.DeviceMasterDTO;
import net.atos.iot.dto.DeviceMasterDTOForApp;
import net.atos.iot.dto.DeviceRuleConfigDTO;

public interface DeviceMasterService {

	List<DeviceMasterDTO> listOfDeviceMaster();

	String createDeviceMaster(DeviceMasterDTO deviceMst);

	String updateDeviceMaster(final DeviceMasterDTO deviceMstDTO);

	String deleteDeviceMaster(final String deviceId);

	DeviceMasterDTO getDeviceMasterByDeviceId(String deviceId);

	String bindDeviceWithTenant(String inputString);

	String bindDeviceWithRules(DeviceRuleConfigDTO deviceRuleConfigDTO);

	String revokeRulesFromDevice(DeviceRuleConfigDTO deviceRuleConfigDTO);

	List<DeviceMasterDTO> getAllDeviceByTenantId(Integer tenantId);

	List<DeviceMasterDTO> getAllDeviceByTenantIdAndStatus(Integer tenantId,
			List<String> deviceStatus);

	public void sendDataToDeviceConfigurationQueue(String deviceId);

	public Integer getTenantIdByDeviceId(String deviceId);

	public List<String> getDeviceIdsByTenantId(Integer tenantId);

	public List<String> getAllSimulatedDeviceIdsByTenantId(Integer tenantId);

	String getDeviceStatusCountByTenantId(Integer tenantId);

	String changeDeviceStatus(String deviceId, String newStatus);

	String getDeviceStatus(String deviceId);

	List<DeviceMasterDTOForApp> getDeviceListForApp();

	void deleteDevicesByDeviceIds(List<String> deviceIds);

	void sendDeviceStatusChangedNotificationByDeviceId(String deviceId, String message);

}