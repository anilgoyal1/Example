package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.DistrictDTO;
import net.atos.iot.entity.District;
import net.atos.iot.entity.State;
import net.atos.iot.repository.DistrictRepository;
import net.atos.iot.repository.StateRepository;
import net.atos.iot.service.DistrictService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is a service class used for District operations.
 * 
 * @author a602834
 *
 */
@Component
public class DistrictServiceImpl implements DistrictService {

	private static final Logger logger = Logger
			.getLogger(DistrictServiceImpl.class);

	@Autowired
	private DistrictRepository districtRepository;

	@Autowired
	private StateRepository stateRepository;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Transactional
	@Override
	public List<DistrictDTO> getDistricts(boolean active) {
		List<DistrictDTO> districtDTOList = null;
		try {
			List<District> districtList = districtRepository
					.getAllDistrict(active);
			if (districtList != null && !districtList.isEmpty()) {
				districtDTOList = new ArrayList<DistrictDTO>();
				DistrictDTO districtDTO = null;
				for (District district : districtList) {
					districtDTO = dMapper.map(district, DistrictDTO.class);
					districtDTOList.add(districtDTO);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (districtDTOList == null) {
			districtDTOList = new ArrayList<DistrictDTO>(0);
		}
		return districtDTOList;
	}

	@Override
	@Transactional
	public String saveDistricts(DistrictDTO districtDTO) {
		logger.info("DistrictServiceImpl start ");
		District district = null;
		State state = null;
		try {
			if (districtDTO != null && districtDTO.getDistrictName() != null
					&& !districtDTO.getDistrictName().isEmpty()) {
				district = districtRepository
						.findDistrictByDistrictName(districtDTO
								.getDistrictName());
				if (null == district) {
					district = dMapper.map(districtDTO, District.class);
					district.setCreatedDate(new Date());
					district.setModifiedDate(new Date());
					if (districtDTO.getState() != null
							&& districtDTO.getState().getStateId() != null
							&& districtDTO.getState().getStateId() > 0) {
						Integer stateId = districtDTO.getState().getStateId();
						state = stateRepository.findStateByStateId(stateId);
						if (state != null) {
							district.setState(state);
						}
					}
					district = districtRepository.save(district);
					return IotConstants.SUCCESS;

				} else {
					logger.info("district already exists");
					return "district alreay exists";
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String deleteDistrict(Integer districtCode) {
		try {
			if (districtCode != null && districtCode > 0) {
				District district = districtRepository
						.findDistrictByDistrictCode(districtCode);
				if (district != null) {
					district.setActive(IotConstants.FALSE);
					district.setModifiedDate(new Date());
					districtRepository.save(district);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;

	}

	@Override
	public DistrictDTO getDistrictByDistrictCode(Integer districtCode) {
		DistrictDTO districtDTO = null;
		try {
			if (districtCode != null && districtCode > 0) {
				District district = districtRepository
						.findDistrictByDistrictCode(districtCode);
				if (district != null) {
					districtDTO = dMapper.map(district, DistrictDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return districtDTO;
	}

	@Override
	public String updateDistrict(DistrictDTO districtDTO) {
		District district = null;
		State state = null;
		try {
			if (districtDTO != null && districtDTO.getDistrictCode() != null
					&& districtDTO.getDistrictCode() > 0) {
				district = districtRepository
						.findDistrictByDistrictCode(districtDTO
								.getDistrictCode());

				if (district != null) {
					district.setDistrictCode(districtDTO.getDistrictCode());
					district.setDistrictName(districtDTO.getDistrictName());
					district.setActive(districtDTO.isActive());
					district.setModifiedBy(districtDTO.getModifiedBy());
					district.setModifiedDate(new Date());
					if (districtDTO.getState() != null
							&& district.getState().getStateId() != null
							&& district.getState().getStateId() > 0) {
						state = stateRepository.findStateByStateId(district
								.getState().getStateId());
						if (state != null) {
							district.setState(state);
						}
					}

					districtRepository.saveAndFlush(district);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;
	}
}
