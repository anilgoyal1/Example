package net.atos.iot.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import net.atos.iot.dto.EdgeGatewaySimulationDTO;
import net.atos.iot.entity.EdgeGatewaySimulation;
import net.atos.iot.entity.Tenant;
import net.atos.iot.repository.EdgeGatewaySimulationRepository;
import net.atos.iot.service.DataCleanUpService;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.DockerContainerService;
import net.atos.iot.service.EdgeGatewaySimulationService;
import net.atos.iot.service.OrchestratorService;
import net.atos.iot.service.SwarmAPIService;
import net.atos.iot.service.TenantService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EdgeGatewaySimulationServiceImpl implements
		EdgeGatewaySimulationService {

	private static final Logger logger = Logger
			.getLogger(EdgeGatewaySimulationServiceImpl.class);
	@Autowired
	EdgeGatewaySimulationRepository edgeGatewaySimulationDao;

	@Autowired
	TenantService tenantServiceImpl;

	@Autowired
	DeviceMasterService deviceMasterService;

	@Autowired
	OrchestratorService orchestratorServiceImpl;

	@Autowired
	DataCleanUpService dataCleanUpService;

	@Autowired
	SwarmAPIService swarmAPIService;

	@Autowired
	DockerContainerService dockerContainerServiceImpl;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Value("${simulatedDeviceNameInitialString}")
	private String simulatedDeviceNameInitialString;

	@Override
	@Transactional
	public String createSimulationDevicesMasterData(
			EdgeGatewaySimulationDTO edgeGatewaySimulationDTO,
			int addNumberOfDevices) {
		if (edgeGatewaySimulationDTO != null && addNumberOfDevices > 0) {
			List<String> deviceIds = null;
			String simulationName = edgeGatewaySimulationDTO
					.getSimulationName();
			Integer tenantId = edgeGatewaySimulationDTO.getTenantId();
			if (simulationName != null && !simulationName.isEmpty()
					&& tenantId != null && tenantId > 0) {
				EdgeGatewaySimulation existingEdgeGatewaySimulation = edgeGatewaySimulationDao
						.findEdgeGatewaySimulationBySimulationName(simulationName);
				if (existingEdgeGatewaySimulation != null) {
					return "Simulation already running.Please delete previous simulation";
				}
				Tenant tenant = tenantServiceImpl.getTenantByTenantId(tenantId);
				if (tenant == null) {
					return "invalid tenant Id";
				}

				deviceIds = new ArrayList<String>();
				for (int i = 0; i < addNumberOfDevices; i++) {
					deviceIds.add(simulatedDeviceNameInitialString.concat("_")
							.concat(simulationName).concat("_")
							.concat(tenant.getTenantName())
							+ i);
				}
				EdgeGatewaySimulation edgeGateWaySimulation = new EdgeGatewaySimulation();
				edgeGateWaySimulation.setDeviceIds(deviceIds);
				edgeGateWaySimulation.setSimulationName(simulationName);
				edgeGateWaySimulation.setTenantId(tenantId);
				edgeGateWaySimulation.setMaxHumidity(edgeGatewaySimulationDTO
						.getMaxHumidity());
				edgeGateWaySimulation.setMinHumidity(edgeGatewaySimulationDTO
						.getMinHumidity());
				edgeGateWaySimulation
						.setMinTemperature(edgeGatewaySimulationDTO
								.getMinTemperature());
				edgeGateWaySimulation
						.setMaxTemperature(edgeGatewaySimulationDTO
								.getMaxTemperature());
				edgeGatewaySimulationDao.save(edgeGateWaySimulation);
				return orchestratorServiceImpl.createDeviceWithSimulationId(
						deviceIds, tenantId);
			} else {
				return "Please check simulation and tenantId";
			}
		}
		return IotConstants.FAILURE;
	}

	@Override
	@Transactional
	public String removeSimulationDevicesMasterData(String simulationName) {
		try {
			if (simulationName != null && !simulationName.isEmpty()) {
				List<String> deviceIds = null;
				EdgeGatewaySimulation existingEdgeGatewaySimulation = edgeGatewaySimulationDao
						.findEdgeGatewaySimulationBySimulationName(simulationName);
				if (existingEdgeGatewaySimulation != null) {
					System.out.println("edge gateway simulation is not null");
					deviceIds = existingEdgeGatewaySimulation.getDeviceIds();
					System.out.println("device ids size " + deviceIds.size());
					existingEdgeGatewaySimulation.setDeviceIds(null);
					edgeGatewaySimulationDao
							.save(existingEdgeGatewaySimulation);
					edgeGatewaySimulationDao
							.deleteEdgeGatewaySimulationBySimulationName(simulationName);
					System.out.println("no exception after delete");
					if (deviceIds != null && deviceIds.size() > 0) {
						System.out
								.println("device ids are not null and size is "
										+ deviceIds.size());
						dataCleanUpService.cleanAllDataByDeviceIds(deviceIds);
					}
					// swarmAPIService.deleteSwarmContainer(simulationName);

				}
				return IotConstants.SUCCESS;
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return IotConstants.FAILURE;
	}

	@Override
	public List<EdgeGatewaySimulationDTO> getAllEdgeGatewaySimulationDTO() {
		List<EdgeGatewaySimulationDTO> edgeGatewaySimulationDTOList = null;
		try {
			List<EdgeGatewaySimulation> edgeGatewaySimulations = edgeGatewaySimulationDao
					.findAll();
			if (edgeGatewaySimulations != null
					&& edgeGatewaySimulations.size() > 0) {
				edgeGatewaySimulationDTOList = new ArrayList<>();
				EdgeGatewaySimulationDTO edgeGatewaySimulationDTO = null;
				for (EdgeGatewaySimulation edgeGatewaySimulation : edgeGatewaySimulations) {
					edgeGatewaySimulationDTO = dMapper.map(
							edgeGatewaySimulation,
							EdgeGatewaySimulationDTO.class);

					if (edgeGatewaySimulation.getSimulationName() != null) {
						edgeGatewaySimulationDTO
								.setSimulationStatus(swarmAPIService
										.checkStatusOfSwarmContainer(edgeGatewaySimulation
												.getSimulationName()));
					}

					if (edgeGatewaySimulationDTO != null) {
						edgeGatewaySimulationDTOList
								.add(edgeGatewaySimulationDTO);
					}
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return edgeGatewaySimulationDTOList;
	}

	@Override
	public boolean checkRunningSimulationForTenant(Integer tenantId) {
		try {
			if (tenantId != null && tenantId > 0) {
				List<EdgeGatewaySimulation> edgeGateWaySimulationList = edgeGatewaySimulationDao
						.findEdgeGatewaySimulationForTenant(tenantId);
				if (edgeGateWaySimulationList != null
						&& edgeGateWaySimulationList.size() > 0) {
					return true;
				}

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return false;
	}

	@Override
	public String startSwarmContainerBySimulationName(String simulationName) {
		try {
			if (simulationName != null && !simulationName.isEmpty()) {
				List<String> deviceIds = null;
				EdgeGatewaySimulation existingEdgeGatewaySimulation = edgeGatewaySimulationDao
						.findEdgeGatewaySimulationBySimulationName(simulationName);
				if (existingEdgeGatewaySimulation != null) {
					System.out.println("edge gateway simulation is not null");
					deviceIds = existingEdgeGatewaySimulation.getDeviceIds();
					if (deviceIds != null && deviceIds.size() > 0) {
						swarmAPIService.startSwarmContainer(deviceIds
								.toString(), simulationName,
								existingEdgeGatewaySimulation
										.getMinTemperature(),
								existingEdgeGatewaySimulation
										.getMaxTemperature(),
								existingEdgeGatewaySimulation.getMinHumidity(),
								existingEdgeGatewaySimulation.getMaxHumidity());
					}
				}

				return IotConstants.SUCCESS;

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String stopSwarmContainerBySimulationName(String simulationName) {
		try {
			if (simulationName != null && !simulationName.isEmpty()) {
				swarmAPIService.deleteSwarmContainer(simulationName);
			}
			return IotConstants.SUCCESS;
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public EdgeGatewaySimulationDTO getEdgeGateWaySimulationBySimulationName(
			String simulationName) {
		EdgeGatewaySimulationDTO edgeGatewaySimulationDTO = null;
		try {
			if (simulationName != null && !simulationName.isEmpty()) {
				EdgeGatewaySimulation edgeGatewaySimulation = edgeGatewaySimulationDao
						.findEdgeGatewaySimulationBySimulationName(simulationName);
				if (edgeGatewaySimulation != null) {
					edgeGatewaySimulationDTO = dMapper.map(
							edgeGatewaySimulation,
							EdgeGatewaySimulationDTO.class);

					if (edgeGatewaySimulation.getSimulationName() != null) {
						edgeGatewaySimulationDTO
								.setSimulationStatus(swarmAPIService
										.checkStatusOfSwarmContainer(edgeGatewaySimulation
												.getSimulationName()));
					}

				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return edgeGatewaySimulationDTO;
	}

	@Override
	public String getSwarmContainerSimulationStatusByName(String simulationName) {
		try {
			if (simulationName != null && !simulationName.isEmpty()) {
				return swarmAPIService
						.checkStatusOfSwarmContainer(simulationName);
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public List<EdgeGatewaySimulationDTO> getEdgeGateWaySimulationByTenantId(
			Integer tenantId) {
		List<EdgeGatewaySimulationDTO> edgeGatewaySimulationDTOList = null;
		try {
			if (tenantId != null && tenantId > 0) {
				List<EdgeGatewaySimulation> edgeGatewaySimulations = edgeGatewaySimulationDao
						.findEdgeGatewaySimulationForTenant(tenantId);
				if (edgeGatewaySimulations != null
						&& edgeGatewaySimulations.size() > 0) {
					edgeGatewaySimulationDTOList = new ArrayList<>();
					EdgeGatewaySimulationDTO edgeGatewaySimulationDTO = null;
					for (EdgeGatewaySimulation edgeGatewaySimulation : edgeGatewaySimulations) {
						edgeGatewaySimulationDTO = dMapper.map(
								edgeGatewaySimulation,
								EdgeGatewaySimulationDTO.class);

						if (edgeGatewaySimulation.getSimulationName() != null) {
							edgeGatewaySimulationDTO
									.setSimulationStatus(swarmAPIService
											.checkStatusOfSwarmContainer(edgeGatewaySimulation
													.getSimulationName()));
						}

						if (edgeGatewaySimulationDTO != null) {
							edgeGatewaySimulationDTOList
									.add(edgeGatewaySimulationDTO);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return edgeGatewaySimulationDTOList;
	}

	@Override
	public String createtDockerContainer(String simulationName) {
		try {
			containerOperationBySimulationName(simulationName,
					IotConstants.CREATE);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.SUCCESS;
	}

	@Override
	public String stopDockerContainerByContainerName(String simulationName) {
		try {
			containerOperationBySimulationName(simulationName,
					IotConstants.STOP);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String startDockerContainerByCotainerName(String simulationName) {
		try {
			containerOperationBySimulationName(simulationName,
					IotConstants.START);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String deleteDockerContainerBySimulationName(String simulationName) {
		try {
			containerOperationBySimulationName(simulationName,
					IotConstants.DELETE);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	private String containerOperationBySimulationName(String simulationName,
			String commandName) {
		try {
			if (simulationName != null && !simulationName.isEmpty()
					&& commandName != null && !commandName.isEmpty()) {
				EdgeGatewaySimulation existingEdgeGatewaySimulation = edgeGatewaySimulationDao
						.findEdgeGatewaySimulationBySimulationName(simulationName);
				if (existingEdgeGatewaySimulation != null) {
					List<String> deviceIds = existingEdgeGatewaySimulation
							.getDeviceIds();
					System.out.println("deviceId size is" + deviceIds.size());
					if (deviceIds != null && deviceIds.size() > 0) {
						for (String deviceId : deviceIds) {
							if (commandName
									.equalsIgnoreCase(IotConstants.CREATE)) {
								createDockerContainerByDeviceId(deviceId);
							} else if (commandName
									.equalsIgnoreCase(IotConstants.START)) {
								startDockerContainerByByDeviceId(deviceId);
							}
							if (commandName.equalsIgnoreCase(IotConstants.STOP)) {
								stopDockerContainerByByDeviceId(deviceId);
							}
							if (commandName
									.equalsIgnoreCase(IotConstants.DELETE)) {
								deleteDockerContainerByByDeviceId(deviceId);
							}

						}
					}
				}

				return IotConstants.SUCCESS;
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String createDockerContainerByDeviceId(String deviceId) {
		if (deviceId != null && !deviceId.isEmpty()) {
			try {
				dockerContainerServiceImpl.createContainer(deviceId);
			} catch (IOException e) {
				logger.error(IotConstants.Exception, e);
			}
		}

		return IotConstants.FAILURE;
	}

	@Override
	public String startDockerContainerByByDeviceId(String deviceId) {
		if (deviceId != null && !deviceId.isEmpty()) {
			try {
				dockerContainerServiceImpl.startDockerContainer(deviceId);
			} catch (IOException e) {
				logger.error(IotConstants.Exception, e);
			}
		}

		return IotConstants.FAILURE;
	}

	@Override
	public String stopDockerContainerByByDeviceId(String deviceId) {
		if (deviceId != null && !deviceId.isEmpty()) {
			try {
				dockerContainerServiceImpl.stopDockerContainer(deviceId);
			} catch (IOException e) {
				logger.error(IotConstants.Exception, e);
			}
		}

		return IotConstants.FAILURE;
	}

	@Override
	public String deleteDockerContainerByByDeviceId(String deviceId) {
		if (deviceId != null && !deviceId.isEmpty()) {
			try {
				dockerContainerServiceImpl.deleteDockerContainer(deviceId);
			} catch (IOException e) {
				logger.error(IotConstants.Exception, e);
			}
		}

		return IotConstants.FAILURE;
	}

	@Override
	public String getDockerContainerStatusByDeviceId(String deviceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDockerContainerSimulationStatus(String simulationName) {
		// TODO Auto-generated method stub
		return null;
	}

}
