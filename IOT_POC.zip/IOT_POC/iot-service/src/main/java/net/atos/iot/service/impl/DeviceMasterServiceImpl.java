package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.atos.iot.dto.DeviceMasterDTO;
import net.atos.iot.dto.DeviceMasterDTOForApp;
import net.atos.iot.dto.DeviceRuleConfigDTO;
import net.atos.iot.dto.RuleConfigDTO;
import net.atos.iot.dto.SensorDataDTO;
import net.atos.iot.dto.SiteSurveyDTO;
import net.atos.iot.dto.TicketDTO;
import net.atos.iot.entity.DeviceMaster;
import net.atos.iot.entity.DeviceStatusMaster;
import net.atos.iot.entity.RuleConfig;
import net.atos.iot.entity.Tenant;
import net.atos.iot.repository.DeviceMasterRepository;
import net.atos.iot.repository.DeviceStatusMasterRepository;
import net.atos.iot.repository.TenantRepository;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.PushNotificationService;
import net.atos.iot.service.RoleService;
import net.atos.iot.service.RuleConfigService;
import net.atos.iot.service.SensorDataService;
import net.atos.iot.service.TicketService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;
import net.atos.iot.util.SendDataToRabbitMQ;

/**
 * This is a service class used for branch operations.
 * 
 * @author a602834
 *
 */
@Service
public class DeviceMasterServiceImpl implements DeviceMasterService {

	private final static Logger logger = Logger.getLogger(DeviceMasterServiceImpl.class);

	@Autowired
	private DeviceMasterRepository deviceMasterRepository;

	@Autowired
	private DeviceStatusMasterRepository deviceStatusMasterDao;

	@Autowired
	private TenantRepository tenantRepository;

	@Autowired
	private TicketService ticketServiceImpl;

	@Autowired
	private RuleConfigService ruleConfigService;

	@Autowired
	private SendDataToRabbitMQ sendDataToRabbitMQ;

	@Autowired
	private RoleService roleService;

	@Autowired
	private SensorDataService sensorDataService;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Autowired
	private EntityManagerFactory emf;

	@Autowired
	private SiteSurveyServiceImpl siteSurveyImpl;

	@Autowired
	private PushNotificationService pushNotificationServiceImpl;

	@Value("${isDeviceStatusChangeNotificationEnabled}")
	private boolean isDeviceStatusChangeNotificationEnabled;

	@Override
	public List<DeviceMasterDTO> listOfDeviceMaster() {
		List<DeviceMasterDTO> deviceDTOList = null;
		try {
			List<DeviceMaster> listDevice = deviceMasterRepository.findAll();
			if (listDevice != null && listDevice.size() > 0) {
				deviceDTOList = new ArrayList<DeviceMasterDTO>();
				DeviceMasterDTO mstDto = null;
				for (DeviceMaster deviceEntity : listDevice) {
					mstDto = new DeviceMasterDTO();
					mstDto = dMapper.map(deviceEntity, DeviceMasterDTO.class);
					deviceDTOList.add(mstDto);
				}
			}
		} catch (Exception e) {
			logger.error("e", e);
			e.printStackTrace();
		}

		return deviceDTOList;
	}

	@Override
	@Transactional
	public String createDeviceMaster(DeviceMasterDTO deviceMst) {
		try {
			if (deviceMst != null && deviceMst.getDeviceId() != null && !deviceMst.getDeviceId().isEmpty()
					&& deviceMst.getTenant() != null) {
				DeviceMaster existingDeviceMst = deviceMasterRepository
						.getDeviceByDeviceId(deviceMst.getDeviceId().trim());
				if (existingDeviceMst != null) {
					return "Device Id already exist";
				}
				DeviceMaster deviceMstEntity = dMapper.map(deviceMst, DeviceMaster.class);
				if (deviceMstEntity != null) {
					Tenant tenant = tenantRepository.findTenantByTenantId(deviceMst.getTenant().getTenantId());
					if (tenant != null && tenant.getTenantId() != null && tenant.getTenantId() > 0) {

						if (deviceMstEntity.isSimulatedDevice()) {
							return saveSimulatedDevice(deviceMstEntity, tenant);
						} else {
							if (deviceMstEntity.getRuleConfigs() != null
									&& !deviceMstEntity.getRuleConfigs().isEmpty()) {
								Set<RuleConfig> ruleConfigSet = deviceMstEntity.getRuleConfigs();
								for (RuleConfig ruleConfig : ruleConfigSet) {
									if (ruleConfig != null) {
										if (ruleConfigService
												.getAllruleConfigByRuleCode(ruleConfig.getRuleCode()) == null) {
											logger.info("Create DeviceFailed because invalid ruleCode");
											return "Create DeviceFailed because invalid ruleCode "
													+ ruleConfig.getRuleCode();
										}
									}
								}
							}
							DeviceStatusMaster deviceMasterStatus = deviceStatusMasterDao
									.getDeviceStatusMasterIdByName(IotConstants.NewDeviceStatus);
							deviceMstEntity.setDeviceStatusMaster(deviceMasterStatus);
							deviceMstEntity.setDeviceLocationLatitude(tenant.getLatitude());
							deviceMstEntity.setDeviceLocationLongitude(tenant.getLongitude());
							deviceMstEntity.setCreatedDate(new Date());
							deviceMstEntity.setActive(true);
							String deviceId = deviceMasterRepository.saveAndFlush(deviceMstEntity).getDeviceId();
							if (deviceMstEntity.getRuleConfigs() != null
									&& !deviceMstEntity.getRuleConfigs().isEmpty()) {
								sendDataToDeviceConfigurationQueue(deviceId);
							}
							if (deviceId != null && !deviceId.equals("")) {
								TicketDTO ticketDTO = new TicketDTO();
								SiteSurveyDTO siteSurveyDTO = new SiteSurveyDTO();
								String ticketAssginedUser = roleService.getUserIdByTenantIdAndRoleName(
										deviceMstEntity.getTenant().getTenantId(), IotConstants.FIELD_ENGINEER);
								siteSurveyDTO.setAssingedDate(new Date());
								siteSurveyDTO.setAssingedTo(ticketAssginedUser);
								siteSurveyDTO.setCreateDate(new Date());
								siteSurveyDTO.setCreatedBy(IotConstants.systemUser);
								siteSurveyDTO.setStatus(IotConstants.ticketTypeAssigned);
								siteSurveyDTO.setDeviceMaster(deviceMst);
								siteSurveyImpl.createSiteSurvey(siteSurveyDTO);
								Calendar currentDate = Calendar.getInstance();
								ticketDTO.setDeviceId(deviceId);
								ticketDTO.setAlertType(IotConstants.TICKET_ALERT_TYPE_CHANGE_REQUEST);
								ticketDTO.setTicketStatus(IotConstants.ticketTypeAssigned);
								ticketDTO.setCreatedBy(IotConstants.systemUser);

								ticketDTO.setAssignedTo(ticketAssginedUser);
								ticketDTO.setAssignedDate(currentDate.getTime());
								ticketDTO.setTicketDescription(IotConstants.NEW_DEVICE_INSTALATION_TICKET_DESCRIPTION);
								currentDate.add(Calendar.HOUR_OF_DAY, 48);
								ticketDTO.setSlaTimeFrame(currentDate.getTime());
								ticketDTO.setTicketType(IotConstants.NEW_DEVICE_TICKET_TYPE);
								ticketDTO.setLevel(IotConstants.ticketLevelMedium);
								ticketServiceImpl.createTicket(ticketDTO);
								return IotConstants.SUCCESS;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("e", e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String updateDeviceMaster(DeviceMasterDTO deviceMstDTO) {
		if (deviceMstDTO != null && deviceMstDTO.getDeviceId() != null && !deviceMstDTO.getDeviceId().isEmpty()) {
			DeviceMaster deviceMstEntity = dMapper.map(deviceMstDTO, DeviceMaster.class);
			deviceMstEntity = deviceMasterRepository.save(deviceMstEntity);
			if (deviceMstEntity != null) {
				return IotConstants.SUCCESS;
			}
		}

		return IotConstants.FAILURE;
	}

	@Override
	public DeviceMasterDTO getDeviceMasterByDeviceId(String deviceId) {
		DeviceMasterDTO deviceMstDto = null;
		if (deviceId != null && !deviceId.isEmpty()) {
			DeviceMaster deviceMst = deviceMasterRepository.getDeviceByDeviceId(deviceId);
			if (deviceMst != null) {
				deviceMstDto = new DeviceMasterDTO();
				deviceMstDto = dMapper.map(deviceMst, DeviceMasterDTO.class);
			}
		}
		return deviceMstDto;
	}

	// this webservice is not used as of now we need to change it in future
	// because
	// we need to delete device data from all tables which are not interrelated
	@Override
	public String deleteDeviceMaster(String deviceId) {
		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				DeviceMaster deviceMst = deviceMasterRepository.getDeviceByDeviceId(deviceId);
				if (deviceMst != null) {
					deviceMst.setActive(IotConstants.FALSE);
					deviceMst.setModifiedDate(new Date());
					deviceMasterRepository.save(deviceMst);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String bindDeviceWithTenant(String inputString) {
		try {
			if (inputString != null) {
				JSONObject json = new JSONObject(inputString);

				if (json != null) {
					String deviceId = json.getString("deviceId");
					Integer tenantId = json.getInt("tenantId");
					if (deviceId != null && !deviceId.isEmpty() && tenantId != null && tenantId > 0) {
						Tenant tenant = tenantRepository.findTenantByTenantId(tenantId);
						DeviceMaster deviceMaster = deviceMasterRepository.getDeviceByDeviceId(deviceId);
						if (deviceMaster != null && tenant != null) {
							deviceMaster.setTenant(tenant);
							deviceMasterRepository.saveAndFlush(deviceMaster);
							return IotConstants.SUCCESS;

						}
					}
				}

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;

	}

	@Override
	public List<DeviceMasterDTO> getAllDeviceByTenantId(Integer tenantId) {
		List<DeviceMasterDTO> deviceDTOList = null;
		try {
			if (tenantId != null && tenantId > 0) {
				Tenant tenentDetail = tenantRepository.findTenantByTenantId(tenantId);
				if (tenentDetail != null) {
					String tenantName = tenentDetail.getTenantName();
					if (tenantName != null && !tenantName.isEmpty()) {
						List<DeviceMaster> deviceMasterList = null;
						if (tenantName.equalsIgnoreCase(IotConstants.BTIC_ADMIN)) {
							deviceMasterList = deviceMasterRepository.findAllByDevices();
						} else {
							deviceMasterList = deviceMasterRepository.findDeviceByTenantId(tenentDetail.getTenantId());
						}
						if (deviceMasterList != null && !deviceMasterList.isEmpty()) {
							deviceDTOList = new ArrayList<DeviceMasterDTO>();
							DeviceMasterDTO deviceMstDto = null;
							for (DeviceMaster deviceMst : deviceMasterList) {
								deviceMstDto = new DeviceMasterDTO();
								deviceMstDto = dMapper.map(deviceMst, DeviceMasterDTO.class);
								deviceDTOList.add(deviceMstDto);
							}
						}
					}
				}

			}
		} catch (Exception e) {
			logger.error("e", e);
		}
		return deviceDTOList;
	}

	@Override
	public List<DeviceMasterDTO> getAllDeviceByTenantIdAndStatus(Integer tenantId, List<String> deviceStatus) {
		List<DeviceMasterDTO> deviceDTOList = null;
		try {
			if (tenantId != null && tenantId > 0) {
				Tenant tenentDetail = tenantRepository.findTenantByTenantId(tenantId);
				if (tenentDetail != null && tenentDetail.getTenantId() > 0) {
					List<DeviceMaster> deviceMasterList = deviceMasterRepository.findDeviceByTenantIdAndStatus(tenantId,
							deviceStatus);
					deviceDTOList = new ArrayList<DeviceMasterDTO>();
					DeviceMasterDTO deviceMstDto = null;
					for (DeviceMaster deviceMst : deviceMasterList) {
						deviceMstDto = new DeviceMasterDTO();
						deviceMstDto = dMapper.map(deviceMst, DeviceMasterDTO.class);
						deviceDTOList.add(deviceMstDto);
					}
				}
			}

		} catch (Exception e) {
			logger.error("e", e);
		}
		return deviceDTOList;
	}

	@Override
	public String bindDeviceWithRules(DeviceRuleConfigDTO deviceRuleConfigDTO) {
		try {
			DeviceMaster deviceMaster = null;
			Set<RuleConfig> ruleConfigs = null;
			if (deviceRuleConfigDTO != null) {
				String deviceId = deviceRuleConfigDTO.getDeviceId();
				List<String> ruleCodes = deviceRuleConfigDTO.getRuleCodes();
				if (deviceId != null && !deviceId.isEmpty() && ruleCodes != null && !ruleCodes.isEmpty()) {
					deviceMaster = deviceMasterRepository.getDeviceByDeviceId(deviceId);
					if (deviceMaster != null) {
						RuleConfig ruleConfig = null;
						ruleConfigs = deviceMaster.getRuleConfigs();
						if (ruleConfigs == null) {
							ruleConfigs = new HashSet<RuleConfig>();
						}

						for (String ruleCode : ruleCodes) {
							ruleConfig = ruleConfigService.getAllruleConfigEntityByRuleCode(ruleCode);
							if (ruleConfig != null) {
								ruleConfigs.add(ruleConfig);
							} else {
								logger.info("can not bind device with rule rude : invalid rule Code " + ruleCode);
								return "can not bind device with rule rude : invalid rule Code " + ruleCode;
							}
						}

					}
					deviceMaster.setRuleConfigs(ruleConfigs);
					deviceMasterRepository.saveAndFlush(deviceMaster);
					sendDataToDeviceConfigurationQueue(deviceId);
					return IotConstants.SUCCESS;

				}

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public String revokeRulesFromDevice(DeviceRuleConfigDTO deviceRuleConfigDTO) {
		try {
			DeviceMaster deviceMaster = null;
			Set<RuleConfig> ruleConfigs = null;
			if (deviceRuleConfigDTO != null) {
				String deviceId = deviceRuleConfigDTO.getDeviceId();
				List<String> ruleCodes = deviceRuleConfigDTO.getRuleCodes();
				if (deviceId != null && !deviceId.isEmpty() && ruleCodes != null && !ruleCodes.isEmpty()) {
					deviceMaster = deviceMasterRepository.getDeviceByDeviceId(deviceId);
					if (deviceMaster != null) {
						ruleConfigs = deviceMaster.getRuleConfigs();
						RuleConfig ruleConfig = null;
						if (ruleConfigs == null) {
							return IotConstants.SUCCESS;
						}
						for (String ruleCode : ruleCodes) {
							ruleConfig = ruleConfigService.getAllruleConfigEntityByRuleCode(ruleCode);
							ruleConfigs.remove(ruleConfig);
						}

					}
					deviceMaster.setRuleConfigs(ruleConfigs);
					deviceMasterRepository.saveAndFlush(deviceMaster);
					return IotConstants.SUCCESS;

				}

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public void sendDataToDeviceConfigurationQueue(String deviceId) {
		JSONObject json = new JSONObject();
		try {
			DeviceMasterDTO deviceMasterDTO = getDeviceMasterByDeviceId(deviceId);
			Set<RuleConfigDTO> ruleConfigDTOs = deviceMasterDTO.getRuleConfigs();
			Set<RuleConfigDTO> temp = new HashSet<RuleConfigDTO>();
			RuleConfigDTO tempDto = null;
			for (RuleConfigDTO ruleConfigDTO : ruleConfigDTOs) {
				tempDto = ruleConfigDTO;
				tempDto.setDevices(null);
				temp.add(tempDto);
			}
			json.put("deviceId", deviceMasterDTO.getDeviceId());
			json.put("rules", temp);
			logger.info("JSON Payload send to alertRule Queue " + json.toString());
			sendDataToRabbitMQ.sendMessageToRabbitMQ(deviceMasterDTO.getDeviceId(), json.toString());

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

	}

	@Cacheable(value = "tenantName")
	public Integer getTenantIdByDeviceId(String deviceId) {
		Integer tenantId = null;
		try {
			if (deviceId != null && !deviceId.isEmpty()) {
				DeviceMaster deviceMst = deviceMasterRepository.getDeviceByDeviceId(deviceId);
				Tenant tenant = deviceMst.getTenant();
				if (tenant != null && tenant.getTenantId() != null && tenant.getTenantId() > 0) {
					tenantId = tenant.getTenantId();
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return tenantId;
	}

	public List<String> getDeviceIdsByTenantId(Integer tenantId) {
		List<String> deviceList = null;
		try {
			if (tenantId != null && tenantId > 0) {
				List<DeviceMasterDTO> deviceMstList = this.getAllDeviceByTenantId(tenantId);
				if (deviceMstList != null && deviceMstList.size() > 0) {
					deviceList = new ArrayList<String>();
					for (DeviceMasterDTO deviceMstDTO : deviceMstList) {
						deviceList.add(deviceMstDTO.getDeviceId());
					}
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);

		}

		return deviceList;
	}

	@Override
	@Cacheable
	public String getDeviceStatusCountByTenantId(Integer tenantId) {
		List<Object[]> response = null;
		JSONArray responseArray = new JSONArray();
		EntityManager entityManager = null;

		try {
			if (tenantId != null && tenantId > 0) {
				List<String> deviceIdList = this.getDeviceIdsByTenantId(tenantId);
				if (deviceIdList != null && !deviceIdList.isEmpty()) {
					{
						StringBuilder sql = new StringBuilder();
						sql.append("SELECT dmm.status_name,count(dmm.status_name) FROM device_mst dm ");
						sql.append("INNER JOIN device_status_master dmm ON dm.device_status_master_id =dmm.id ");
						sql.append(" where dm.device_id in(:deviceList) group by dmm.status_name ");
						entityManager = emf.createEntityManager();
						Query query = entityManager.createNativeQuery(sql.toString());
						query.setParameter("deviceList", deviceIdList);
						response = query.getResultList();
						if (response != null) {
							JSONObject json = null;
							for (Object[] obj : response) {
								json = new JSONObject();
								json.put("status", obj[0]);
								json.put("count", obj[1]);
								responseArray.put(json);

							}
						}

					}

				}

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return responseArray.toString();
	}

	@Override
	public String changeDeviceStatus(String deviceId, String newStatus) {
		String response = IotConstants.FAILURE;
		try {
			if (deviceId != null && newStatus != null && !deviceId.isEmpty() && !newStatus.isEmpty()) {
				DeviceMaster deviceMst = deviceMasterRepository.getDeviceByDeviceId(deviceId);
				if (deviceMst != null) {
					if (!deviceMst.getDeviceStatusMaster().getStatusName().equalsIgnoreCase(newStatus)) {

						if (newStatus.equalsIgnoreCase(IotConstants.liveDeviceStatus)) {
							SensorDataDTO sensorDataDTO = sensorDataService.getSensorDataMonitoringByDeviceId(deviceId);
							if (sensorDataDTO != null && sensorDataDTO.getCreatedDate() != null) {
								Date lastDataReading = sensorDataDTO.getCreatedDate();
								if (DateUtil.differenceInMinute(lastDataReading, new Date()) > 5) {
									return IotConstants.SUCCESS;
								}

							}
						}
						DeviceStatusMaster deviceStatusMaster = deviceStatusMasterDao
								.getDeviceStatusMasterIdByName(newStatus);

						if (deviceMst != null && deviceStatusMaster != null) {
							deviceMst.setDeviceStatusMaster(deviceStatusMaster);
							deviceMasterRepository.saveAndFlush(deviceMst);
							this.sendDeviceStatusChangedNotificationByDeviceId(deviceId, deviceId
									+ " Status Changed to  " + deviceMst.getDeviceStatusMaster().getStatusName());

							logger.info(deviceId.concat("status Changed to ").concat(newStatus));
							response = IotConstants.SUCCESS;
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error", e);
		}

		return response;
	}

	@Override
	public String getDeviceStatus(String deviceId) {
		String deviceStatus = null;
		if (deviceId != null && deviceId.length() > 0) {
			DeviceMaster deviceMaster = deviceMasterRepository.getDeviceByDeviceId(deviceId);
			if (deviceMaster != null) {
				deviceStatus = deviceMaster.getDeviceStatusMaster() != null
						? deviceMaster.getDeviceStatusMaster().getStatusName()
						: null;
			}
		}
		return deviceStatus;
	}

	@Override
	public List<DeviceMasterDTOForApp> getDeviceListForApp() {
		List<DeviceMasterDTOForApp> deviceMasterDTOForAppList = null;
		try {
			List<DeviceMaster> deviceMasterList = deviceMasterRepository.findAllByDevices();
			if (deviceMasterList != null && !deviceMasterList.isEmpty()) {
				deviceMasterDTOForAppList = new ArrayList<DeviceMasterDTOForApp>();
				DeviceMasterDTOForApp deviceMasterDTOForApp = null;
				for (DeviceMaster deviceMaster : deviceMasterList) {
					deviceMasterDTOForApp = new DeviceMasterDTOForApp();
					if (deviceMaster.getDeviceId() != null && !deviceMaster.getDeviceId().isEmpty()) {
						deviceMasterDTOForApp.setDeviceId(deviceMaster.getDeviceId());
						deviceMasterDTOForApp.setSimulatedDevice(deviceMaster.isSimulatedDevice());
						deviceMasterDTOForApp.setStatus(deviceMaster.getDeviceStatusMaster().getStatusName());
						deviceMasterDTOForApp.setTenantName(deviceMaster.getTenant().getTenantName());
						deviceMasterDTOForAppList.add(deviceMasterDTOForApp);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error", e);
		}
		if (deviceMasterDTOForAppList == null) {
			deviceMasterDTOForAppList = new ArrayList<DeviceMasterDTOForApp>();

		}
		return deviceMasterDTOForAppList;
	}

	private String saveSimulatedDevice(DeviceMaster deviceMstEntity, Tenant tenant) {
		try {
			DeviceStatusMaster deviceMasterStatus = deviceStatusMasterDao
					.getDeviceStatusMasterIdByName(IotConstants.PROVISIONED_DEVICE_STATUS);
			deviceMstEntity.setDeviceStatusMaster(deviceMasterStatus);
			deviceMstEntity.setCreatedDate(new Date());
			deviceMstEntity.setActive(true);
			deviceMstEntity.setDeviceLocationLatitude(tenant.getLatitude());
			deviceMstEntity.setDeviceLocationLongitude(tenant.getLongitude());
			deviceMasterRepository.saveAndFlush(deviceMstEntity).getDeviceId();
			return IotConstants.SUCCESS;
		} catch (Exception e) {
			logger.error("Error", e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public List<String> getAllSimulatedDeviceIdsByTenantId(Integer tenantId) {
		List<String> deviceList = null;
		try {
			if (tenantId != null && tenantId > 0) {
				List<DeviceMasterDTO> deviceMstList = this.getAllDeviceByTenantId(tenantId);
				if (deviceMstList != null && deviceMstList.size() > 0) {
					deviceList = new ArrayList<String>();
					for (DeviceMasterDTO deviceMstDTO : deviceMstList) {
						if (deviceMstDTO.isSimulatedDevice()) {
							deviceList.add(deviceMstDTO.getDeviceId());
						}
					}

				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);

		}

		return deviceList;

	}

	@Override
	public void deleteDevicesByDeviceIds(List<String> deviceIds) {
		if (deviceIds != null && !deviceIds.isEmpty()) {
			deviceMasterRepository.deleteDeviceMasterByDeviceIds(deviceIds);
		}
	}

	@Override
	public void sendDeviceStatusChangedNotificationByDeviceId(String deviceId, String message) {
		if (deviceId != null && !deviceId.isEmpty() && message != null && !message.isEmpty()) {
			if (isDeviceStatusChangeNotificationEnabled) {
				pushNotificationServiceImpl.sendNotficationByDeviceId(deviceId, message);
			}
		}
	}
}
