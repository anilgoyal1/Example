package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.DeviceStatusMasterDTO;
import net.atos.iot.entity.DeviceStatusMaster;

public interface DeviceStatusMasterService {

	List<DeviceStatusMasterDTO> findAllDeviceStatusMaster();

	DeviceStatusMasterDTO findDeviceStatusMasterById(Integer id);

	DeviceStatusMasterDTO getDeviceStatusMasterIdByName(String status);

	public DeviceStatusMaster getDeviceStatusMasterByStatusName(String status);

	String createDeviceStatusMaster(DeviceStatusMasterDTO deviceStatusMasterDTO);

}
