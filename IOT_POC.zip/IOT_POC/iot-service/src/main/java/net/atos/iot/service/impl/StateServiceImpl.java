package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import net.atos.iot.dto.RegionDTO;
import net.atos.iot.dto.StateDTO;
import net.atos.iot.entity.Region;
import net.atos.iot.entity.State;
import net.atos.iot.repository.RegionRepository;
import net.atos.iot.repository.StateRepository;
import net.atos.iot.service.StateService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is a service class used for State operations.
 * 
 * @author a602834
 *
 */
@Component("stateServiceImpl")
public class StateServiceImpl implements StateService {

	private static final Logger logger = Logger
			.getLogger(StateServiceImpl.class);

	@Autowired
	private StateRepository stateRepository;

	@Autowired
	private RegionRepository regionRepository;

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Transactional
	@Override
	public List<StateDTO> getStates(boolean active) {
		List<State> states = null;
		List<StateDTO> stateDtos = null;
		try {
			states = stateRepository.findAllState(active);
			if (states != null && !states.isEmpty()) {
				stateDtos = new ArrayList<StateDTO>();
				StateDTO stateDto = null;
				for (State state : states) {
					stateDto = dMapper.map(state, StateDTO.class);
					stateDtos.add(stateDto);

				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);

		}
		if (stateDtos == null) {
			stateDtos = new ArrayList<StateDTO>(0);
		}
		return stateDtos;
	}

	@Transactional
	@Override
	public String saveStates(StateDTO stateDTO) {
		State state = null;
		Region region = null;
		try {
			if (stateDTO != null && stateDTO.getStateCode() != null
					&& !stateDTO.getStateCode().isEmpty()) {
				state = stateRepository.findStateByStateCode(stateDTO
						.getStateCode());
				if (null == state) {
					state = dMapper.map(stateDTO, State.class);
					state.setCreatedDate(new Date());
					state.setModifiedDate(new Date());
					RegionDTO regionDTO = stateDTO.getRegion();
					if (regionDTO != null && regionDTO.getRegionId() != null
							&& regionDTO.getRegionId() > 0) {
						Integer regionId = stateDTO.getRegion().getRegionId();
						region = regionRepository
								.findRegionByRegionId(regionId);
						if (region != null) {
							state.setRegion(region);
						}
					}
					stateRepository.saveAndFlush(state);
					return IotConstants.SUCCESS;
				} else {
					logger.info("state already exists");
					return "state already exists";
				}
			} else {
				logger.info("state code can not be null ");
				return "state code can not be null";
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	@Transactional
	public String updateState(StateDTO stateDTO) {
		State state = null;
		Region region = null;
		try {
			if (stateDTO != null && stateDTO.getStateId() != null
					&& stateDTO.getStateId() > 0) {
				state = stateRepository.findStateByStateId(stateDTO
						.getStateId());
				if (state != null) {
					state.setStateCode(stateDTO.getStateCode());
					state.setStateName(stateDTO.getStateName());
					state.setActive(stateDTO.isActive());
					state.setModifiedBy(stateDTO.getModifiedBy());
					state.setModifiedDate(new Date());
					RegionDTO regionDTO = stateDTO.getRegion();
					if (regionDTO != null && regionDTO.getRegionId() != null
							&& regionDTO.getRegionId() > 0) {
						Integer regionId = stateDTO.getRegion().getRegionId();
						region = regionRepository
								.findRegionByRegionId(regionId);
						if (region != null) {
							state.setRegion(region);
						}
					}
					stateRepository.saveAndFlush(state);
					return IotConstants.SUCCESS;
				} else {
					logger.info("state doest not exists with id "
							+ stateDTO.getStateId());
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	@Transactional
	public String deleteState(Integer stateId) {
		try {
			if (stateId != null && stateId > 0) {
				State state = stateRepository.findStateByStateId(stateId);
				if (state != null) {
					state.setActive(IotConstants.FALSE);
					state.setModifiedDate(new Date());
					stateRepository.save(state);
					return IotConstants.SUCCESS;
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public StateDTO getStateByStateId(Integer stateId) {
		StateDTO stateDTO = null;
		try {
			if (stateId != null && stateId > 0) {
				State state = stateRepository.findStateByStateId(stateId);
				if (state != null) {
					stateDTO = dMapper.map(state, StateDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return stateDTO;
	}

}
