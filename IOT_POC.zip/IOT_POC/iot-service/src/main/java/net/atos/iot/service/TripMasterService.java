package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.TripMasterDTO;
import net.atos.iot.entity.TripMaster;

public interface TripMasterService {

	Long startTrip(TripMasterDTO tripMasteDTO);

	String endTrip(Long tripId);

	TripMasterDTO getTripByTripId(long tripId);

	List<TripMasterDTO> getAllTrips();

	List<TripMasterDTO> findAllTripsByTripStatus(String tripStatus);
	
	void deleteTripsByDevicesIds(List<String> deviceIds);

}
