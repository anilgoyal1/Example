package net.atos.iot.service.impl;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import net.atos.iot.dto.DeviceMasterDTO;
import net.atos.iot.dto.SiteSurveyDTO;
import net.atos.iot.dto.TicketDTO;
import net.atos.iot.entity.Ticket;
import net.atos.iot.repository.TicketRepository;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.DeviceStatusMasterService;
import net.atos.iot.service.PushNotificationService;
import net.atos.iot.service.RoleService;
import net.atos.iot.service.SensorDataService;
import net.atos.iot.service.SiteSurveyService;
import net.atos.iot.service.TicketService;
import net.atos.iot.service.UserDetailsService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * This is a service class used for branch operations.
 * 
 * @author a602834
 *
 */
@Service
public class TicketServiceImpl implements TicketService {

	private final static Logger logger = Logger.getLogger(TicketServiceImpl.class);

	@Autowired
	private TicketRepository ticketRepository;

	@Autowired
	private DeviceMasterService deviceMstImpl;

	@Autowired
	private DeviceStatusMasterService deviceStatusServiceImpl;

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private PushNotificationService pushNotificationServiceImpl;

	private Mapper dMapper = new DozerBeanMapper();

	@Autowired
	private EntityManagerFactory emf;

	@Autowired
	private SiteSurveyService siteSurveyServiceImpl;

	@Autowired
	private RoleService roleService;

	@Autowired
	private SensorDataService sensorDataService;

	@Value("${isTicketStatusChangedNotificationEnabled}")
	private boolean isTicketStatusChangedNotificationEnabled;

	@Override
	public String createTicket(TicketDTO ticketDTO) {
		Ticket ticket = null;
		try {
			if (ticketDTO != null && !StringUtils.isEmpty(ticketDTO.getDeviceId())
					&& !StringUtils.isEmpty(ticketDTO.getTicketStatus())) {
				List<Ticket> ticketList = ticketRepository.findTicketByStatusAndDeviceId(ticketDTO.getTicketStatus(),
						ticketDTO.getDeviceId());
				if (ticketList != null && ticketList.size() > 0) {
					return "Ticket already exist for Device Id ".concat(ticketDTO.getDeviceId()).concat(" with status ")
							.concat(ticketDTO.getTicketStatus());
				} else {
					ticket = dMapper.map(ticketDTO, Ticket.class);
					return saveTicket(ticket);

				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public List<TicketDTO> getTicketByDeviceAndStatus(String deviceId, String status) {
		List<TicketDTO> ticketListDto = null;
		try {
			List<Ticket> ticketList = ticketRepository.findTicketByStatusAndDeviceId(status, deviceId);
			ticketListDto = createTicketDTOFromTicketEntity(ticketList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (ticketListDto == null) {
			ticketListDto = new ArrayList<TicketDTO>();
		}
		return ticketListDto;
	}

	@Override
	public List<TicketDTO> getTicketByDeviceId(String deviceId) {
		List<TicketDTO> ticketListDto = null;
		try {
			List<Ticket> ticketList = ticketRepository.findByDeviceId(deviceId);
			ticketListDto = createTicketDTOFromTicketEntity(ticketList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (ticketListDto == null) {
			ticketListDto = new ArrayList<TicketDTO>();
		}
		return ticketListDto;
	}

	@Override
	public List<TicketDTO> getTicketByStatus(String status) {
		List<TicketDTO> ticketListDto = null;
		try {
			List<Ticket> ticketList = ticketRepository.findTicketByStatus(status);
			ticketListDto = createTicketDTOFromTicketEntity(ticketList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (ticketListDto == null) {
			ticketListDto = new ArrayList<TicketDTO>();
		}
		return ticketListDto;
	}

	@Autowired
	public List<TicketDTO> getAllTicket() {
		List<TicketDTO> ticketListDto = null;
		try {
			List<Ticket> ticketList = ticketRepository.findAll();
			ticketListDto = createTicketDTOFromTicketEntity(ticketList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (ticketListDto == null) {
			ticketListDto = new ArrayList<TicketDTO>();
		}
		return ticketListDto;
	}

	@Override
	public String updateTicket(TicketDTO ticketDTO, String userId) {
		try {
			if (ticketDTO != null && !StringUtils.isEmpty(ticketDTO.getDeviceId())
					&& !StringUtils.isEmpty(ticketDTO.getTicketStatus())
					&& !StringUtils.isEmpty(ticketDTO.getNewTicketStatus()) && ticketDTO.getTicketId() > 0L) {
				Ticket ticket = ticketRepository.findTicketByTicketId(ticketDTO.getTicketId());
				if (ticket == null) {
					return "Ticket not found for ticket id " + ticketDTO.getTicketId();
				} else if (ticket.getAlertType().equalsIgnoreCase(IotConstants.TICKET_ALERT_TYPE_CHANGE_REQUEST)) {
					return handleChagneRequest(ticket, ticketDTO, userId);
				} else {
					return handleIncidents(ticket, ticketDTO, userId);

				}
			} else {
				return "Please check devideId,TicketId,Ticket Status.";
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;

	}

	@Override
	public List<TicketDTO> getActiveTicketDTO() {
		List<TicketDTO> ticketListDto = null;
		try {
			List<Ticket> ticketList = ticketRepository.getActiveTickets("Close");
			ticketListDto = createTicketDTOFromTicketEntity(ticketList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (ticketListDto == null) {
			ticketListDto = new ArrayList<TicketDTO>();
		}
		return ticketListDto;
	}

	@Override
	public List<TicketDTO> getTicketByTenanatIdAndStatus(Integer tenantId, String status) {
		List<TicketDTO> ticketListDto = new ArrayList<TicketDTO>();
		try {
			if (tenantId != null && tenantId > 0) {
				List<DeviceMasterDTO> deviceMstList = deviceMstImpl.getAllDeviceByTenantId(tenantId);
				if (deviceMstList != null && deviceMstList.size() > 0) {
					List<String> deviceList = new ArrayList<String>();
					for (DeviceMasterDTO deviceMstDTO : deviceMstList) {
						deviceList.add(deviceMstDTO.getDeviceId());
					}

					List<Ticket> ticketList = ticketRepository.findTicketByStatusAndDeviceIds(status, deviceList);
					ticketListDto = createTicketDTOFromTicketEntity(ticketList);
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);

		}
		if (ticketListDto == null) {
			ticketListDto = new ArrayList<TicketDTO>();
		}
		return ticketListDto;
	}

	@Override
	public List<TicketDTO> getAllTicketTenantIdWise(Integer tenantId) {
		List<TicketDTO> ticketListDto = new ArrayList<TicketDTO>();
		try {
			if (tenantId != null && tenantId > 0) {
				List<String> deviceList = deviceMstImpl.getDeviceIdsByTenantId(tenantId);
				if (deviceList != null && deviceList.size() > 0) {
					List<Ticket> ticketList = ticketRepository.findTicketByTenantId(deviceList);
					ticketListDto = createTicketDTOFromTicketEntity(ticketList);
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		if (ticketListDto == null) {
			ticketListDto = new ArrayList<TicketDTO>();
		}
		return ticketListDto;
	}

	@Override
	public TicketDTO getTicketByTicketId(Long ticketId) {
		TicketDTO ticketDTO = null;
		try {
			if (ticketId != null && ticketId > 0) {
				Ticket ticket = ticketRepository.findTicketByTicketId(ticketId);
				if (ticket != null) {
					ticketDTO = dMapper.map(ticket, TicketDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return ticketDTO;

	}

	@Override
	public String getTicketCountForDashboard(Integer tenantId, String filterData) {
		JSONObject response = new JSONObject();
		StringBuilder sql = new StringBuilder();
		String whereCondition = null;
		String fromDateStr = null;
		String toDateStr = null;
		Date fromDate = null;
		Date toDate = null;
		DateFormat df = null;
		Integer newTicketCount = 0;
		Integer closedTicketCount = 0;
		Integer resolvedTicketCount = 0;
		Integer assignedTicketCount = 0;
		Integer esclatedTicketCount = 0;
		String ticketStatus = null;
		EntityManager entityManager = null;
		try {
			if (tenantId != null && tenantId > 0) {
				List<String> deviceIdList = deviceMstImpl.getDeviceIdsByTenantId(tenantId);

				if (deviceIdList != null && !deviceIdList.isEmpty()) {

					if (filterData != null && !filterData.isEmpty()) {
						JSONObject jsonFilter = new JSONObject(filterData);
						if (jsonFilter != null && jsonFilter.has(IotConstants.fromDate)
								&& jsonFilter.has(IotConstants.toDate)) {
							fromDateStr = jsonFilter.getString(IotConstants.fromDate);
							toDateStr = jsonFilter.getString(IotConstants.toDate);
							df = new SimpleDateFormat("yyyy-MM-dd");
							fromDate = DateUtil.convertDateAndTimeToBeginingOfDate(df.parse(fromDateStr));
							toDate = DateUtil.convertDateAndTimeToEndOfDate(df.parse(toDateStr));

							if (fromDate != null && toDate != null) {
								whereCondition = " And created_date between :fromDate And :toDate ";
							}

						}
					}

					sql.append(" select ticket_status from Ticket t  ");
					sql.append("where device_id in(:deviceList) ");
					if (whereCondition != null) {
						sql.append(whereCondition);
					}
					entityManager = emf.createEntityManager();
					Query query = entityManager.createNativeQuery(sql.toString());
					query.setParameter("deviceList", deviceIdList);
					if (whereCondition != null) {
						query.setParameter("fromDate", fromDate);
						query.setParameter("toDate", toDate);
					}
					List<String> ticketList = query.getResultList();
					if (ticketList != null && !ticketList.isEmpty()) {
						for (String ticket : ticketList) {
							ticketStatus = ticket;
							if (ticketStatus != null) {
								if (ticketStatus.equalsIgnoreCase(IotConstants.ticketTypeNew)) {
									newTicketCount++;
								} else if (ticketStatus.equalsIgnoreCase(IotConstants.ticketTypeResolved)) {
									resolvedTicketCount++;
								} else if (ticketStatus.equalsIgnoreCase(IotConstants.ticketTypeAssigned)) {
									assignedTicketCount++;
								} else if (ticketStatus.equalsIgnoreCase(IotConstants.ticketTypeClose)) {
									closedTicketCount++;

								} else if (ticketStatus.equalsIgnoreCase(IotConstants.ticketTypeEscalated)) {
									esclatedTicketCount++;
								}
							}

						}
					}

					response.put(IotConstants.ticketTypeNew, newTicketCount);
					response.put(IotConstants.ticketTypeResolved, resolvedTicketCount);
					response.put(IotConstants.ticketTypeAssigned, assignedTicketCount);
					response.put(IotConstants.ticketTypeEscalated, esclatedTicketCount);
					response.put(IotConstants.ticketTypeClose, closedTicketCount);

				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);

		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return response.toString();
	}

	@Override
	public List<Ticket> getOpenTicketByDeviceIdAndTicketType(String deviceId, String ticketType) {
		List<Ticket> tickets = null;
		try {
			if (deviceId != null && !deviceId.isEmpty() && ticketType != null && !ticketType.isEmpty()) {
				tickets = ticketRepository.getOpenTicketByDeviceIdAndTicketType(deviceId, ticketType,
						IotConstants.ticketTypeClose);

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return tickets;
	}

	private List<TicketDTO> createTicketDTOFromTicketEntity(List<Ticket> ticketList) {
		List<TicketDTO> ticketListDto = null;
		try {
			if (ticketList != null && !ticketList.isEmpty()) {
				ticketListDto = new ArrayList<TicketDTO>();
				TicketDTO tcDto = null;
				for (Ticket ticket : ticketList) {
					tcDto = new TicketDTO();
					tcDto = dMapper.map(ticket, TicketDTO.class);
					ticketListDto.add(tcDto);
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (ticketListDto == null) {
			ticketListDto = new ArrayList<TicketDTO>();
		}
		return ticketListDto;
	}

	@Override
	public String saveTicket(Ticket ticket) {
		String response = IotConstants.FAILURE;
		try {
			if (ticket != null) {
				ticket.setCreateDate(new Timestamp(new Date().getTime()));
				ticket = ticketRepository.saveAndFlush(ticket);
				this.sendTicketStatusChangedNotificationByDeviceId(ticket.getDeviceId(),
						" Ticket No " + ticket.getTicketId() + " Status Changed to  " + ticket.getTicketStatus());
				response = IotConstants.SUCCESS;
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return response;
	}

	@Override
	public List<Ticket> getActiveTicketEntity() {
		List<Ticket> ticketList = null;
		String[] closeTicketStatus = { IotConstants.ticketTypeClose, IotConstants.ticketTypeResolved, };
		List<String> resolvedOrClosedTicketStatus = Arrays.asList(closeTicketStatus);
		try {
			ticketList = ticketRepository.getTicketSWhereStatusNotIn(resolvedOrClosedTicketStatus);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return ticketList;
	}

	private String handleChagneRequest(Ticket ticket, TicketDTO ticketDTO, String userId) {
		if (ticket != null) {
			SiteSurveyDTO siteSurvey = siteSurveyServiceImpl.getSiteSurveyByDeviceId(ticket.getDeviceId());
			if (siteSurvey.getStatus() != null
					&& siteSurvey.getStatus().equalsIgnoreCase(IotConstants.ticketTypeAssigned)) {
				return "Site survey already exists for device ".concat(ticket.getDeviceId())
						.concat(" .Please complete sitesurvey first");
			} else {

				if (StringUtils.isEmpty(ticketDTO.getRootCause())) {
					return "root cause is compulsory";

				}

				if (ticketDTO.getNewTicketStatus().equalsIgnoreCase(IotConstants.ticketTypeResolved)) {
					ticket.setResolveBy(userId);
					ticket.setResolveDate(new Date());
					ticket.setAssignedTo(roleService.getUserIdByTenantIdAndRoleName(
							deviceMstImpl.getTenantIdByDeviceId(ticket.getDeviceId()), IotConstants.SERVICE_MANAGER));

				} else if (ticketDTO.getNewTicketStatus().equalsIgnoreCase(IotConstants.ticketTypeClose)) {
					ticket.setCloseDate(new Date());
					ticket.setClosedBy(userId);

				} else if (ticketDTO.getNewTicketStatus().equalsIgnoreCase(IotConstants.ticketTypeAssigned)) {
					return "Site survey status is already assinged";
				}

				if (siteSurvey.getStatus().equalsIgnoreCase(IotConstants.SITE_SURVEY_OK)) {
					deviceMstImpl.changeDeviceStatus(ticket.getDeviceId(), IotConstants.PROVISIONED_DEVICE_STATUS);
				} else {
					deviceMstImpl.changeDeviceStatus(ticket.getDeviceId(), IotConstants.RejectedDeviceStatus);
				}
				ticket.setTicketStatus(ticketDTO.getNewTicketStatus());
				ticket.setModifiedBy(userId);
				ticket.setRootCause(ticketDTO.getRootCause());
				ticket.setModifiedDate(new Date());

				this.saveTicket(ticket);
				return IotConstants.SUCCESS;
			}
		}
		return IotConstants.FAILURE;
	}

	private String handleIncidents(Ticket ticket, TicketDTO ticketDTO, String userId) {
		try {
			if (StringUtils.isEmpty(ticketDTO.getRootCause())) {
				return "root cause is compulsory";

			}
			if (ticketDTO.getNewTicketStatus().equalsIgnoreCase(IotConstants.ticketTypeAssigned)) {
				return "Ticket Status is already assinged";
			} else if (ticketDTO.getNewTicketStatus().equalsIgnoreCase(IotConstants.ticketTypeResolved)) {
				ticket.setResolveBy(userId);
				ticket.setResolveDate(new Date());
				ticket.setAssignedTo(roleService.getUserIdByTenantIdAndRoleName(
						deviceMstImpl.getTenantIdByDeviceId(ticket.getDeviceId()), IotConstants.SERVICE_MANAGER));
				List<String> ticketStatus = new ArrayList<String>();
				ticketStatus.add(IotConstants.ticketTypeResolved);
				ticketStatus.add(IotConstants.ticketTypeClose);
				List<Ticket> pendingTicketList = ticketRepository.getTicketsByNotInStatusAndDeviceIdAndTicketId(
						ticketStatus, ticket.getDeviceId(), ticket.getTicketId());
				if (pendingTicketList == null || pendingTicketList.isEmpty()) {

					deviceMstImpl.changeDeviceStatus(ticket.getDeviceId(), IotConstants.liveDeviceStatus);
				}
			} else if (ticketDTO.getNewTicketStatus().equalsIgnoreCase(IotConstants.ticketTypeClose)) {
				ticket.setCloseDate(new Date());
				ticket.setClosedBy(userId);
			}
			ticket.setTicketStatus(ticketDTO.getNewTicketStatus());
			ticket.setModifiedBy(userId);
			ticket.setRootCause(ticketDTO.getRootCause());
			ticket.setModifiedDate(new Date());
			if (!StringUtils.isEmpty(ticketDTO.getTicketDescription())) {
				ticket.setTicketDescription(ticketDTO.getTicketDescription());
			}
			ticket.setTicketStatus(ticketDTO.getNewTicketStatus());
			this.saveTicket(ticket);
			return IotConstants.SUCCESS;
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}

	@Override
	public void deleteAllTicketsByDeviceIds(List<String> deviceIds) {
		if (deviceIds != null && !deviceIds.isEmpty()) {
			ticketRepository.deleteTicketsByDeviceIds(deviceIds);
		}

	}

	@Override
	public void sendTicketStatusChangedNotification(Integer tenantId, String message) {
		if (tenantId != null && tenantId > 0 && message != null && !message.isEmpty())
			if (isTicketStatusChangedNotificationEnabled) {
				pushNotificationServiceImpl.sendNotificationByTenantId(tenantId, message);
			}

	}

	@Override
	public void sendTicketStatusChangedNotificationByDeviceId(String deviceId, String message) {
		if (deviceId != null && !deviceId.isEmpty() && message != null && !message.isEmpty())
			if (isTicketStatusChangedNotificationEnabled) {
				pushNotificationServiceImpl.sendNotficationByDeviceId(deviceId, message);
			}

	}

	@Override
	public String createTicketForAishwarya(TicketDTO ticketDTO) {
		Ticket ticket = null;
		try {
			if (ticketDTO != null && !StringUtils.isEmpty(ticketDTO.getDeviceId())
					&& !StringUtils.isEmpty(ticketDTO.getTicketStatus())) {
				ticket = dMapper.map(ticketDTO, Ticket.class);
				ticket.setCreateDate(new Date());
				ticket.setAssignedDate(new Date());
				
				return saveTicket(ticket);

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return IotConstants.FAILURE;
	}
}