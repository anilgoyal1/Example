package net.atos.iot.service.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import net.atos.iot.service.DockerContainerService;
import net.atos.iot.util.IotConstants;
import net.atos.iot.util.PerformFunction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class DockerContainerServiceImpl implements DockerContainerService {

	@Autowired
	PerformFunction performFunction;

	@Value("${containerAPIUrlEndPoint}")
	private String containerAPIUrlEndPoint;

	@Value("${containerApiImageName}")
	private String containerApiImageName;

	@Value("${createContainerPayload}")
	private String createContainerPayload;

	@Value("${isHttpProxyRequired}")
	private boolean isHttpProxyRequired;

	@Value("${httpProxyHost}")
	private String httpProxyHost;

	@Value("${httpProxyPort}")
	private String httpProxyPort;

	static final String CONTENT_TYPE = "Content-Type";

	static final String APPLICATION_JSON = "application/json";

	static final String ACCEPT = "Accept";

	static final String POST = "POST";

	static final String GET = "GET";

	static final String DELETE = "DELETE";

	private static final Logger logger = Logger
			.getLogger(DockerContainerServiceImpl.class);

	@Override
	public void createContainer(String containerName) throws IOException {
		if (containerName != null && !containerName.isEmpty()) {
			System.out.println("Execute method asynchronously - "
					+ Thread.currentThread().getName());
			String containerPayload = createContainerPayload;
			containerPayload = containerPayload
					.replace("#HostName#", containerName)
					.replace("#deviceId#", containerName)
					.replace("#ImageName#", containerApiImageName);
			String apiEndPoint = containerAPIUrlEndPoint
					.concat("/create?name=").concat(containerName);
			System.out.println("api end point " + apiEndPoint);
			System.out.println("container payload " + containerPayload);
			int response = this.performFunction(apiEndPoint, IotConstants.POST,
					containerPayload);
			logger.info("response after calling createContainer docker  api "
					+ response);
		}
	}

	@Override
	@Async
	public void startDockerContainer(String containerName) throws IOException {
		if (containerName != null && !containerName.isEmpty()) {
			System.out.println("Execute method asynchronously - "
					+ Thread.currentThread().getName());
			String startAPIEndpoint = containerAPIUrlEndPoint.concat(
					"/{id}/start").replace("{id}", containerName);
			int response = this.performFunction(startAPIEndpoint,
					IotConstants.POST, "");
			logger.info("response after startDockerContainer api " + response);

		}

	}

	@Override
	@Async
	public void stopDockerContainer(String containerName) throws IOException {
		if (containerName != null && !containerName.isEmpty()) {
			int response = this.performFunction(
					containerAPIUrlEndPoint.concat("/{id}/stop").replace(
							"{id}", containerName), IotConstants.POST, null);
			logger.info("response after calling stopDockerContainer api "
					+ response);

		}

	}

	@Override
	@Async
	public void deleteDockerContainer(String containerName) throws IOException {
		if (containerName != null && !containerName.isEmpty()) {
			int response = this.performFunction(
					containerAPIUrlEndPoint.concat("/{id}").replace("{id}",
							containerName), IotConstants.DELETE, null);
			logger.info("response after deleteDockerContainer api " + response);
		}
	}

	// after testing update it
	@Override
	@Async
	public void checkStatusOfDockerContainer(String containerName)
			throws Exception {
		if (containerName != null && !containerName.isEmpty()) {
			int response = this.performFunction(
					containerAPIUrlEndPoint.concat("/{id}/json").replace(
							"{id}", null), IotConstants.GET, null);
		}
	}

	@Async
	public int performFunction(String uri, String method, String inputJSONStr)
			throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		int response = 0;
		StringBuilder responsePost = new StringBuilder();
		if (isHttpProxyRequired) {
			System.getProperties().put("http.proxyHost", httpProxyHost);
			System.getProperties().put("http.proxyPort", httpProxyPort);
		}
		HttpURLConnection conn = null;
		try {
			URL url = new URL(uri);
			conn = (HttpURLConnection) url.openConnection();
			if (POST.equalsIgnoreCase(method)) {
				conn.setDoOutput(true);
				conn.setRequestMethod(POST);
				conn.setRequestProperty(CONTENT_TYPE, APPLICATION_JSON);
				OutputStream os = conn.getOutputStream();
				{
					if (inputJSONStr != null && !inputJSONStr.isEmpty())
						os.write(inputJSONStr.getBytes());
					os.flush();
				}
				if (conn != null) {
					response = conn.getResponseCode();
				}
				conn.disconnect();
			} else if (DELETE.equalsIgnoreCase(method)) {
				HttpURLConnection httpURLConnection = null;
				httpURLConnection = (HttpURLConnection) url.openConnection();
				httpURLConnection.setRequestProperty(CONTENT_TYPE,
						"application/x-www-form-urlencoded");
				httpURLConnection.setRequestMethod(DELETE);
				if (conn != null) {
					response = conn.getResponseCode();
				}
			} else if (GET.equalsIgnoreCase(method)) {
				conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod(GET);
				conn.setRequestProperty(CONTENT_TYPE, "application/json");
				if (conn != null) {
					response = conn.getResponseCode();
				}

				conn.disconnect();
			}

		} catch (Exception e) {
			// logger.error(IotConstants.Exception, e);
		} finally {

			System.getProperties().remove("http.proxyHost");
			System.getProperties().remove("http.proxyPort");

			if (conn != null) {
				conn.disconnect();
			}
		}
		logger.info(response);
		return response;

	}

}
