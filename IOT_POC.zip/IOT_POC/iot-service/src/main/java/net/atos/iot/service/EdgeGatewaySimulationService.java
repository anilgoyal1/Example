package net.atos.iot.service;

import java.util.List;

import net.atos.iot.dto.EdgeGatewaySimulationDTO;

public interface EdgeGatewaySimulationService {

	String createSimulationDevicesMasterData(
			EdgeGatewaySimulationDTO edgeGatewaySimulationDTO,
			int addNumberOfDevices);

	String removeSimulationDevicesMasterData(String simulationId);

	List<EdgeGatewaySimulationDTO> getAllEdgeGatewaySimulationDTO();

	boolean checkRunningSimulationForTenant(Integer tenantId);

	String startSwarmContainerBySimulationName(String simulationName);

	String stopSwarmContainerBySimulationName(String simulationName);

	EdgeGatewaySimulationDTO getEdgeGateWaySimulationBySimulationName(
			String simulationName);

	String getSwarmContainerSimulationStatusByName(String simulationName);

	List<EdgeGatewaySimulationDTO> getEdgeGateWaySimulationByTenantId(
			Integer tenantId);

	String createtDockerContainer(String simulationName);

	String getDockerContainerSimulationStatus(String simulationName);

	String stopDockerContainerByContainerName(String deviceId);

	String startDockerContainerByCotainerName(String simulationName);

	String deleteDockerContainerBySimulationName(String simulationName);

	String createDockerContainerByDeviceId(String deviceId);

	String startDockerContainerByByDeviceId(String deviceId);

	String stopDockerContainerByByDeviceId(String deviceId);

	String deleteDockerContainerByByDeviceId(String deviceId);

	String getDockerContainerStatusByDeviceId(String deviceId);

}
