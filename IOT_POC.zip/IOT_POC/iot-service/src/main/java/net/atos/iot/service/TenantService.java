package net.atos.iot.service;

import java.util.List;
import java.util.Map;

import net.atos.iot.dto.TenantDTO;
import net.atos.iot.entity.Tenant;

public interface TenantService {

	public List<TenantDTO> getAllTenants(boolean Active);

	public TenantDTO getTenantDTOById(Integer tenantId);

	public String createTenant(TenantDTO tenantDTO);

	public String deleteTenant(Integer tenantId);

	TenantDTO assignCountriesToTenant(Map<String, Object> hashMap);

	String updateTenant(TenantDTO tenantDto);

	public Tenant getTenantByTenantId(Integer tenantId);

	public Integer getTenantIdByDeviceId(String deviceId);

}
