package net.atos.iot.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import net.atos.iot.dto.AlertDataDTO;
import net.atos.iot.entity.AlertData;
import net.atos.iot.repository.AlertDataRepository;
import net.atos.iot.service.AlertDataService;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.PushNotificationService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AlertDataServiceImpl implements AlertDataService {

	private static final Logger logger = Logger
			.getLogger(AlertDataServiceImpl.class);

	@Autowired
	private AlertDataRepository alertDataRepository;

	private Mapper mapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Autowired
	private DeviceMasterService deviceMstImpl;

	@Autowired
	private EntityManagerFactory emf;

	@Value("${isAlertNotificationEnabled}")
	private boolean isAlertNotificationEnabled;

	@Autowired
	PushNotificationService pushNotificationUtil;

	@Override
	public List<AlertDataDTO> getAllAlertData() {
		List<AlertData> alertDataList = null;
		List<AlertDataDTO> alertDataDTOList = null;
		try {
			alertDataList = alertDataRepository.findAll();
			alertDataDTOList = creteAlertDataDTOFromAlertDataEntity(alertDataList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (alertDataDTOList == null) {
			alertDataDTOList = new ArrayList<AlertDataDTO>();
		}
		return alertDataDTOList;
	}

	@Override
	public List<AlertDataDTO> getAlertDataByLevel(String level) {
		List<AlertData> alertDataList = null;
		List<AlertDataDTO> alertDataDTOList = null;
		try {
			alertDataList = alertDataRepository.findAlertDataByLevel(level);
			alertDataDTOList = creteAlertDataDTOFromAlertDataEntity(alertDataList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return alertDataDTOList;
	}

	@Override
	public List<AlertDataDTO> getAlertDataByCreatedDateAndDeviceId(
			String deviceId, Date fromDate, Date toDate) {
		List<AlertData> alertDataList = null;
		List<AlertDataDTO> alertDataDTOList = null;
		try {
			alertDataList = alertDataRepository
					.findAlertDataByDeviceIdAndCreatedDate(deviceId, fromDate,
							toDate);
			alertDataDTOList = creteAlertDataDTOFromAlertDataEntity(alertDataList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (alertDataDTOList == null) {
			alertDataDTOList = new ArrayList<AlertDataDTO>();
		}
		return alertDataDTOList;
	}

	@Override
	public List<AlertDataDTO> getAlertDataByDeviceIdAndExceptAlertType(
			String deviceId, Date fromDate, Date toDate, String alertType) {
		List<AlertData> alertDataList = null;
		List<AlertDataDTO> alertDataDTOList = null;
		try {
			alertDataList = alertDataRepository
					.getAlertDataByDeviceIdAndExceptAlertType(deviceId,
							fromDate, toDate, alertType);
			alertDataDTOList = creteAlertDataDTOFromAlertDataEntity(alertDataList);
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return alertDataDTOList;
	}

	@Override
	public List<AlertDataDTO> getAllDataByLevelAndTenantId(String level,
			Integer tenantId) {
		List<AlertData> alertDataList = null;
		List<AlertDataDTO> alertDataDTOList = null;
		try {
			if (tenantId > 0) {
				List<String> deviceList = deviceMstImpl
						.getDeviceIdsByTenantId(tenantId);
				if (deviceList != null && deviceList.size() > 0) {
					alertDataList = alertDataRepository
							.getDeviceByLevelAndDeviceIds(level, deviceList);
					alertDataDTOList = creteAlertDataDTOFromAlertDataEntity(alertDataList);
				}
			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return alertDataDTOList;
	}

	@Override
	public List<AlertDataDTO> getAllAlertDataByTenantId(Integer tenantId) {
		List<AlertData> alertDataList = null;
		List<AlertDataDTO> alertDataDTOList = null;
		try {
			if (tenantId > 0) {
				List<String> deviceList = deviceMstImpl
						.getDeviceIdsByTenantId(tenantId);
				if (deviceList != null && deviceList.size() > 0) {
					alertDataList = alertDataRepository
							.findAlertDataByDeviceIds(deviceList);
					alertDataDTOList = creteAlertDataDTOFromAlertDataEntity(alertDataList);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return alertDataDTOList;
	}

	@Override
	public JSONObject getAlertDataCountAlertTypeAndDateWise(String filterData) {
		JSONObject responseJson = null;
		Date fromDate = null;
		Date toDate = null;
		if (filterData != null && filterData.contains(IotConstants.fromDate)
				&& filterData.contains(IotConstants.toDate)) {
			fromDate = DateUtil.getDateFromJSONString(filterData,
					IotConstants.fromDate);
			toDate = DateUtil.getDateFromJSONString(filterData,
					IotConstants.toDate);
			if (fromDate == null) {
				fromDate = DateUtil
						.convertDateAndTimeToBeginingOfDate(new Date());
			}
			if (toDate == null) {
				toDate = DateUtil.convertDateAndTimeToEndOfDate(new Date());
			}
			responseJson = this.getAlertDataCountAlerTypeAndDateWise(fromDate,
					toDate);
		}

		return responseJson;
	}

	private JSONObject getAlertDataCountAlerTypeAndDateWise(Date fromDate,
			Date toDate) {
		List<Object[]> alertDataList = null;
		JSONArray responseArray = new JSONArray();
		Integer sensorViolationCount = 0;
		Integer temperatureViolationCount = 0;
		Integer humidityViolationCount = 0;
		Integer temperingAlertCount = 0;
		Integer edgeGatewayNotRechableCount = 0;
		Integer sensorNotRechableCount = 0;
		Integer otherAlert = 0;
		String currentAlert = null;
		String currentDate = null;
		String previousDate = null;
		JSONObject alertCountJson = null;
		JSONObject dateJson = new JSONObject();
		int cnt = 0;
		try {
			alertDataList = getAlertDataList(fromDate, toDate);
			if (alertDataList != null && !alertDataList.isEmpty()) {
				int alertListSize = alertDataList.size();
				for (Object[] obj : alertDataList) {
					if (obj[0] != null && obj[1] != null) {
						currentDate = obj[0].toString();
						currentAlert = obj[1].toString();
						if (cnt == 0) {
							previousDate = currentDate;
						}
						if (previousDate.equalsIgnoreCase(currentDate)) {
							if (currentAlert
									.equalsIgnoreCase(IotConstants.TEMPERATURE_VIOLATION)) {
								temperatureViolationCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.HUMIDITY_VIOLATION)) {
								humidityViolationCount++;
							}

							else if (currentAlert
									.equalsIgnoreCase(IotConstants.TAMPERING_ALERT)) {
								temperingAlertCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.SENSOR_NOT_REACHABLE)) {
								sensorNotRechableCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.EDGE_GATEWAY_NOT_REACHABLE)) {
								edgeGatewayNotRechableCount++;
							} else {
								otherAlert++;
							}

						} else {
							alertCountJson = new JSONObject();

							alertCountJson.put(
									IotConstants.TEMPERATURE_VIOLATION,
									temperatureViolationCount);
							alertCountJson.put(IotConstants.HUMIDITY_VIOLATION,
									humidityViolationCount);

							alertCountJson.put(IotConstants.TAMPERING_ALERT,
									temperingAlertCount);

							alertCountJson.put(
									IotConstants.SENSOR_NOT_REACHABLE,
									sensorNotRechableCount);

							alertCountJson.put(
									IotConstants.EDGE_GATEWAY_NOT_REACHABLE,
									edgeGatewayNotRechableCount);

							alertCountJson.put("OtherAlert", otherAlert);

							dateJson.put(previousDate, alertCountJson);
							responseArray.put(dateJson);
							sensorViolationCount = 0;
							temperatureViolationCount = 0;
							humidityViolationCount = 0;
							temperingAlertCount = 0;
							edgeGatewayNotRechableCount = 0;
							sensorNotRechableCount = 0;
							otherAlert = 0;
							if (currentAlert
									.equalsIgnoreCase(IotConstants.TEMPERATURE_VIOLATION)) {
								temperatureViolationCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.HUMIDITY_VIOLATION)) {
								humidityViolationCount++;
							}

							else if (currentAlert
									.equalsIgnoreCase(IotConstants.TAMPERING_ALERT)) {
								temperingAlertCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.SENSOR_NOT_REACHABLE)) {
								sensorNotRechableCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.EDGE_GATEWAY_NOT_REACHABLE)) {
								edgeGatewayNotRechableCount++;
							} else {
								otherAlert++;
							}
						}

						if (alertListSize - 1 == cnt) {
							alertCountJson = new JSONObject();

							alertCountJson.put(
									IotConstants.TEMPERATURE_VIOLATION,
									temperatureViolationCount);
							alertCountJson.put(IotConstants.HUMIDITY_VIOLATION,
									humidityViolationCount);

							alertCountJson.put(IotConstants.TAMPERING_ALERT,
									temperingAlertCount);

							alertCountJson.put(IotConstants.TAMPERING_ALERT,
									temperingAlertCount);

							alertCountJson.put(
									IotConstants.SENSOR_NOT_REACHABLE,
									sensorNotRechableCount);

							alertCountJson.put(
									IotConstants.EDGE_GATEWAY_NOT_REACHABLE,
									edgeGatewayNotRechableCount);

							alertCountJson.put("OtherAlert", otherAlert);
							responseArray.put(dateJson);
						}
						previousDate = currentDate;
						cnt++;

					}
				}

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return dateJson;
	}

	List<Object[]> getAlertDataList(Date fromDate, Date toDate) {
		List<Object[]> alertDataList = null;
		EntityManager entityManager = null;
		try {

			StringBuilder sql = new StringBuilder();
			sql.append(" select date(created_date),alert_type from alert_data t ");
			sql.append(" where date(created_date) ");
			if (fromDate != null && toDate != null) {
				sql.append(" between :fromDate And :toDate ");
			}
			sql.append("order by date(created_date),alert_type");
			entityManager = emf.createEntityManager();
			Query query = entityManager.createNativeQuery(sql.toString());
			if (fromDate != null && toDate != null) {
				query.setParameter("fromDate", fromDate);
				query.setParameter("toDate", toDate);
			}
			alertDataList = query.getResultList();
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
		return alertDataList;
	}

	@Override
	public List<String> getAllDistinctAlertType() {
		List<String> alertType = null;
		try {
			alertType = alertDataRepository.getDistinctAlertType();
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (alertType == null) {
			alertType = new ArrayList<String>();
		}

		return alertType;

	}

	@Override
	public JSONObject getAlertDataForDashBoard(Integer tenantId,
			String filterData) {
		JSONObject responseJson = null;
		Date fromDate = null;
		Date toDate = null;
		if (filterData != null && filterData.contains(IotConstants.fromDate)
				&& filterData.contains(IotConstants.toDate)) {
			fromDate = DateUtil.getDateFromJSONString(filterData,
					IotConstants.fromDate);
			toDate = DateUtil.getDateFromJSONString(filterData,
					IotConstants.toDate);
			if (fromDate == null) {
				fromDate = DateUtil
						.convertDateAndTimeToBeginingOfDate(new Date());
			}
			if (toDate == null) {
				toDate = DateUtil.convertDateAndTimeToEndOfDate(new Date());
			}
		}

		responseJson = this.getAlertDataCountByAlertType(tenantId, fromDate,
				toDate);

		return responseJson;
	}

	List<Object[]> getAlertDataListNew(Integer tenantId, Date fromDate,
			Date toDate) {
		List<Object[]> alertDataList = null;
		EntityManager entityManager = null;
		try {
			if (tenantId != null) {
				List<String> deviceList = deviceMstImpl
						.getDeviceIdsByTenantId(tenantId);

				if (deviceList != null && !deviceList.isEmpty()) {
					StringBuilder sql = new StringBuilder();
					sql.append(" select created_date ,alert_type from alert_data  ");
					sql.append(" where device_id in(:deviceList) ");

					if (fromDate != null && toDate != null) {
						sql.append(" And created_date between :fromDate And :toDate ");
					}

					sql.append(" order by alert_type ");
					entityManager = emf.createEntityManager();
					Query query = entityManager.createNativeQuery(sql
							.toString());
					query.setParameter("deviceList", deviceList);
					if (fromDate != null && toDate != null) {
						query.setParameter("fromDate", fromDate);
						query.setParameter("toDate", toDate);
					}
					alertDataList = query.getResultList();
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return alertDataList;

	}

	private JSONObject getAlertDataCountByAlertType(Integer tenantId,
			Date fromDate, Date toDate) {
		JSONObject jsonResponse = new JSONObject();
		List<Object[]> alertDataList = null;
		Integer sensorViolationCount = 0;
		Integer temperatureViolationCount = 0;
		Integer humidityViolationCount = 0;
		Integer temperingAlertCount = 0;
		Integer edgeGatewayNotRechableCount = 0;
		Integer sensorNotRechableCount = 0;
		Integer otherAlert = 0;
		Integer speedviolation = 0;
		String currentAlert = null;
		int totalCount = 0;
		double sensorViolationPercentage = 0.0;
		double tempViolationPercentage = 0.0;
		double humidityViolationPercentage = 0.0;
		double temperingAlertViolationPercentage = 0.0;
		double sensorNotRechablePercentages = 0;
		double edgeGatewayViolationpercentage = 0.0;
		double speedViolationpercentage = 0.0;
		double otherAlertPercentage = 0.0;
		JSONObject countAndPercentageJSON = null;
		try {
			alertDataList = getAlertDataListNew(tenantId, fromDate, toDate);
			if (alertDataList != null && !alertDataList.isEmpty()) {
				for (Object[] alert : alertDataList) {
					currentAlert = alert[1].toString();
					if (currentAlert != null) {
						if (currentAlert
								.equalsIgnoreCase(IotConstants.TEMPERATURE_VIOLATION)) {
							temperatureViolationCount++;
						} else if (currentAlert
								.equalsIgnoreCase(IotConstants.HUMIDITY_VIOLATION)) {
							humidityViolationCount++;
						}

						else if (currentAlert
								.equalsIgnoreCase(IotConstants.TAMPERING_ALERT)) {
							temperingAlertCount++;
						} else if (currentAlert
								.equalsIgnoreCase(IotConstants.SENSOR_NOT_REACHABLE)) {
							sensorNotRechableCount++;
						} else if (currentAlert
								.equalsIgnoreCase(IotConstants.EDGE_GATEWAY_NOT_REACHABLE)) {
							edgeGatewayNotRechableCount++;
						} else if (currentAlert
								.equalsIgnoreCase(IotConstants.SPEED_VIOLATION)) {
							speedviolation++;
						} else {
							otherAlert++;
						}

						totalCount++;
					}

				}
				if (totalCount > 0) {
					tempViolationPercentage = (((double) temperatureViolationCount / totalCount) * 100);
					humidityViolationPercentage = (((double) humidityViolationCount / totalCount) * 100);
					temperingAlertViolationPercentage = (((double) temperingAlertCount / totalCount) * 100);
					sensorNotRechablePercentages = (((double) sensorNotRechableCount / totalCount) * 100);
					edgeGatewayViolationpercentage = (((double) edgeGatewayNotRechableCount / totalCount) * 100);
					speedViolationpercentage = (((double) speedviolation / totalCount) * 100);
					otherAlertPercentage = (((double) otherAlert / totalCount) * 100);

				}

				countAndPercentageJSON = new JSONObject();
				countAndPercentageJSON.put("Count", temperatureViolationCount);
				countAndPercentageJSON.put("Percentage",
						tempViolationPercentage);
				jsonResponse.put(IotConstants.TEMPERATURE_VIOLATION,
						countAndPercentageJSON);

				countAndPercentageJSON = new JSONObject();
				countAndPercentageJSON.put("Count", humidityViolationCount);
				countAndPercentageJSON.put("Percentage",
						humidityViolationPercentage);
				jsonResponse.put(IotConstants.HUMIDITY_VIOLATION,
						countAndPercentageJSON);

				countAndPercentageJSON = new JSONObject();
				countAndPercentageJSON.put("Count", temperingAlertCount);
				countAndPercentageJSON.put("Percentage",
						temperingAlertViolationPercentage);
				jsonResponse.put(IotConstants.TAMPERING_ALERT,
						countAndPercentageJSON);

				countAndPercentageJSON = new JSONObject();
				countAndPercentageJSON.put("Count", sensorNotRechableCount);
				countAndPercentageJSON.put("Percentage",
						sensorNotRechablePercentages);
				jsonResponse.put(IotConstants.SENSOR_NOT_REACHABLE,
						countAndPercentageJSON);

				countAndPercentageJSON = new JSONObject();
				countAndPercentageJSON
						.put("Count", edgeGatewayNotRechableCount);
				countAndPercentageJSON.put("Percentage",
						edgeGatewayViolationpercentage);
				jsonResponse.put(IotConstants.EDGE_GATEWAY_NOT_REACHABLE,
						countAndPercentageJSON);

				countAndPercentageJSON = new JSONObject();
				countAndPercentageJSON.put("Count", speedviolation);
				countAndPercentageJSON.put("Percentage",
						speedViolationpercentage);
				jsonResponse.put(IotConstants.SPEED_VIOLATION,
						countAndPercentageJSON);

				countAndPercentageJSON = new JSONObject();
				countAndPercentageJSON.put("Count", otherAlert);
				countAndPercentageJSON.put("Percentage", otherAlertPercentage);
				jsonResponse.put("otherAlert", countAndPercentageJSON);

			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return jsonResponse;

	}

	@Override
	public String getAlertData(String deviceId, String filterData) {
		String response = null;
		if (deviceId != null && !deviceId.isEmpty()) {
			String alertType = null;
			Date fromDate = null;
			Date toDate = null;
			if (filterData != null) {
				JSONObject inputJson = new JSONObject(filterData);
				if (inputJson != null) {
					fromDate = DateUtil.getDateFromJSONString(filterData,
							IotConstants.fromDate);
					toDate = DateUtil.getDateFromJSONString(filterData,
							IotConstants.toDate);
					if (fromDate == null) {
						fromDate = DateUtil
								.convertDateAndTimeToBeginingOfDate(new Date());
					}
					if (toDate == null) {
						toDate = DateUtil
								.convertDateAndTimeToEndOfDate(new Date());
					}
					if (inputJson.has("alertType")) {
						alertType = inputJson.getString("alertType");
					}

				}
			}

			response = this
					.getAlertDataCountByDeviceIdAndAlertTypeAndDateWiseUISpecfic(
							deviceId, fromDate, toDate, alertType);
		} else {
			JSONObject json = new JSONObject();
			return json.put("Error", "Device Id can not be blank or null")
					.toString();
		}

		// TODO Auto-generated method stub
		return response.toString();
	}

	private String getAlertDataCountByDeviceIdAndAlertTypeAndDateWise(
			String deviceId, Date fromDate, Date toDate, String alertType) {
		List<Object[]> alertDataList = null;
		Integer sensorViolationCount = 0;
		Integer temperatureViolationCount = 0;
		Integer humidityViolationCount = 0;
		Integer temperingAlertCount = 0;
		Integer edgeGatewayNotRechableCount = 0;
		Integer sensorNotRechableCount = 0;
		Integer otherAlert = 0;
		String currentAlert = null;
		String currentDate = null;
		String previousDate = null;
		JSONObject alertCountJson = null;
		JSONObject dateJson = new JSONObject();
		JSONArray responseArray = new JSONArray();
		int cnt = 0;
		try {
			alertDataList = getAlertDataListByDeviceIdAndAlertTypeDateWise(
					deviceId, fromDate, toDate, alertType);
			if (alertDataList != null && !alertDataList.isEmpty()) {
				int alertListSize = alertDataList.size();
				for (Object[] obj : alertDataList) {
					if (obj[0] != null && obj[1] != null) {
						currentDate = obj[0].toString();
						currentAlert = obj[1].toString();
						if (cnt == 0) {
							previousDate = currentDate;
						}
						if (previousDate.equalsIgnoreCase(currentDate)) {
							if (currentAlert
									.equalsIgnoreCase(IotConstants.TEMPERATURE_VIOLATION)) {
								temperatureViolationCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.HUMIDITY_VIOLATION)) {
								humidityViolationCount++;
							}

							else if (currentAlert
									.equalsIgnoreCase(IotConstants.TAMPERING_ALERT)) {
								temperingAlertCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.SENSOR_NOT_REACHABLE)) {
								sensorNotRechableCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.EDGE_GATEWAY_NOT_REACHABLE)) {
								edgeGatewayNotRechableCount++;
							} else {
								otherAlert++;
							}

						} else {
							alertCountJson = new JSONObject();

							alertCountJson.put(
									IotConstants.TEMPERATURE_VIOLATION,
									temperatureViolationCount);
							alertCountJson.put(IotConstants.HUMIDITY_VIOLATION,
									humidityViolationCount);
							alertCountJson.put(IotConstants.TAMPERING_ALERT,
									temperingAlertCount);
							alertCountJson.put(
									IotConstants.SENSOR_NOT_REACHABLE,
									sensorNotRechableCount);
							alertCountJson.put(
									IotConstants.EDGE_GATEWAY_NOT_REACHABLE,
									edgeGatewayNotRechableCount);
							alertCountJson.put("OtherAlert", otherAlert);

							dateJson.put(previousDate, alertCountJson);
							// responseArray.put(dateJson);
							sensorViolationCount = 0;
							temperatureViolationCount = 0;
							humidityViolationCount = 0;
							temperingAlertCount = 0;
							sensorNotRechableCount = 0;
							edgeGatewayNotRechableCount = 0;
							otherAlert = 0;
							if (currentAlert
									.equalsIgnoreCase(IotConstants.TEMPERATURE_VIOLATION)) {
								temperatureViolationCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.HUMIDITY_VIOLATION)) {
								humidityViolationCount++;
							}

							else if (currentAlert
									.equalsIgnoreCase(IotConstants.TAMPERING_ALERT)) {
								temperingAlertCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.SENSOR_NOT_REACHABLE)) {
								sensorNotRechableCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.EDGE_GATEWAY_NOT_REACHABLE)) {
								edgeGatewayNotRechableCount++;
							} else {
								otherAlert++;
							}

						}

						if (alertListSize - 1 == cnt) {
							alertCountJson = new JSONObject();

							alertCountJson.put(
									IotConstants.TEMPERATURE_VIOLATION,
									temperatureViolationCount);
							alertCountJson.put(IotConstants.HUMIDITY_VIOLATION,
									humidityViolationCount);
							alertCountJson.put(IotConstants.TAMPERING_ALERT,
									temperingAlertCount);
							alertCountJson.put(
									IotConstants.SENSOR_NOT_REACHABLE,
									sensorNotRechableCount);
							alertCountJson.put(
									IotConstants.EDGE_GATEWAY_NOT_REACHABLE,
									edgeGatewayNotRechableCount);
							alertCountJson.put("OtherAlert", otherAlert);
							dateJson.put(currentDate, alertCountJson);
							// responseArray.put(dateJson);
						}
						previousDate = currentDate;

					}
					cnt++;
				}

			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return dateJson.toString();
	}

	private List<Object[]> getAlertDataListByDeviceIdAndAlertTypeDateWise(
			String deviceId, Date fromDate, Date toDate, String alertType) {
		List<Object[]> alertDataList = null;
		EntityManager entityManager = null;
		try {

			if (fromDate == null || toDate == null) {
				fromDate = DateUtil
						.convertDateAndTimeToBeginingOfDate(new Date());

				toDate = DateUtil.convertDateAndTimeToEndOfDate(new Date());
			} else {
				fromDate = DateUtil
						.convertDateAndTimeToBeginingOfDate(fromDate);
				toDate = DateUtil.convertDateAndTimeToEndOfDate(toDate);
			}
			System.out.println("from date " + fromDate);
			System.out.println("to daet " + toDate);

			StringBuilder sql = new StringBuilder();
			sql.append(" select date(created_date),alert_type from alert_data  ");
			sql.append(" where date(created_date) between :fromDate And :toDate And device_id =:deviceId ");
			if (alertType != null && !alertType.isEmpty()) {
				sql.append(" and alert_type =:alert_type  ");
			}
			sql.append("order by date(created_date), alert_type ");
			entityManager = emf.createEntityManager();
			Query query = entityManager.createNativeQuery(sql.toString());
			if (alertType != null && !alertType.isEmpty()) {
				query.setParameter("alert_type", alertType);

			}
			query.setParameter("fromDate", fromDate);
			query.setParameter("deviceId", deviceId);
			query.setParameter("toDate", toDate);
			alertDataList = query.getResultList();
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return alertDataList;
	}

	@Override
	public String createAlertDataBashBoard(Integer tenantId, String filterData) {
		JSONObject alertData = this.getAlertDataForDashBoard(tenantId,
				filterData);
		JSONObject jsonResponse = new JSONObject();
		jsonResponse.put("alertData", alertData);
		return jsonResponse.toString();
	}

	private List<AlertDataDTO> creteAlertDataDTOFromAlertDataEntity(
			List<AlertData> alertDataList) {
		List<AlertDataDTO> alertDataDTOList = null;
		if (alertDataList != null) {
			alertDataDTOList = new ArrayList<AlertDataDTO>();
			AlertDataDTO alertDataDTO = null;
			for (AlertData alertData : alertDataList) {
				alertDataDTO = mapper.map(alertData, AlertDataDTO.class);
				alertDataDTOList.add(alertDataDTO);
			}
		}
		if (alertDataDTOList == null) {
			alertDataDTOList = new ArrayList<AlertDataDTO>();
		}
		return alertDataDTOList;
	}

	private String getAlertDataCountByDeviceIdAndAlertTypeAndDateWiseUISpecfic(
			String deviceId, Date fromDate, Date toDate, String alertType) {
		List<Object[]> alertDataList = null;
		Integer sensorViolationCount = 0;
		Integer temperatureViolationCount = 0;
		Integer humidityViolationCount = 0;
		Integer temperingAlertCount = 0;
		Integer edgeGatewayNotRechableCount = 0;
		Integer sensorNotReachableCount = 0;
		Integer otherAlert = 0;
		String currentAlert = null;
		String currentDate = null;
		String previousDate = null;
		JSONObject alertCountJson = new JSONObject();
		Integer speedViolationCount = 0;
		JSONObject dataJson = new JSONObject();
		String dataFormat = "{date,count}";
		ArrayList<String> temperatureViolationArray = new ArrayList<String>();
		ArrayList<String> temperingAlertArray = new ArrayList<String>();
		ArrayList<String> humidityViolationArray = new ArrayList<String>();
		ArrayList<String> sensorViolationArray = new ArrayList<String>();
		ArrayList<String> sensorNotRechableArray = new ArrayList<String>();
		ArrayList<String> edgeGatewayNotReachableArray = new ArrayList<String>();
		ArrayList<String> otherAlertArray = new ArrayList<String>();
		ArrayList<String> speedViolationArray = new ArrayList<String>();
		JSONArray responseArray = new JSONArray();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		int cnt = 0;
		try {
			alertDataList = getAlertDataListByDeviceIdAndAlertTypeDateWise(
					deviceId, fromDate, toDate, alertType);
			if (alertDataList != null && !alertDataList.isEmpty()) {
				int alertListSize = alertDataList.size();
				for (Object[] obj : alertDataList) {
					if (obj[0] != null && obj[1] != null) {
						currentDate = obj[0].toString();
						currentAlert = obj[1].toString();
						if (cnt == 0) {
							previousDate = currentDate;
						}
						if (previousDate.equalsIgnoreCase(currentDate)) {
							if (currentAlert
									.equalsIgnoreCase(IotConstants.TEMPERATURE_VIOLATION)) {
								temperatureViolationCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.HUMIDITY_VIOLATION)) {
								humidityViolationCount++;
							}

							else if (currentAlert
									.equalsIgnoreCase(IotConstants.TAMPERING_ALERT)) {
								temperingAlertCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.SENSOR_NOT_REACHABLE)) {
								sensorNotReachableCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.EDGE_GATEWAY_NOT_REACHABLE)) {
								edgeGatewayNotRechableCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.SPEED_VIOLATION)) {
								speedViolationCount++;
							} else {
								otherAlert++;
							}

						} else {
							Long dateTimeInlong = sdf.parse(previousDate)
									.getTime();
							temperatureViolationArray.add(dataFormat.replace(
									"date", dateTimeInlong.toString()).replace(
									"count",
									temperatureViolationCount.toString()));
							temperingAlertArray.add(dataFormat.replace("date",
									dateTimeInlong.toString()).replace("count",
									temperingAlertCount.toString()));
							humidityViolationArray
									.add(dataFormat.replace("date",
											dateTimeInlong.toString()).replace(
											"count",
											humidityViolationCount.toString()));
							sensorNotRechableArray
									.add(dataFormat.replace("date",
											dateTimeInlong.toString()).replace(
											"count",
											sensorNotReachableCount.toString()));
							edgeGatewayNotReachableArray.add(dataFormat
									.replace("date", dateTimeInlong.toString())
									.replace(
											"count",
											edgeGatewayNotRechableCount
													.toString()));
							otherAlertArray.add(dataFormat.replace("date",
									dateTimeInlong.toString()).replace("count",
									otherAlert.toString()));
							speedViolationArray.add(dataFormat.replace("date",
									dateTimeInlong.toString()).replace("count",
									speedViolationCount.toString()));
							sensorViolationCount = 0;
							temperatureViolationCount = 0;
							humidityViolationCount = 0;
							temperingAlertCount = 0;
							sensorNotReachableCount = 0;
							edgeGatewayNotRechableCount = 0;
							otherAlert = 0;
							speedViolationCount = 0;
							if (currentAlert
									.equalsIgnoreCase(IotConstants.TEMPERATURE_VIOLATION)) {
								temperatureViolationCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.HUMIDITY_VIOLATION)) {
								humidityViolationCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.TAMPERING_ALERT)) {
								temperingAlertCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.SENSOR_NOT_REACHABLE)) {
								sensorNotReachableCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.EDGE_GATEWAY_NOT_REACHABLE)) {
								edgeGatewayNotRechableCount++;
							} else if (currentAlert
									.equalsIgnoreCase(IotConstants.SPEED_VIOLATION)) {
								speedViolationCount++;
							} else {
								otherAlert++;
							}

						}

						if (alertListSize - 1 == cnt) {
							Long dateTimeInlong = sdf.parse(currentDate)
									.getTime();
							temperatureViolationArray.add(dataFormat.replace(
									"date", dateTimeInlong.toString()).replace(
									"count",
									temperatureViolationCount.toString()));
							temperingAlertArray.add(dataFormat.replace("date",
									dateTimeInlong.toString()).replace("count",
									temperingAlertCount.toString()));
							humidityViolationArray
									.add(dataFormat.replace("date",
											dateTimeInlong.toString()).replace(
											"count",
											humidityViolationCount.toString()));
							sensorNotRechableArray
									.add(dataFormat.replace("date",
											dateTimeInlong.toString()).replace(
											"count",
											sensorNotReachableCount.toString()));
							edgeGatewayNotReachableArray.add(dataFormat
									.replace("date", dateTimeInlong.toString())
									.replace(
											"count",
											edgeGatewayNotRechableCount
													.toString()));
							otherAlertArray.add(dataFormat.replace("date",
									dateTimeInlong.toString()).replace("count",
									otherAlert.toString()));
							speedViolationArray.add(dataFormat.replace("date",
									dateTimeInlong.toString()).replace("count",
									speedViolationCount.toString()));
						}
						previousDate = currentDate;

					}
					cnt++;
				}

				alertCountJson.put(IotConstants.TEMPERATURE_VIOLATION,
						temperatureViolationArray);
				alertCountJson.put(IotConstants.HUMIDITY_VIOLATION,
						humidityViolationArray);
				alertCountJson.put(IotConstants.TAMPERING_ALERT,
						temperingAlertArray);
				alertCountJson.put(IotConstants.SENSOR_NOT_REACHABLE,
						sensorNotRechableArray);
				alertCountJson.put(IotConstants.SPEED_VIOLATION,
						speedViolationArray);
				alertCountJson.put(IotConstants.EDGE_GATEWAY_NOT_REACHABLE,
						edgeGatewayNotReachableArray);
				alertCountJson.put("otherAlert", otherAlertArray);
				dataJson.put("data", alertCountJson);

			}

		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}

		return dataJson.toString();
	}

	@Override
	public void deleteAlertDataByDeviceIds(List<String> deviceIds) {
		if (deviceIds != null && deviceIds.size() > 0) {
			alertDataRepository.deleteAlertDataByDeviceIds(deviceIds);
		}

	}

	@Override
	public void sendAlertDataNotification(Integer tenantId, String message) {
		if (tenantId != null && tenantId > 0 && message != null
				&& !message.isEmpty())
			if (isAlertNotificationEnabled) {
				pushNotificationUtil.sendNotificationByTenantId(tenantId,
						message);
			}

	}
}
