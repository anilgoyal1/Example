package net.atos.iot.service;

import java.util.Date;
import java.util.List;

import net.atos.iot.dto.AlertDataDTO;

import org.json.JSONObject;

public interface AlertDataService {

	public List<AlertDataDTO> getAllAlertData();

	public JSONObject getAlertDataCountAlertTypeAndDateWise(String filterDate);

	public JSONObject getAlertDataForDashBoard(Integer tenantId,
			String filterDate);

	List<AlertDataDTO> getAlertDataByLevel(String level);

	public List<AlertDataDTO> getAlertDataByCreatedDateAndDeviceId(
			String deviceId, Date fromDate, Date toDate);

	List<AlertDataDTO> getAllDataByLevelAndTenantId(String level,
			Integer tenantId);

	List<AlertDataDTO> getAllAlertDataByTenantId(Integer tenantId);

	List<String> getAllDistinctAlertType();

	public String getAlertData(String deviceId, String filterData);

	List<AlertDataDTO> getAlertDataByDeviceIdAndExceptAlertType(
			String deviceId, Date fromDate, Date toDate, String alertType);

	String createAlertDataBashBoard(Integer tenentId, String filterData);

	void deleteAlertDataByDeviceIds(List<String> deviceIds);
	
	void sendAlertDataNotification(Integer tenantId, String message);

}
