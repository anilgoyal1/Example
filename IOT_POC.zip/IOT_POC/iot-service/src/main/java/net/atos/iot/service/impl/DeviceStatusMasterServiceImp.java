package net.atos.iot.service.impl;

import java.util.ArrayList;
import java.util.List;

import net.atos.iot.dto.DeviceStatusMasterDTO;
import net.atos.iot.entity.DeviceStatusMaster;
import net.atos.iot.repository.DeviceStatusMasterRepository;
import net.atos.iot.service.DeviceStatusMasterService;
import net.atos.iot.util.DozerBeanMapperFactory;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DeviceStatusMasterServiceImp implements DeviceStatusMasterService {

	private final static Logger logger = Logger
			.getLogger(DeviceStatusMasterServiceImp.class);

	private Mapper dMapper = DozerBeanMapperFactory.getDozerBeanMapper();

	@Autowired
	private DeviceStatusMasterRepository deviceStatusMasterRepository;

	@Override
	public List<DeviceStatusMasterDTO> findAllDeviceStatusMaster() {
		List<DeviceStatusMasterDTO> listOfDeviceStatusDTO = null;
		try {

			List<DeviceStatusMaster> listOfDeviceStatus = deviceStatusMasterRepository
					.getAllDeviceStatusMaster();
			if (listOfDeviceStatus != null && listOfDeviceStatus.size() > 0) {
				DeviceStatusMasterDTO deviceStausMasterDTO = null;
				listOfDeviceStatusDTO = new ArrayList<DeviceStatusMasterDTO>();
				for (DeviceStatusMaster deviceStatusMaster : listOfDeviceStatus) {
					deviceStausMasterDTO = dMapper.map(deviceStatusMaster,
							DeviceStatusMasterDTO.class);
					listOfDeviceStatusDTO.add(deviceStausMasterDTO);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		if (listOfDeviceStatusDTO == null) {

		}
		return listOfDeviceStatusDTO;
	}

	@Override
	public DeviceStatusMasterDTO findDeviceStatusMasterById(Integer id) {
		DeviceStatusMasterDTO deviceStatusDTO = null;
		try {
			if (id != null && id > 0) {
				DeviceStatusMaster deviceStatusMaster = deviceStatusMasterRepository
						.getDeviceStatusMasterById(id);
				if (deviceStatusMaster != null) {
					deviceStatusDTO = dMapper.map(deviceStatusMaster,
							DeviceStatusMasterDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return deviceStatusDTO;
	}

	@Override
	public DeviceStatusMasterDTO getDeviceStatusMasterIdByName(String status) {
		DeviceStatusMasterDTO deviceStatusDTO = null;
		try {
			if (status != null) {
				DeviceStatusMaster deviceStatusMaster = deviceStatusMasterRepository
						.getDeviceStatusMasterIdByName(status);
				if (deviceStatusMaster != null) {
					deviceStatusDTO = dMapper.map(deviceStatusMaster,
							DeviceStatusMasterDTO.class);
				}
			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return deviceStatusDTO;
	}

	@Override
	public DeviceStatusMaster getDeviceStatusMasterByStatusName(String status) {
		DeviceStatusMaster deviceStatusMaster = null;
		try {
			if (status != null) {
				deviceStatusMaster = deviceStatusMasterRepository
						.getDeviceStatusMasterIdByName(status);

			}
		} catch (Exception e) {
			logger.error(IotConstants.Exception, e);
		}
		return deviceStatusMaster;
	}

	@Override
	public String createDeviceStatusMaster(
			DeviceStatusMasterDTO deviceStatusMasterDTO) {
		if (deviceStatusMasterDTO != null) {
			DeviceStatusMaster deviceStatusMaster = dMapper.map(
					deviceStatusMasterDTO, DeviceStatusMaster.class);
			if (deviceStatusMaster != null) {
				deviceStatusMasterRepository.save(deviceStatusMaster);
			}
			return IotConstants.SUCCESS;
		}
		return IotConstants.FAILURE;
	}

}
