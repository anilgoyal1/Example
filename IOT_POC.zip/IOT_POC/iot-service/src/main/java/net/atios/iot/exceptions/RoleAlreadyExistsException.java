package net.atios.iot.exceptions;

public class RoleAlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5313133823237734199L;

	/**
	 * Instantiates a new RoleAlreadyExistsException exception.
	 */
	public RoleAlreadyExistsException() {
		super();
	}

	/**
	 * Instantiates a new RoleAlreadyExistsException exception.
	 * 
	 * @param message
	 *            the string
	 */
	public RoleAlreadyExistsException(final String message) {
		super(message);
	}

	/**
	 * Instantiates a new RoleAlreadyExistsException exception.
	 * 
	 * @param errCodeValue
	 *            the string
	 * 
	 * @param cause
	 *            the Throwable object
	 */
	public RoleAlreadyExistsException(final String errCodeValue,
			final Throwable cause) {
		super(errCodeValue, cause);
	}

	/**
	 * Instantiates a new RoleAlreadyExistsException exception.
	 * 
	 * @param cause
	 *            the Throwable object
	 */
	public RoleAlreadyExistsException(final Throwable cause) {
		super(cause);
	}
}
