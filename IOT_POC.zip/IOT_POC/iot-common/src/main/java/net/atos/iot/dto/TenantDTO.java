package net.atos.iot.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class TenantDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 935618243755678020L;

	private Integer tenantId;

	private String tenantName;

	private boolean isActive;

	private String serviceName;

	private String contactNo;

	private String emailId;

	private String createdBy;

	private Timestamp createdDate;

	private String modifiedBy;

	private Timestamp modifiedDate;

	private Set<CountryDTO> country;

	private List<UserDetailsDTO> userDetails;

	List<Integer> countriesIds;

	private Double longitude;

	private Double latitude;

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Integer getTenantId() {
		return tenantId;
	}

	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public List<UserDetailsDTO> getUserDetails() {
		return userDetails;
	}

	@JsonIgnore
	public void setUserDetails(List<UserDetailsDTO> userDetails) {
		this.userDetails = userDetails;
	}

	public Set<CountryDTO> getCountry() {
		return country;
	}

	public void setCountry(Set<CountryDTO> country) {
		this.country = country;
	}

	public List<Integer> getCountriesIds() {
		return countriesIds;
	}

	public void setCountriesIds(List<Integer> countriesIds) {
		this.countriesIds = countriesIds;
	}

}
