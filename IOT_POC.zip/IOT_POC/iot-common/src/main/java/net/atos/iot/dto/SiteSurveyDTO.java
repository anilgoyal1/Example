package net.atos.iot.dto;

import java.io.Serializable;
import java.util.Date;

public class SiteSurveyDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7745327423580122963L;

	private Long surveyId;

	DeviceMasterDTO deviceMaster;

	String networkConnectivitCheck;

	String networkType;

	String siteName;

	String address;

	String phone;

	String roomName;

	String exactLocation;

	String ipAddressofDevice;

	String hasRemoteConnectivityWithEdgeGatway;

	Date createDate;

	String createdBy;

	String modifiedDate;

	String assingedTo;

	Date assingedDate;

	String completedBy;

	Date completedDate;

	String status;

	String newStatus;

	public String getNewStatus() {
		return newStatus;
	}

	public void setNewStatus(String newStatus) {
		this.newStatus = newStatus;
	}

	public Long getSurveyId() {
		return surveyId;
	}

	public void setSurveyId(Long surveyId) {
		this.surveyId = surveyId;
	}

	public DeviceMasterDTO getDeviceMaster() {
		return deviceMaster;
	}

	public void setDeviceMaster(DeviceMasterDTO deviceMaster) {
		this.deviceMaster = deviceMaster;
	}

	public String getNetworkConnectivitCheck() {
		return networkConnectivitCheck;
	}

	public void setNetworkConnectivitCheck(String networkConnectivitCheck) {
		this.networkConnectivitCheck = networkConnectivitCheck;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getExactLocation() {
		return exactLocation;
	}

	public void setExactLocation(String exactLocation) {
		this.exactLocation = exactLocation;
	}

	public String getIpAddressofDevice() {
		return ipAddressofDevice;
	}

	public void setIpAddressofDevice(String ipAddressofDevice) {
		this.ipAddressofDevice = ipAddressofDevice;
	}

	public String getHasRemoteConnectivityWithEdgeGatway() {
		return hasRemoteConnectivityWithEdgeGatway;
	}

	public void setHasRemoteConnectivityWithEdgeGatway(
			String hasRemoteConnectivityWithEdgeGatway) {
		this.hasRemoteConnectivityWithEdgeGatway = hasRemoteConnectivityWithEdgeGatway;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getAssingedTo() {
		return assingedTo;
	}

	public void setAssingedTo(String assingedTo) {
		this.assingedTo = assingedTo;
	}

	public Date getAssingedDate() {
		return assingedDate;
	}

	public void setAssingedDate(Date assingedDate) {
		this.assingedDate = assingedDate;
	}

	public String getCompletedBy() {
		return completedBy;
	}

	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}

	public Date getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(Date completedDate) {
		this.completedDate = completedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
