
package net.atos.iot.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.json.JSONObject;

public class DateUtil {

	private static final Logger LOGGER = Logger.getLogger(DateUtil.class);

	private static final String UTC = "UTC";

	private static TimeZone tz = TimeZone.getTimeZone(UTC);

	private static final ThreadLocal<DateFormat> threadSafeDateFormat = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat(IotConstants.ISODATE);
		}
	};

	public static Date convertISOStringToLocalDate(String source)
			throws ParseException {
		threadSafeDateFormat.get().setTimeZone(tz);
		Date d = threadSafeDateFormat.get().parse(source);
		return d;
	}

	public static String convertDateToDateISODateString(Date sourse)
			throws ParseException {
		threadSafeDateFormat.get().setTimeZone(tz);
		String d = threadSafeDateFormat.get().format(sourse);
		return d;
	}

	public static String createCurrentDateInISOFormat() throws ParseException {
		String dateStr = null;
		Calendar c = Calendar.getInstance();
		c.setTime(new Date());
		Date d = c.getTime();
		dateStr = convertDateToDateISODateString(d);
		return dateStr;
	}

	public static Date convertDateAndTimeToBeginingOfDate(Date currentDate) {
		Calendar c = null;
		Date beginingOfDate = null;
		try {
			if (currentDate == null) {
				currentDate = new Date();
			}

			c = Calendar.getInstance();
			c.setTime(currentDate);
			c.set(Calendar.HOUR_OF_DAY, 0);
			c.set(Calendar.MINUTE, 0);
			c.set(Calendar.SECOND, 0);
			c.set(Calendar.MILLISECOND, 0);
			beginingOfDate = c.getTime();
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return beginingOfDate;
	}

	public static Date convertDateAndTimeToEndOfDate(Date currentDate) {
		Calendar c = null;
		Date EndOfDate = null;
		try {
			if (currentDate == null) {
				currentDate = new Date();
			}
			c = Calendar.getInstance();
			c.setTime(currentDate);
			c.set(Calendar.HOUR_OF_DAY, 23);
			c.set(Calendar.MINUTE, 59);
			c.set(Calendar.SECOND, 59);
			c.set(Calendar.MILLISECOND, 999);
			EndOfDate = c.getTime();
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return EndOfDate;
	}

	public static long differenceInMinute(Date fromDate, Date toDate) {
		long diffMinutes = 0;
		try {
			long diff = toDate.getTime() - fromDate.getTime();
			diffMinutes = (diff / (60 * 1000)) % 60;

		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return diffMinutes;

	}

	public static long differenceInHours(Date fromDate, Date toDate) {
		long diffrenceInHours = 0;
		try {
			long diff = toDate.getTime() - fromDate.getTime();
			diffrenceInHours = diff / (60 * 60 * 1000);
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return diffrenceInHours;

	}

	public static Date getDateFromJSONString(String filterData, String keyName) {
		String dateStr = null;
		Date date = null;
		try {
			if (filterData != null && !filterData.isEmpty() && keyName != null
					&& !keyName.isEmpty()) {
				JSONObject json = new JSONObject(filterData);
				if (!json.isNull(keyName)) {
					dateStr = json.getString(keyName);
					date = DateUtil.convertISOStringToLocalDate(dateStr);
				}
			}
		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		}
		return date;
	}

}
