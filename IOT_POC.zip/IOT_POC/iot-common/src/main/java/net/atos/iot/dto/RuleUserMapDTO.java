package net.atos.iot.dto;

import java.io.Serializable;

public class RuleUserMapDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2329356171146676893L;

	private Long id;

	private String ruleCode;

	private Integer userDetailsId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRuleCode() {
		return ruleCode;
	}

	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}

	public Integer getUserDetailsId() {
		return userDetailsId;
	}

	public void setUserDetailsId(Integer userDetailsId) {
		this.userDetailsId = userDetailsId;
	}

}
