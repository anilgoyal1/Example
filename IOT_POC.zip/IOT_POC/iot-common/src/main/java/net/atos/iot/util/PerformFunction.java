package net.atos.iot.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class PerformFunction {

	private static final Logger LOGGER = Logger
			.getLogger(PerformFunction.class);

	@Value("${isHttpProxyRequired}")
	private boolean isHttpProxyRequired;

	@Value("${httpProxyHost}")
	private String httpProxyHost;

	@Value("${httpProxyPort}")
	private String httpProxyPort;

	static final String CONTENT_TYPE = "Content-Type";

	static final String APPLICATION_JSON = "application/json";

	static final String ACCEPT = "Accept";

	static final String POST = "POST";

	static final String GET = "GET";

	static final String DELETE = "DELETE";

	public String performFunction(String uri, String method, String inputJSONStr)
			throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String response = null;
		StringBuilder responsePost = new StringBuilder();

		if (isHttpProxyRequired) {

			System.getProperties().put("http.proxyHost", httpProxyHost);
			System.getProperties().put("http.proxyPort", httpProxyPort);
		}
		HttpURLConnection conn = null;
		try {
			URL url = new URL(uri);
			conn = (HttpURLConnection) url.openConnection();
			if (POST.equalsIgnoreCase(method)) {
				conn.setDoOutput(true);
				conn.setRequestMethod(POST);
				conn.setRequestProperty(CONTENT_TYPE, APPLICATION_JSON);
				OutputStream os = conn.getOutputStream();
				os.write(inputJSONStr.getBytes());
				os.flush();
				if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED
						|| conn.getResponseCode() != HttpURLConnection.HTTP_CONFLICT) {
					LOGGER.info("Failed : HTTP error code:"
							+ conn.getResponseCode());
				}
				BufferedReader br = new BufferedReader(new InputStreamReader(
						conn.getInputStream()));
				String output;
				while ((output = br.readLine()) != null) {
					responsePost.append(output);
				}
				conn.disconnect();
				response = responsePost.toString();
			} else if (DELETE.equalsIgnoreCase(method)) {
				HttpURLConnection httpURLConnection = null;
				httpURLConnection = (HttpURLConnection) url.openConnection();
				httpURLConnection.setRequestProperty(CONTENT_TYPE,
						"application/x-www-form-urlencoded");
				httpURLConnection.setRequestMethod(DELETE);
				System.out.println(httpURLConnection.getResponseCode());
			} else if (GET.equalsIgnoreCase(method)) {
				conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod(GET);
				conn.setRequestProperty(CONTENT_TYPE, "application/json");
				if (conn.getResponseCode() == 200) {
					response = IotConstants.SUCCESS;
				} else {
					response = IotConstants.FAILURE;
				}

				conn.disconnect();
			}

		} catch (Exception e) {
			LOGGER.error(IotConstants.Exception, e);
		} finally {

			System.getProperties().remove("http.proxyHost");
			System.getProperties().remove("http.proxyPort");

			if (conn != null) {
				conn.disconnect();
			}
		}
		LOGGER.info(response);
		return response;

	}
}
