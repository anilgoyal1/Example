package net.atos.iot.dto;

import java.io.Serializable;


public class TicketRootCauseDTO implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2456784475393984829L;

	private Integer id;

	private String rootCause;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRootCause() {
		return rootCause;
	}

	public void setRootCause(String rootCause) {
		this.rootCause = rootCause;
	}
	
	
	
}
