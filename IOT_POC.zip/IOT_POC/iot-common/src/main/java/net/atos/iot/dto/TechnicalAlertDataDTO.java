package net.atos.iot.dto;

import java.io.Serializable;
import java.util.Date;

public class TechnicalAlertDataDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3061016303058768256L;

	private Long id;
	String deviceId;
	String simulated;
	Double temprature;
	Double humidity;
	Date lastDataReceivedTime;
	String description;
	Date createdDate;
	String alertType;
	


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getSimulated() {
		return simulated;
	}

	public void setSimulated(String simulated) {
		this.simulated = simulated;
	}

	public Double getTemprature() {
		return temprature;
	}

	public void setTemprature(Double temprature) {
		this.temprature = temprature;
	}

	public Double getHumidity() {
		return humidity;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}

	public Date getLastDataReceivedTime() {
		return lastDataReceivedTime;
	}

	public void setLastDataReceivedTime(Date lastDataReceivedTime) {
		this.lastDataReceivedTime = lastDataReceivedTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
