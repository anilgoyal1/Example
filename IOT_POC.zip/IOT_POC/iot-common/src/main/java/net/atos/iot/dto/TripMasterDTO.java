package net.atos.iot.dto;

import java.io.Serializable;
import java.util.Date;

public class TripMasterDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6246575657599060203L;

	private Long tripId;

	String driverName;

	String deviceId;

	String licensePlateNo;

	String tripStartLatitude;

	String tripEndLatitude;

	String tripStartLongitude;

	String tripEndLongitude;

	String tripStatus;

	Date tripStartTime;

	Date tripEndTime;

	long estimationTimeInMinute;

	String startLocation;

	String endLocation;

	String tripFeedback;

	long tripDurationInMinute;

	Double distance;


	public long getTripDurationInMinute() {
		return tripDurationInMinute;
	}

	public void setTripDurationInMinute(long tripDurationInMinute) {
		this.tripDurationInMinute = tripDurationInMinute;
	}

	public Long getTripId() {
		return tripId;
	}

	public void setTripId(Long tripId) {
		this.tripId = tripId;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getLicensePlateNo() {
		return licensePlateNo;
	}

	public void setLicensePlateNo(String licensePlateNo) {
		this.licensePlateNo = licensePlateNo;
	}

	public String getTripStartLatitude() {
		return tripStartLatitude;
	}

	public void setTripStartLatitude(String tripStartLatitude) {
		this.tripStartLatitude = tripStartLatitude;
	}

	public String getTripEndLatitude() {
		return tripEndLatitude;
	}

	public void setTripEndLatitude(String tripEndLatitude) {
		this.tripEndLatitude = tripEndLatitude;
	}

	public String getTripStartLongitude() {
		return tripStartLongitude;
	}

	public void setTripStartLongitude(String tripStartLongitude) {
		this.tripStartLongitude = tripStartLongitude;
	}

	public String getTripEndLongitude() {
		return tripEndLongitude;
	}

	public void setTripEndLongitude(String tripEndLongitude) {
		this.tripEndLongitude = tripEndLongitude;
	}

	public String getTripStatus() {
		return tripStatus;
	}

	public void setTripStatus(String tripStatus) {
		this.tripStatus = tripStatus;
	}

	public Date getTripStartTime() {
		return tripStartTime;
	}

	public void setTripStartTime(Date tripStartTime) {
		this.tripStartTime = tripStartTime;
	}

	public Date getTripEndTime() {
		return tripEndTime;
	}

	public void setTripEndTime(Date tripEndTime) {
		this.tripEndTime = tripEndTime;
	}

	public long getEstimationTimeInMinute() {
		return estimationTimeInMinute;
	}

	public void setEstimationTimeInMinute(long estimationTimeInMinute) {
		this.estimationTimeInMinute = estimationTimeInMinute;
	}

	public String getStartLocation() {
		return startLocation;
	}

	public void setStartLocation(String startLocation) {
		this.startLocation = startLocation;
	}

	public String getEndLocation() {
		return endLocation;
	}

	public void setEndLocation(String endLocation) {
		this.endLocation = endLocation;
	}

	public String getTripFeedback() {
		return tripFeedback;
	}

	public void setTripFeedback(String tripFeedback) {
		this.tripFeedback = tripFeedback;
	}

	public Double getDistance() {
		return distance;
	}

	public void setDistance(Double distance) {
		this.distance = distance;
	}
	
	

}
