package net.atos.iot.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Name", "TaskTemplate" })
public class SwarmApiDTO {

	@JsonProperty("Name")
	private String name;
	@JsonProperty("TaskTemplate")
	private TaskTemplate taskTemplate;

	@JsonProperty("Name")
	public String getName() {
		return name;
	}

	@JsonProperty("Name")
	public void setName(String name) {
		this.name = name;
	}

	@JsonProperty("TaskTemplate")
	public TaskTemplate getTaskTemplate() {
		return taskTemplate;
	}

	@JsonProperty("TaskTemplate")
	public void setTaskTemplate(TaskTemplate taskTemplate) {
		this.taskTemplate = taskTemplate;
	}

}