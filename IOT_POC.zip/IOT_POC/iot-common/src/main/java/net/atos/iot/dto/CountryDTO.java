package net.atos.iot.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class CountryDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer countryId;

	private String countryName;

	private boolean isActive;

	private String countryCode;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;

	private List<RegionDTO> regions;

	private List<Integer> regionsIdList;

	public List<Integer> getRegionsIdList() {
		return regionsIdList;
	}

	public void setRegionsIdList(List<Integer> regionsIdList) {
		this.regionsIdList = regionsIdList;
	}

	public List<RegionDTO> getRegions() {
		return regions;
	}

	public void setRegions(List<RegionDTO> regions) {
		this.regions = regions;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
