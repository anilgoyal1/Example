package net.atos.iot.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class BranchDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7169751552343970872L;

	private Long branchId;
	private boolean isActive;
	private String address1;
	private String branchCode;
	private String branchCodeCust;
	private String branchName;
	private String branchSubtype;
	private String branchType;
	private String createdBy;
	private Timestamp createdDate;
	private Double branchLatitude;
	private Double branchLongitude;
	private String modifiedBy;
	private Timestamp modifiedDate;

	@JsonBackReference
	private DistrictDTO district;

	private Set<LocationDTO> locations = new HashSet<LocationDTO>();

	public Set<LocationDTO> getLocations() {
		return locations;
	}

	public void setLocations(Set<LocationDTO> locations) {
		this.locations = locations;
	}

	public Long getBranchId() {
		return branchId;
	}

	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchCodeCust() {
		return branchCodeCust;
	}

	public void setBranchCodeCust(String branchCodeCust) {
		this.branchCodeCust = branchCodeCust;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchSubtype() {
		return branchSubtype;
	}

	public void setBranchSubtype(String branchSubtype) {
		this.branchSubtype = branchSubtype;
	}

	public String getBranchType() {
		return branchType;
	}

	public void setBranchType(String branchType) {
		this.branchType = branchType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Double getBranchLatitude() {
		return branchLatitude;
	}

	public void setBranchLatitude(Double branchLatitude) {
		this.branchLatitude = branchLatitude;
	}

	public Double getBranchLongitude() {
		return branchLongitude;
	}

	public void setBranchLongitude(Double branchLongitude) {
		this.branchLongitude = branchLongitude;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public DistrictDTO getDistrict() {
		return district;
	}

	public void setDistrict(DistrictDTO district) {
		this.district = district;
	}

}
