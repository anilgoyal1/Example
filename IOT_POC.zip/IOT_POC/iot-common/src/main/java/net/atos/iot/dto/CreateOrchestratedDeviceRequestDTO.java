package net.atos.iot.dto;

import java.io.Serializable;

public class CreateOrchestratedDeviceRequestDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3034435672890183519L;
	
	int numberOfdevice;
	
	int tenantId;

	public int getNumberOfdevice() {
		return numberOfdevice;
	}

	public void setNumberOfdevice(int numberOfdevice) {
		this.numberOfdevice = numberOfdevice;
	}

	public int getTenantId() {
		return tenantId;
	}

	public void setTenantId(int tenantId) {
		this.tenantId = tenantId;
	}  
	
	
	
	
	

}
