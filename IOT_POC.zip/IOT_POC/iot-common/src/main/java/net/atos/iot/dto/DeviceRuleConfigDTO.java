package net.atos.iot.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DeviceRuleConfigDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2067666516323767548L;

	private String deviceId;
	private List<String> ruleCodes = new ArrayList<String>();
	
	public String getDeviceId() {
		return deviceId;
	}
	
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public List<String> getRuleCodes() {
		return ruleCodes;
	}
	public void setRuleCodes(List<String> ruleCodes) {
		this.ruleCodes = ruleCodes;
	}
	
	
	
}
