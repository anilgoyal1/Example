package net.atos.iot.util;

import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;

public class DozerBeanMapperFactory {

	private static final Mapper mapper = new DozerBeanMapper();;

	private DozerBeanMapperFactory() {

	}

	public static Mapper getDozerBeanMapper() {
		return mapper;

	}

}
