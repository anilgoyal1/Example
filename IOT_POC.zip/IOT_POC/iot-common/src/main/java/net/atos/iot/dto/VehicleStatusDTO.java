package net.atos.iot.dto;

import java.io.Serializable;

public class VehicleStatusDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2696880564335420428L;
	
	
	private String deviceId;
	
	private String status;

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	

}
