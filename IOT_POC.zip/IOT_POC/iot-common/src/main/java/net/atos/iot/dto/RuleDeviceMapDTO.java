package net.atos.iot.dto;

import java.io.Serializable;

public class RuleDeviceMapDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1415769654213560837L;

	private Long id;

	private String ruleCode;

	private String deviceId;

	private boolean isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRuleCode() {
		return ruleCode;
	}

	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
	
	
	

}
