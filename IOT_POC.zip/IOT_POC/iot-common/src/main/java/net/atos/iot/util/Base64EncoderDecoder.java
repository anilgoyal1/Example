package net.atos.iot.util;

import org.apache.commons.codec.binary.Base64;

public class Base64EncoderDecoder {

	public static String encodeString(String encodeString) {
		if (encodeString != null && !encodeString.isEmpty()) {
			byte[] encoded = Base64.encodeBase64(encodeString.getBytes());
			return new String(encoded);
		}
		return null;
	}

	public static String decodeString(String decodeString) {
		if (decodeString != null && !decodeString.isEmpty()) {
			byte[] decoded = Base64.decodeBase64(decodeString);
			return new String(decoded);
		}
		return null;
	}

}
