package net.atos.iot.util;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

@Component
public class SendDataToRabbitMQ {

	@Value("${spring.rabbitmq.host}")
	private String rabbitMQHostName;

	@Value("${spring.rabbitmq.port}")
	private Integer rabbitMQPort;

	@Value("${spring.rabbitmq.username}")
	private String rabbitMQUserName;

	@Value("${spring.rabbitmq.password}")
	private String rabbitMQPassword;

	@Value("${rabbitMQExchangeType}")
	private String rabbitMQExchangeType;

	@Value("${spring.rabbitmq.directExchangeName}")
	private String rabbitMQExchangeName;

	@Value("${isHttpProxyRequired}")
	private boolean isHttpProxyRequired;

	@Value("${httpProxyHost}")
	private String httpProxyHost;

	@Value("${httpProxyPort}")
	private String httpProxyPort;

	public void sendDataToQueue(String json, String queueName, String routingKey) {
		sendDataToQueue(json, rabbitMQHostName, rabbitMQPort, rabbitMQUserName, rabbitMQPassword, rabbitMQExchangeType,
				rabbitMQExchangeName, queueName, routingKey);
	}

	public void sendDataToQueue(String json, String host, int port, String userName, String password,
			String exchangeType, String exchangeName, String queueName, String routKey) {
		Channel channel = null;
		Connection connection = null;
		try {
			if (isHttpProxyRequired) {
				System.getProperties().put("http.proxyHost", httpProxyHost);
				System.getProperties().put("http.proxyPort", httpProxyPort);
			}
			ConnectionFactory factory = new ConnectionFactory();
			factory.setHost(host);
			factory.setPort(port);
			factory.setPassword(password);
			factory.setUsername(userName);
			connection = factory.newConnection();
			channel = connection.createChannel();
			channel.exchangeDeclare(exchangeName, exchangeType, true);
			if (queueName != null) {
				channel.queueBind(queueName, exchangeName, routKey);
			}
			channel.basicPublish(exchangeName, routKey, null, json.getBytes());
			System.out.println(" [x] Sent '" + json + "'");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (channel != null && channel.isOpen()) {
					channel.close();
				}
				if (connection != null && connection.isOpen())
					connection.close();
				if (isHttpProxyRequired) {
					System.getProperties().remove("http.proxyHost");
					System.getProperties().remove("http.proxyPort");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

	public void sendMessageToRabbitMQ(String QUEUE_NAME,String message) {
		//ConnectionFactory factory = new ConnectionFactory();
		//factory.setHost(rabbitMQHostName);
		Connection connection = null;
		Channel channel=null;;
		try {
			if (isHttpProxyRequired) {
				System.getProperties().put("http.proxyHost", httpProxyHost);
				System.getProperties().put("http.proxyPort", httpProxyPort);
			}
			ConnectionFactory factory = new ConnectionFactory();
			factory.setHost(rabbitMQHostName);
			factory.setPort(rabbitMQPort);
			factory.setPassword(rabbitMQPassword);
			factory.setUsername(rabbitMQUserName);
			connection = factory.newConnection();
			channel = connection.createChannel();
			channel.queueDeclare(QUEUE_NAME, false, false, false, null);
			channel.basicPublish("", QUEUE_NAME, null, message.getBytes("UTF-8"));
			System.out.println(" [x] Sent '" + message + "'");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (channel != null && channel.isOpen()) {
					channel.close();
				}
				if (connection != null && connection.isOpen())
					connection.close();
				if (isHttpProxyRequired) {
					System.getProperties().remove("http.proxyHost");
					System.getProperties().remove("http.proxyPort");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

}
