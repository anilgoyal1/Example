package net.atos.iot.util;


public class IotConstants {

	public static final String SUCCESS = "success";

	public static final String FAILURE = "failure";

	public static final String result = "result";

	public static final boolean FALSE = false;

	public static final boolean TRUE = true;

	public static final String RESPONSE_OK = "OK";

	public static final String RESULT = "Result";

	public static final String RECORDS = "Records";

	public static final String Exception = "exception";

	public static final String toDate = "toDate";

	public static final String fromDate = "fromDate";

	public static final String NewDeviceStatus = "New";

	public static final String VEHICLE_MOVING = "Moving";

	public static final String VEHICLE_STOPPED = "Stopped";

	public static final String VEHICLE_IDLE = "Idle";

	public static final String VEHICLE_UNAVAILABLE = "unavailable";

	public static final int vechicleTrackingDefaultTimeInMinute = 60;

	public static final String DEVICEID = "deviceId";

	public static final String VEHICLE_STATUS = "vechicalStatus";

	public static final String TICKET_ALERT_TYPE_CHANGE_REQUEST = "CHANGE_REQUEST";

	public static final String ticketTypeNew = "New";

	public static final String ticketTypeAssigned = "Assigned";

	public static final String ticketTypeResolved = "Resolved";

	public static final String ticketTypeEscalated = "Escalated";

	public static final String ticketTypeClose = "Close";

	public static final String businessAlert = "BUSINESS_ALERT";

	public static final String technicalAlert = "TECHNICAL_ALERT";

	public static final String ticketLevelHigh = "HIGH";

	public static final String ticketLevelMedium = "MEDIUM";

	public static final String ticketAssignedUser = "Alex";

	public static final String ticketCloseUser = "Peter";

	public static final String systemUser = "SYSTEM";

	public static final String ticketType = "AlertType";

	public static final String NEW_DEVICE_INSTALATION_TICKET_DESCRIPTION = "New site survey and device provisioning";

	public static final String NEW_DEVICE_TICKET_TYPE = "SITE_SURVEY_AND_PROVISIONING";

	public static final String liveDeviceStatus = "Live";

	public static final String deadDeviceStatus = "Dead";

	public static final String RejectedDeviceStatus = "Rejected";

	public static final String POST = "POST";

	public static final String businessAlertCreatedFor = "Business Alert Created for ";

	public static final String newTicketCreatedFor = "New Ticket Created For ";

	public static final String technicalAlertCreatedFor = "Technical Alert Created for ";

	public static final String ISODATE = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	public static final String SENSOR_DATA_SAVED = " sensor data saved ";

	public static final String SENSOR_DATA = "Sensor Data :";

	public static final String GPS_SENSOR_DATA = "GPS Sensor Data :";

	public static final String GPS_SENSOR_DATA_SAVED = "GPS Sensor Data Saved";

	public static final String GPS_SENSOR_ARRAY_DATA = "GPS Sensor Array Data :";

	public static final String GPS_SENSOR_ARRAY_DATA_SAVED = "GPS Sensor Array Data Saved";

	public static final String ALERT_DATA = "Alert Data :";

	public static final String ALERT_DATA_SAVED = "Alert Data Saved";

	public static final String GPS_SENSOR_ALERT_DATA = "GPS Sensor Alert Data :";

	public static final String GPS_SENSOR_ALERT_DATA_SAVED = "GPS Sensor Alert Date Saved";

	public static final String GPS_SENSOR_ALERT_ARRAY_DATA = "GPS Sensor Alert Array Data :";

	public static final String GPS_SENSOR_ALERT_ARRAY_DATA_SAVED = "GPS Sensor Alert Array Data Saved";

	public static final String TAMPERING_ALERT = "TAMPERING_ALERT";

	public static final String EDGE_GATEWAY_NOT_REACHABLE = "EDGE_GATEWAY_NOT_REACHABLE";

	// public static final String NETWORK_ISSUES = "NETWORK_ISSUES";

	public static final String SENSOR_NOT_REACHABLE = "SENSOR_NOT_REACHABLE";

	public static final String TEMPERATURE_VIOLATION = "TEMPERATURE_VIOLATION";

	public static final String HUMIDITY_VIOLATION = "HUMIDITY_VIOLATION";

	public static final String SPEED_VIOLATION = "SPEED_VIOLATION";

	public static final String PROVISIONED_DEVICE_STATUS = "Provisioned";

	public static final String SITE_SURVEY_OK = "Ok";

	public static final String SITE_SURVEY_NOT_OK = "Not ok";

	public static final String REJECTED_DEVICE_STATUS = "Rejected";

	public static final String ENDED = "Ended";

	public static final String BEFORE_TIME = "Before Time";

	public static final String ON_TIME = "On Time";

	public static final String AFTER_TIME = "After Time";

	public static final String CONTENT_TYPE = "Content-Type";

	public static final String APPLICATION_JSON_CHARSET = "application/json; charset=UTF-8";

	public static final String AUTHORIZATION = "Authorization";

	public static final String UTF_8 = "UTF-8";

	public static final String Running = "Running";

	public static final String TRIP_STARTED = "started";

	public static final long HOURS_IN_WEEKS = 168;

	public static final long HOURS_IN_MONTHS = 720;

	public static final String FIELD_ENGINEER = "Field Engineer";

	public static final String SERVICE_MANAGER = "Service Manager";

	public static final String PUSH_NOTIFICATION_EXCHANGE_NAME = "PushNotificationExchange";

	public static final String PUSH_NOTIFICATION_ROUTING_KEY_FOR_BROADCAST_MESSAGE = "broadCast*.";

	public static final String DELETE = "DELETE";

	public static final String GET = "GET";

	public static final String CREATE = "CREATE";

	public static final String START = "START";

	public static final String STOP = "STOP";

	public static final String BTIC_ADMIN = "BTIC_ADMIN";

	
}
