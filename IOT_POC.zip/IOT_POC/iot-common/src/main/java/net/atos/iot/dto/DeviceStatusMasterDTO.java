package net.atos.iot.dto;

import java.io.Serializable;

public class DeviceStatusMasterDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -701229541937384238L;
	
	private Integer id;

	private String statusName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}


}
