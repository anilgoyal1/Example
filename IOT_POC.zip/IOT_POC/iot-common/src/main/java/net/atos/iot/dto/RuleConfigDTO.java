package net.atos.iot.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class RuleConfigDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2529667657576100456L;

	private String ruleCode;

	private String paramMaxVal;

	private String paramMinVal;

	private String paramName;

	private boolean isActive;

	private Set<String> devices = new HashSet<String>(0);

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean active) {
		this.isActive = active;
	}

	public String getRuleCode() {
		return ruleCode;
	}

	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}

	public String getParamMaxVal() {
		return paramMaxVal;
	}

	public void setParamMaxVal(String paramMaxVal) {
		this.paramMaxVal = paramMaxVal;
	}

	public String getParamMinVal() {
		return paramMinVal;
	}

	public void setParamMinVal(String paramMinVal) {
		this.paramMinVal = paramMinVal;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public Set<String> getDevices() {
		return devices;
	}

	public void setDevices(Set<String> devices) {
		this.devices = devices;
	}

}
