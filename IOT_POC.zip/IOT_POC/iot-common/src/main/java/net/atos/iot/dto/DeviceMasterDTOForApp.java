package net.atos.iot.dto;

import java.io.Serializable;

public class DeviceMasterDTOForApp implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7097767952850679431L;

	String deviceId;

	String status;

	String tenantName;

	boolean isSimulatedDevice;

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public boolean isSimulatedDevice() {
		return isSimulatedDevice;
	}

	public void setSimulatedDevice(boolean isSimulated) {
		this.isSimulatedDevice = isSimulated;
	}
	
	
	

}
