package net.atos.iot.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"Image",
"Args",
"Hostname"
})
public class ContainerSpec {

@JsonProperty("Image")
private String image;
@JsonProperty("Args")
private List<String> args = null;
@JsonProperty("Hostname")
private String hostname;


@JsonProperty("Image")
public String getImage() {
return image;
}

@JsonProperty("Image")
public void setImage(String image) {
this.image = image;
}

@JsonProperty("Args")
public List<String> getArgs() {
return args;
}

@JsonProperty("Args")
public void setArgs(List<String> args) {
this.args = args;
}

@JsonProperty("Hostname")
public String getHostname() {
return hostname;
}

@JsonProperty("Hostname")
public void setHostname(String hostname) {
this.hostname = hostname;
}



}