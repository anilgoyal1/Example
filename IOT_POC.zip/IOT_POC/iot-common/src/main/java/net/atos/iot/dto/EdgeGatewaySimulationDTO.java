package net.atos.iot.dto;

import java.io.Serializable;
import java.util.List;

public class EdgeGatewaySimulationDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4728249671359716390L;

	private String simulationName;

	private String simulationStatus;

	private Integer tenantId;

	private Integer minTemperature;

	private Integer maxTemperature;

	private Integer minHumidity;

	private Integer maxHumidity;

	private List<String> deviceIds;

	public String getSimulationStatus() {
		return simulationStatus;
	}

	public void setSimulationStatus(String simulationStatus) {
		this.simulationStatus = simulationStatus;
	}

	public String getSimulationName() {
		return simulationName;
	}

	public void setSimulationName(String simulationName) {
		this.simulationName = simulationName;
	}

	public Integer getTenantId() {
		return tenantId;
	}

	public void setTenantId(Integer tenantId) {
		this.tenantId = tenantId;
	}

	public List<String> getDeviceIds() {
		return deviceIds;
	}

	public void setDeviceIds(List<String> deviceIds) {
		this.deviceIds = deviceIds;
	}

	public Integer getMinTemperature() {
		return minTemperature;
	}

	public void setMinTemperature(Integer minTemperature) {
		this.minTemperature = minTemperature;
	}

	public Integer getMaxTemperature() {
		return maxTemperature;
	}

	public void setMaxTemperature(Integer maxTemperature) {
		this.maxTemperature = maxTemperature;
	}

	public Integer getMinHumidity() {
		return minHumidity;
	}

	public void setMinHumidity(Integer minHumidity) {
		this.minHumidity = minHumidity;
	}

	public Integer getMaxHumidity() {
		return maxHumidity;
	}

	public void setMaxHumidity(Integer maxHumidity) {
		this.maxHumidity = maxHumidity;
	}

}
