package net.atos.iot.util;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PushNotificationUtil {

	private static final Logger LOGGER = Logger.getLogger(PushNotificationUtil.class);

	@Value("${pushNotificationServerUrl}")
	private String pushNotificationServerUrl;

	@Value("${isProxyRequiredForPushNotification}")
	private boolean isProxyRequiredForPushNotification;

	@Value("${httpProxyHost}")
	private String proxyHostForPushNotification;

	@Value("${httpProxyPort}")
	private Integer proxyPortForPushNotification;

	@Value("${apiKeyForPushNotification}")
	private String apiKeyForPushNotification;

	@Value("${pushNotificationJsonMessageFormat}")
	private String pushNotificationJsonMessageFormat;

	@Value("${isPushNotificationEnabled}")
	private boolean isPushNotificationEnabled;

	public void sendPushNotification(Integer tenantId, String notificationMessage) {

		if (isPushNotificationEnabled) {
			if (tenantId != null && notificationMessage != null && !notificationMessage.isEmpty()) {
				// LOGGER.info("tenantId for pushNotification " + tenantId
				// + " and notification Message " + notificationMessage);
				try {
					String jsonResponse;
					HttpURLConnection con = null;
					URL url = new URL(pushNotificationServerUrl);

					if (isProxyRequiredForPushNotification) {
						Proxy proxy = new Proxy(Proxy.Type.HTTP,
								new InetSocketAddress(proxyHostForPushNotification, proxyPortForPushNotification));

						con = (HttpURLConnection) url.openConnection(proxy);
					} else {
						con = (HttpURLConnection) url.openConnection();
					}
					if (con != null) {
						con.setUseCaches(false);
						con.setDoOutput(true);
						con.setDoInput(true);
						con.setRequestProperty(IotConstants.CONTENT_TYPE, IotConstants.APPLICATION_JSON_CHARSET);
						con.setRequestProperty(IotConstants.AUTHORIZATION, apiKeyForPushNotification);
						con.setRequestMethod(IotConstants.POST);
						String strJsonBody = pushNotificationJsonMessageFormat;
						strJsonBody = strJsonBody.replace("#notificationMessage#", notificationMessage)
								.replace("#tenantId#", tenantId.toString());
						byte[] sendBytes = strJsonBody.getBytes(IotConstants.UTF_8);
						con.setFixedLengthStreamingMode(sendBytes.length);
						OutputStream outputStream = con.getOutputStream();
						outputStream.write(sendBytes);
						int httpResponse = con.getResponseCode();
						if (httpResponse >= HttpURLConnection.HTTP_OK
								&& httpResponse < HttpURLConnection.HTTP_BAD_REQUEST) {
							Scanner scanner = new Scanner(con.getInputStream(), IotConstants.UTF_8);
							jsonResponse = scanner.useDelimiter("\\A").hasNext() ? scanner.next() : "";
							scanner.close();
						} else {
							Scanner scanner = new Scanner(con.getErrorStream(), IotConstants.UTF_8);
							jsonResponse = scanner.useDelimiter("\\A").hasNext() ? scanner.next() : "";
							scanner.close();
						}
					}
				} catch (Exception e) {
					LOGGER.error(IotConstants.Exception, e);
				}
			}
		}
	}
}
