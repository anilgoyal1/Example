package net.atos.iot.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class DeviceMasterDTO implements Serializable {

	/**
	 * Serial Version Id
	 */
	private static final long serialVersionUID = 5728804968451043489L;

	private String deviceId;

	private TenantDTO tenant;

	private String tenantName;

	private String serviceName;

	private String applianceId;

	private String serialNumber;

	private String deviceType;

	private String deviceBaseLoc;

	private String deviceDesc;

	private boolean isActive;

	private String createdBy;

	private Date createdDate;

	private String modifiedBy;

	private Date modifiedDate;

	private String serverUrl;

	private Integer serverPort;

	private String communicationDetails;

	private long pushFrequency;

	private long pullFrequency;

	private String sensorType;

	private DeviceStatusMasterDTO deviceStatusMaster;

	private Double deviceLocationLongitude;

	private Double deviceLocationLatitude;

	private Set<RuleConfigDTO> ruleConfigs = new HashSet<RuleConfigDTO>(0);
	
	private boolean isSimulatedDevice;

	public boolean isSimulatedDevice() {
		return isSimulatedDevice;
	}

	public void setSimulatedDevice(boolean isSimulatedDevice) {
		this.isSimulatedDevice = isSimulatedDevice;
	}

	public Set<RuleConfigDTO> getRuleConfigs() {
		return ruleConfigs;
	}

	public void setRuleConfigs(Set<RuleConfigDTO> ruleConfigs) {
		this.ruleConfigs = ruleConfigs;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public TenantDTO getTenant() {
		return tenant;
	}

	public void setTenant(TenantDTO tenant) {
		this.tenant = tenant;
	}

	public String getTenantName() {
		return tenantName;
	}

	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getApplianceId() {
		return applianceId;
	}

	public void setApplianceId(String applianceId) {
		this.applianceId = applianceId;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceBaseLoc() {
		return deviceBaseLoc;
	}

	public void setDeviceBaseLoc(String deviceBaseLoc) {
		this.deviceBaseLoc = deviceBaseLoc;
	}

	public String getDeviceDesc() {
		return deviceDesc;
	}

	public void setDeviceDesc(String deviceDesc) {
		this.deviceDesc = deviceDesc;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getServerUrl() {
		return serverUrl;
	}

	public void setServerUrl(String serverUrl) {
		this.serverUrl = serverUrl;
	}

	public Integer getServerPort() {
		return serverPort;
	}

	public void setServerPort(Integer serverPort) {
		this.serverPort = serverPort;
	}

	public String getCommunicationDetails() {
		return communicationDetails;
	}

	public void setCommunicationDetails(String communicationDetails) {
		this.communicationDetails = communicationDetails;
	}

	public long getPushFrequency() {
		return pushFrequency;
	}

	public void setPushFrequency(long pushFrequency) {
		this.pushFrequency = pushFrequency;
	}

	public long getPullFrequency() {
		return pullFrequency;
	}

	public void setPullFrequency(long pullFrequency) {
		this.pullFrequency = pullFrequency;
	}

	public String getSensorType() {
		return sensorType;
	}

	public void setSensorType(String sensorType) {
		this.sensorType = sensorType;
	}

	public DeviceStatusMasterDTO getDeviceStatusMaster() {
		return deviceStatusMaster;
	}

	public void setDeviceStatusMaster(DeviceStatusMasterDTO deviceStatusMaster) {
		this.deviceStatusMaster = deviceStatusMaster;
	}

	public Double getDeviceLocationLongitude() {
		return deviceLocationLongitude;
	}

	public void setDeviceLocationLongitude(Double deviceLocationLongitude) {
		this.deviceLocationLongitude = deviceLocationLongitude;
	}

	public Double getDeviceLocationLatitude() {
		return deviceLocationLatitude;
	}

	public void setDeviceLocationLatitude(Double deviceLocationLatitude) {
		this.deviceLocationLatitude = deviceLocationLatitude;
	}

}
