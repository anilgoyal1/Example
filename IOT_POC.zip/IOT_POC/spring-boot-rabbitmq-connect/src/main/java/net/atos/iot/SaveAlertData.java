package net.atos.iot;

import java.util.Date;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import net.atos.iot.entity.AlertData;
import net.atos.iot.repository.AlertDataRepository;
import net.atos.iot.service.AlertDataService;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.TenantService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.IotConstants;

@Component
public class SaveAlertData {

	private static final Logger LOGGER = Logger.getLogger(SaveAlertData.class);

	@Value("${jsonDeviceId}")
	private String jsonDeviceId;

	@Value("${jsonTemperature}")
	private String jsonTemperature;

	@Value("${jsonHumidity}")
	private String jsonHumidity;

	@Value("${jsonSimulated}")
	private String jsonSimulated;

	@Value("${jsonReceivedDate}")
	private String jsonReceivedTime;

	@Value("${jsonLongitude}")
	private String jsonLongitude;

	@Value("${jsonLatitude}")
	private String jsonLatitude;

	@Value("${jsonSpeed}")
	private String jsonSpeed;

	@Value("${jsonHeading}")
	private String jsonHeading;

	@Value("${jsonState}")
	private String jsonState;

	@Value("${jsonDescription}")
	private String jsonDescription;

	@Value("${jsonLevel}")
	private String jsonLevel;

	@Value("${jsonAlertType}")
	private String jsonAlertType;

	@Value("${businessAlerts}")
	private String businessAlerts;

	@Value("${technicalAlerts}")
	private String technicalAlerts;

	@Value("${alertDataQueueName}")
	private String alertDataQueueName;

	@Value("${alertDataRoutingKey}")
	private String alertDataRoutingKey;

	@Autowired
	private AlertDataRepository alertDataDao;

	@Autowired
	private AlertDataService alertDataService;

	@Autowired
	private CreateTicket createTicket;

	@Autowired
	private DeviceMasterService deviceMasterServiceImpl;

	@Autowired
	private TenantService tenantServiceImpl;

	public void saveAlertData(String queueMessage) {
		if (queueMessage != null && !queueMessage.isEmpty()) {
			if (queueMessage.startsWith("{")) {
				createAndSaveAlertDataEntity(queueMessage);
			} else if (queueMessage.startsWith("[")) {
				JSONArray jsonArray = new JSONArray(queueMessage);
				JSONObject jsonOBj = null;
				for (int i = 0; i < jsonArray.length(); i++) {
					jsonOBj = new JSONObject();
					jsonOBj = jsonArray.getJSONObject(i);
					createAndSaveAlertDataEntity(jsonOBj.toString());
				}
			}

		}
	}

	private void createAndSaveAlertDataEntity(String data) {

		if (data != null && !data.isEmpty()) {
			try {
				JSONObject jsonOBj = new JSONObject(data);
				if (jsonOBj != null) {
					AlertData alertData = new AlertData();
					if (jsonOBj.has(jsonDeviceId)) {
						alertData.setDeviceId(jsonOBj.get(jsonDeviceId).toString());
					}
					if (jsonOBj.has(jsonSimulated)) {
						alertData.setSimulated(jsonOBj.get(jsonSimulated).toString());
					}
					if (jsonOBj.has(jsonTemperature)) {
						alertData.setTemperature(jsonOBj.getDouble(jsonTemperature));
					}
					if (jsonOBj.has(jsonHumidity)) {
						alertData.setHumidity(jsonOBj.getDouble(jsonHumidity));
					}

					if (jsonOBj.has(jsonLatitude)) {
						alertData.setLatitude(Double.parseDouble(jsonOBj.get(jsonLatitude).toString()));
					}
					if (jsonOBj.has(jsonLongitude)) {
						alertData.setLongitude(Double.parseDouble(jsonOBj.get(jsonLongitude).toString()));
					}
					if (jsonOBj.has(jsonSpeed) && !jsonOBj.get(jsonSpeed).toString().isEmpty()) {
						alertData.setSpeed(Double.parseDouble(jsonOBj.get(jsonSpeed).toString()));
					}

					if (jsonOBj.has(jsonHeading) && !jsonOBj.get(jsonHeading).toString().isEmpty()) {
						alertData.setHeading(Double.parseDouble(jsonOBj.get(jsonHeading).toString()));
					}

					if (jsonOBj.has(jsonState)) {
						alertData.setState(jsonOBj.getString(jsonState));
					}
					try {
						if (jsonOBj.has(jsonReceivedTime)) {
							alertData.setReceivedTime(
									DateUtil.convertISOStringToLocalDate((jsonOBj.getString(jsonReceivedTime))));
						}
					} catch (Exception e) {
						LOGGER.error("unparsable date " + jsonOBj.getString(jsonReceivedTime));
					}

					try {
						if (jsonOBj.has("LastDataReceivedTime")) {
							alertData.setReceivedTime(
									DateUtil.convertISOStringToLocalDate((jsonOBj.getString("LastDataReceivedTime"))));
						}
					} catch (Exception e) {
						LOGGER.error("unparsable date " + jsonOBj.getString("LastDataReceivedTime"));
					}
					if (jsonOBj.has(jsonLevel)) {
						alertData.setLevel(jsonOBj.getString(jsonLevel));
					}
					if (jsonOBj.has(jsonDescription)) {
						alertData.setDescription(jsonOBj.getString(jsonDescription));
					}

					if (jsonOBj.has(jsonAlertType)) {
						alertData.setAlertType(jsonOBj.getString(jsonAlertType));
						System.out.println("Alert Type in save alert method" + jsonOBj.getString(jsonAlertType));
					}

					if ((alertData.getAlertType() == null || alertData.getAlertType().isEmpty())) {
						alertData.setAlertType("TAMPERING_ALERT");
					}
					alertData.setCreatedDate(new Date());
					if (alertData.getDeviceId() != null) {
						if (alertData != null && alertData.getAlertType().isEmpty()) {
							alertData.setAlertType("other");
						}
						alertData = alertDataDao.saveAndFlush(alertData);
						alertDataService.sendAlertDataNotification(
								tenantServiceImpl.getTenantIdByDeviceId(alertData.getDeviceId()),
								alertData.getAlertType() + " Received For " + alertData.getDeviceId());
						LOGGER.info("Alert Data saved");
						createTicket(jsonOBj.toString(), alertData);

					}
				}

			} catch (Exception e) {
				LOGGER.error(IotConstants.Exception, e);
			}
		}
	}

	private void createTicket(String data, AlertData alertData) {
		String strTicketType = null;
		String alertType = null;
		System.out.println("Alert Type in createTicket calling method" + alertData.getAlertType());
		if (alertData != null) {
			strTicketType = alertData.getAlertType();
			System.out.println("technicalAlerts type " + technicalAlerts.toString());
			if (technicalAlerts.contains(strTicketType)) {
				alertType = IotConstants.technicalAlert;
			} else {
				alertType = IotConstants.businessAlert;
			}
			try {

				createTicket.craeteTicket(data, alertType, strTicketType, alertData.getDeviceId());
			} catch (Exception e) {
				LOGGER.error(IotConstants.Exception, e);

			}
		}
	}
}
