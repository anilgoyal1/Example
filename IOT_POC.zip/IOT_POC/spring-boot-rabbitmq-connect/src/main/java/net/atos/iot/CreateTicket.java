package net.atos.iot;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import net.atos.iot.entity.DeviceMaster;
import net.atos.iot.entity.Tenant;
import net.atos.iot.entity.Ticket;
import net.atos.iot.repository.DeviceMasterRepository;
import net.atos.iot.repository.DeviceStatusMasterRepository;
import net.atos.iot.repository.RoleRepository;
import net.atos.iot.repository.TicketRepository;
import net.atos.iot.repository.UserDetailsRepository;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.RoleService;
import net.atos.iot.service.TenantService;
import net.atos.iot.service.TicketService;
import net.atos.iot.util.IotConstants;

@Component
public class CreateTicket {

	private static final Logger LOGGER = Logger.getLogger(CreateTicket.class);

	@Autowired
	private TicketRepository ticketDao;

	@Value("${jsonLongitude}")
	private String jsonLongitude;

	@Value("${deviceInspectionStatus}")
	private String deviceInspectionStatus;

	@Value("${jsonLatitude}")
	private String jsonLatitude;

	@Value("${jsonSpeed}")
	private String jsonSpeed;

	@Value("${jsonHeading}")
	private String jsonHeading;

	@Value("${jsonState}")
	private String jsonState;

	@Value("${jsonDescription}")
	private String jsonDescription;

	@Value("${jsonLevel}")
	private String jsonLevel;

	@Value("${jsonDeviceId}")
	private String jsonDeviceId;

	@Value("${jsonTemperature}")
	private String jsonTemperature;

	@Value("${jsonHumidity}")
	private String jsonHumidity;

	@Value("${jsonSimulated}")
	private String jsonSimulated;

	@Value("${jsonReceivedDate}")
	private String jsonReceivedTime;

	@Value("${jsonLastDataReceivedTime}")
	private String jsonLastDataReceivedTime;

	@Autowired
	private DeviceMasterRepository deviceMasterDao;

	@Autowired
	private UserDetailsRepository userDetailsDao;

	@Autowired
	private DeviceStatusMasterRepository deviceStatusMasterDao;

	@Autowired
	private TicketService ticketServiceImpl;

	@Autowired
	private CreateTicket createTicket;

	@Autowired
	private RoleRepository userRole;

	@Autowired
	private EntityManagerFactory emf;

	@Autowired
	private DeviceMasterService deviceMasterService;

	@Autowired
	private RoleService roleService;;

	@Autowired
	private TenantService tenantServiceImpl;

	public void craeteTicket(String data, String alertType, String strTicketType, String deviceId) throws Exception {
		System.out.println("Alert Type in craeteTicket called method" + alertType);
		Ticket ticket = new Ticket();
		String ticketAssginedUser = null;
		String[] statusToIgnore = { IotConstants.ticketTypeClose, IotConstants.ticketTypeResolved };
		List<String> closeAndResolvedTicketTypeList = Arrays.asList(statusToIgnore);
		try {
			JSONObject jsonOBj = new JSONObject(data);
			if (jsonOBj.has(jsonDeviceId)) {
				ticket.setDeviceId(jsonOBj.get(jsonDeviceId).toString());
				List<Ticket> ticketListByStatusAndType = ticketDao
						.findNotClosedTicketByTicketTypeAndTicketStatusAndDeviceId(closeAndResolvedTicketTypeList,
								ticket.getDeviceId(), alertType, strTicketType);
				if (ticketListByStatusAndType != null) {
					System.out.println("ticketListByStatusAndType size" + ticketListByStatusAndType.size());
				}
				if (ticketListByStatusAndType == null || ticketListByStatusAndType.isEmpty()) {
					ticket.setAlertType(alertType);
					DeviceMaster deviceMst = deviceMasterDao.getDeviceByDeviceId(deviceId);
					if (deviceMst != null && deviceMst.getTenant() != null) {
						Tenant tenant = deviceMst.getTenant();
						if (tenant != null && tenant.getTenantId() != null) {
							ticketAssginedUser = getUserIdByTenantId(tenant.getTenantId());
							ticket.setTicketStatus(IotConstants.ticketTypeAssigned);
							Calendar currentDate = Calendar.getInstance();
							ticket.setCreateDate(currentDate.getTime());
							ticket.setAssignedTo(ticketAssginedUser);
							if (alertType.equalsIgnoreCase(IotConstants.technicalAlert)) {
								System.out.println("it is a technicle alert");
								ticket.setLevel(IotConstants.ticketLevelHigh);
								currentDate.add(Calendar.HOUR_OF_DAY, 24);
								ticket.setSlaTimeFrame(currentDate.getTime());
							} else {
								System.out.println("it is a business alert");
								ticket.setLevel(IotConstants.ticketLevelMedium);
								currentDate.add(Calendar.HOUR_OF_DAY, 48);
								ticket.setSlaTimeFrame(currentDate.getTime());
							}

							ticket.setAssignedDate(new Date());
							if (jsonOBj.has(jsonDescription)) {
								ticket.setTicketDescription(jsonOBj.get(jsonDescription).toString());
							}
							if (jsonOBj.has(jsonHumidity)) {
								ticket.setHumidity(jsonOBj.getDouble(jsonHumidity));
							}
							if (jsonOBj.has(jsonTemperature)) {
								ticket.setTemperature(jsonOBj.getDouble(jsonTemperature));
							}
							if (jsonOBj.has(jsonLatitude)) {
								ticket.setLatitude(Double.parseDouble(jsonOBj.get(jsonLatitude).toString()));
							}
							if (jsonOBj.has(jsonLongitude)) {
								ticket.setLongitude(Double.parseDouble(jsonOBj.get(jsonLongitude).toString()));
							}
							if (jsonOBj.has(jsonSpeed)) {
								ticket.setSpeed(jsonOBj.getDouble(jsonSpeed));
							}
							if (jsonOBj.has(IotConstants.ticketType)
									&& !jsonOBj.getString(IotConstants.ticketType).isEmpty()) {
								ticket.setTicketType(jsonOBj.getString(IotConstants.ticketType));
							}
							ticket.setCreatedBy(IotConstants.systemUser);
							ticket = ticketDao.saveAndFlush(ticket);
							LOGGER.info("ticket created.");
							Integer tenentId = tenantServiceImpl.getTenantIdByDeviceId(deviceId);
							if (tenentId != null) {
								ticketServiceImpl.sendTicketStatusChangedNotification(tenentId,
										" ticket No ".concat(ticket.getTicketId().toString())
												.concat(" created for device ").concat(deviceId));
							}
							deviceMasterService.changeDeviceStatus(jsonOBj.get(jsonDeviceId).toString(),
									deviceInspectionStatus);
						}
					}
				}

			}

		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
	}

	public String getUserIdByTenantId(Integer tenantId) {
		String userName = null;
		EntityManager entityManager = null;
		try {
			if (tenantId != null && tenantId > 0) {
				StringBuilder sql = new StringBuilder();
				sql.append("select user_id from user_details where role_id=:roleId And tenant_tenant_id=:tenantId");
				entityManager = emf.createEntityManager();
				Integer roleId = roleService.getRoleIdByRoleName(IotConstants.FIELD_ENGINEER);
				Query query = entityManager.createNativeQuery(sql.toString());
				query.setParameter("roleId", roleId);
				query.setParameter("tenantId", tenantId);
				List<String> userIdList = query.getResultList();
				if (userIdList != null && !userIdList.isEmpty()) {
					userName = userIdList.get(0);
				}
			}
		} catch (Exception e) {
			LOGGER.info("Exception ", e);
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}
		return userName;
	}

}
