package net.atos.iot;

import java.text.SimpleDateFormat;
import java.util.Date;

import net.atos.iot.entity.AlertData;
import net.atos.iot.entity.GPSSensorData;
import net.atos.iot.entity.SensorData;
import net.atos.iot.repository.AlertDataRepository;
import net.atos.iot.repository.GPSSensorDataRepository;
import net.atos.iot.repository.SensorDataRepository;
import net.atos.iot.service.AlertDataService;
import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.service.TenantService;
import net.atos.iot.util.DateUtil;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public class SensorDataListener {

	private static final Logger LOGGER = Logger
			.getLogger(SensorDataListener.class);

	@Value("${jsonLongitude}")
	private String jsonLongitude;

	@Value("${deviceInspectionStatus}")
	private String deviceInspectionStatus;

	@Value("${jsonLatitude}")
	private String jsonLatitude;

	@Value("${jsonSpeed}")
	private String jsonSpeed;

	@Value("${jsonHeading}")
	private String jsonHeading;

	@Value("${jsonState}")
	private String jsonState;

	@Value("${jsonDescription}")
	private String jsonDescription;

	@Value("${jsonLevel}")
	private String jsonLevel;

	@Value("${jsonDeviceId}")
	private String jsonDeviceId;

	@Value("${jsonTemperature}")
	private String jsonTemperature;

	@Value("${jsonHumidity}")
	private String jsonHumidity;

	@Value("${jsonSimulated}")
	private String jsonSimulated;

	@Value("${jsonReceivedDate}")
	private String jsonReceivedTime;

	@Value("${sensorDataQueueName}")
	private String sensorDataQueueName;

	@Value("${sensorDataRoutingKey}")
	private String sensorDataRoutingKey;

	@Value("${jsonTripStatus}")
	private String jsonTripStatus;

	@Value("${jsonDriverName}")
	private String jsonDriverName;

	@Value("${jsonLicensePlate}")
	private String jsonLicensePlate;

	@Value("${jsonFuelLevel}")
	private String jsonFuelLevel;

	@Value("${jsonEngineLoad}")
	private String jsonEngineLoad;

	@Value("${jsonShortTermFuel}")
	private String jsonShortTermFuel;

	@Value("${jsonLongTermFuel}")
	private String jsonLongTermFuel;

	@Value("${jsonEngineRPM}")
	private String jsonEngineRPM;

	@Value("${jsonMAFAirFlow}")
	private String jsonMAFAirFlow;

	@Value("${jsonThrottlePosition}")
	private String jsonThrottlePosition;

	@Value("${jsonEngineStartFrom}")
	private String jsonEngineStartFrom;

	@Value("${jsonDistanceTraveledWithLightOn}")
	private String jsonDistanceTraveledWithLightOn;

	@Value("${jsonRelThottlePos}")
	private String jsonRelThottlePos;

	@Value("${jsonAmbientAirTemp}")
	private String jsonAmbientAirTemp;

	@Value("${jsonEngineFuelRate}")
	private String jsonEngineFuelRate;

	@Value("${jsonHDDUsed}")
	private String jsonHDDUsed;

	@Value("${jsonCPUUsed}")
	private String jsonCPUUsed;

	@Value("${jsonRAMUsed}")
	private String jsonRAMUsed;

	@Value("${jsonTripId}")
	private String jsonTripId;

	@Value("${jsonSpeedLimit}")
	private double jsonSpeedLimit;

	@Autowired
	private SensorDataRepository sensorDataDao;

	@Autowired
	private GPSSensorDataRepository gpsSensorDataDao;

	// SimpleDateFormat dt = new SimpleDateFormat(IotConstants.ISODATE);

	static SimpleDateFormat dt1 = new SimpleDateFormat(
			"E MMM dd yyyy HH:mm:ss 'GMT+0000' 'Z'");

	@Autowired
	private CreateTicket createTicket;

	@Autowired
	private AlertDataRepository alertDataDao;

	@Autowired
	private DeviceMasterService deviceMasterServiceImpl;

	@Autowired
	private TenantService tenantServiceImpl;

	@Autowired
	private AlertDataService alertDataService;

	public void receiveMessage(byte[] message) {
		String queueMessage = new String(message);
		String deviceStatus = null;
		try {
			if (queueMessage != null && queueMessage.length() > 0) {
				JSONObject json = new JSONObject(queueMessage);
				LOGGER.info("Sensor Data Message " + queueMessage);
				if (json != null && json.has(jsonDeviceId)) {
					deviceStatus = deviceMasterServiceImpl.getDeviceStatus(json
							.get(jsonDeviceId).toString().trim());
					if (deviceStatus == null
							|| (deviceStatus
									.equalsIgnoreCase(IotConstants.NewDeviceStatus)
									|| deviceStatus
											.equalsIgnoreCase(IotConstants.deadDeviceStatus) || deviceStatus
										.equalsIgnoreCase(IotConstants.RejectedDeviceStatus))) {

					} else {
						saveSensorData(queueMessage.toString(), deviceStatus);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception ", e);

		}
	}

	public void saveSensorData(String data, String deviceStatus)
			throws Exception {
		try {
			if (data.contains(jsonTemperature) && data.contains(jsonHumidity)) {
				JSONObject jsonOBj = new JSONObject(data.toString());
				SensorData sensorData = new SensorData();
				if (jsonOBj.has(jsonDeviceId)) {
					sensorData
							.setDeviceId(jsonOBj.get(jsonDeviceId).toString());
				}
				if (jsonOBj.has(jsonSimulated)) {
					sensorData.setSimulated(jsonOBj.get(jsonSimulated)
							.toString());
				}
				if (jsonOBj.has(jsonHumidity)) {
					sensorData.setHumidity(jsonOBj.getDouble(jsonHumidity));
				}
				if (jsonOBj.has(jsonTemperature)) {
					sensorData
							.setTemprature(jsonOBj.getDouble(jsonTemperature));
				}
				if (jsonOBj.has(jsonReceivedTime)) {
					sensorData.setReceivedTime(DateUtil
							.convertISOStringToLocalDate(jsonOBj
									.getString(jsonReceivedTime)));
				}

				if (jsonOBj.has(jsonHDDUsed)) {
					sensorData
							.setHardDiskUsed((jsonOBj.getDouble(jsonHDDUsed)));
				}

				if (jsonOBj.has(jsonCPUUsed)) {
					sensorData.setCpuUsed(jsonOBj.getDouble(jsonCPUUsed));
				}

				if (jsonOBj.has(jsonRAMUsed)) {
					sensorData.setRamUsed(jsonOBj.getDouble(jsonRAMUsed));
				}

				if (sensorData.getDeviceId() != null) {
					sensorData.setCreatedDate(new Date());
					sensorDataDao.saveAndFlush(sensorData);
					if (deviceStatus
							.equalsIgnoreCase(IotConstants.PROVISIONED_DEVICE_STATUS)) {
						deviceMasterServiceImpl.changeDeviceStatus(
								jsonOBj.get(jsonDeviceId).toString(),
								IotConstants.liveDeviceStatus);
					}
					LOGGER.info(IotConstants.SENSOR_DATA_SAVED);
				}
			} else {
				LOGGER.info("inside gps sensor data block");
				if (data.trim().startsWith("{")) {
					this.saveJsonGpsSensorData(data, deviceStatus);
				} else if (data.trim().startsWith("[")) {
					this.saveArrayJsonGpsSensorData(data, deviceStatus);
				}

			}
		} catch (Exception e) {
			LOGGER.error("Exception ", e);

		}
	}

	private void saveJsonGpsSensorData(String data, String deviceStastus) {
		try {
			LOGGER.info(IotConstants.GPS_SENSOR_DATA);
			JSONObject jsonOBj = new JSONObject(data);
			GPSSensorData gpsSensor = gpsJsonDataToEntity(jsonOBj,
					deviceStastus);
			if (gpsSensor != null) {
				this.gpsSaveData(gpsSensor, deviceStastus);
				LOGGER.info(IotConstants.GPS_SENSOR_DATA_SAVED);
			}

		} catch (Exception e) {
			LOGGER.error("Error", e);
		}

	}

	private void saveArrayJsonGpsSensorData(String data, String deviceStastus) {
		LOGGER.info(IotConstants.GPS_SENSOR_ARRAY_DATA);
		try {
			JSONArray jsonArray = new JSONArray(data);
			JSONObject jsonOBj = null;
			for (int i = 0; i < jsonArray.length(); i++) {
				jsonOBj = new JSONObject();
				jsonOBj = jsonArray.getJSONObject(i);
				GPSSensorData gpsSensor = gpsJsonDataToEntity(jsonOBj,
						deviceStastus);
				if (gpsSensor != null) {
					this.gpsSaveData(gpsSensor, deviceStastus);
				}
			}
			LOGGER.info(IotConstants.GPS_SENSOR_ARRAY_DATA_SAVED);
		} catch (Exception e) {
			LOGGER.error("Exception", e);
		}
	}

	private GPSSensorData gpsJsonDataToEntity(JSONObject jsonOBj,
			String deviceStatus) {
		GPSSensorData gpsSensor = new GPSSensorData();
		try {
			LOGGER.info("GPS Sensor Data " + jsonOBj);
			if (jsonOBj.has(jsonDeviceId)) {
				gpsSensor.setDeviceId(jsonOBj.get(jsonDeviceId).toString());
			}
			if (jsonOBj.has(jsonSimulated)) {
				gpsSensor.setSimulated(jsonOBj.get(jsonSimulated).toString());
			}

			if (jsonOBj.has(jsonReceivedTime)) {
				try {
					if (jsonOBj.getString(jsonReceivedTime).contains("-")) {
						gpsSensor.setReceivedTime(DateUtil
								.convertISOStringToLocalDate((jsonOBj
										.getString(jsonReceivedTime))));
					} else {
						gpsSensor.setReceivedTime(dt1.parse(jsonOBj
								.getString(jsonReceivedTime)));
					}
				} catch (Exception e) {
					LOGGER.error("unparsable date"
							+ jsonOBj.getString(jsonReceivedTime));
				}
			}
			if (jsonOBj.has(jsonLatitude)) {
				gpsSensor.setLatitude(Double.parseDouble(jsonOBj.get(
						jsonLatitude).toString()));
			}
			if (jsonOBj.has(jsonLongitude)) {
				gpsSensor.setLongitude(Double.parseDouble(jsonOBj.get(
						jsonLongitude).toString()));
			}
			if (jsonOBj.has(jsonSpeed)) {
				gpsSensor.setSpeed(jsonOBj.getDouble(jsonSpeed));
				// temporary
				if (jsonOBj.getDouble(jsonSpeed) > jsonSpeedLimit
						&& !deviceStatus
								.equalsIgnoreCase(IotConstants.PROVISIONED_DEVICE_STATUS)) {
					saveDataForGPSAlert(jsonOBj);
					alertDataService.sendAlertDataNotification(
							tenantServiceImpl.getTenantIdByDeviceId(jsonOBj
									.get(jsonDeviceId).toString()),
							" Speed Limits Reached To "
									+ jsonOBj.getDouble(jsonSpeed) + " for "
									+ jsonOBj.get(jsonDeviceId).toString());

				}
			}
			if (jsonOBj.has(jsonHeading)) {
				gpsSensor.setHeading(jsonOBj.getDouble(jsonHeading));
			}
			if (jsonOBj.has(jsonState)) {
				gpsSensor.setState(jsonOBj.getString(jsonState));
			}
			if (jsonOBj.has(jsonDescription)) {
				gpsSensor.setDescription(jsonOBj.getString(jsonDescription));
			}
			if (jsonOBj.has(IotConstants.ticketType)) {
				gpsSensor.setAlertType(jsonOBj
						.getString(IotConstants.ticketType));
			}
			if (jsonOBj.has(jsonTripStatus)) {
				gpsSensor.setTripStatus(jsonOBj.getString(jsonTripStatus));
			}
			if (jsonOBj.has(jsonDriverName)) {
				gpsSensor.setDriverName(jsonOBj.getString(jsonDriverName));
			}

			if (jsonOBj.has(jsonLicensePlate)) {
				gpsSensor.setLicensePlate(jsonOBj.getString(jsonLicensePlate));
			}

			if (jsonOBj.has(jsonEngineLoad)) {
				gpsSensor
						.setEngineLoad((jsonOBj.getDouble(jsonEngineLoad) + 0.0));
			}

			if (jsonOBj.has(jsonShortTermFuel)) {
				gpsSensor.setShortTermFuel((jsonOBj
						.getDouble(jsonShortTermFuel)));
			}

			if (jsonOBj.has(jsonLongTermFuel)) {
				gpsSensor
						.setLongTermFuel((jsonOBj.getDouble(jsonLongTermFuel)));
			}

			if (jsonOBj.has(jsonEngineRPM)) {
				gpsSensor.setEngineRPM((jsonOBj.getDouble(jsonEngineRPM)));
			}

			if (jsonOBj.has(jsonMAFAirFlow)) {
				gpsSensor.setmAFAirFlow((jsonOBj.getDouble(jsonMAFAirFlow)));
			}

			if (jsonOBj.has(jsonThrottlePosition)) {
				gpsSensor.setThrottlePosition((jsonOBj
						.getDouble(jsonThrottlePosition)));
			}

			if (jsonOBj.has(jsonEngineStartFrom)) {
				gpsSensor.setEngineStartFrom((jsonOBj
						.getDouble(jsonEngineStartFrom)));
			}
			if (jsonOBj.has(jsonDistanceTraveledWithLightOn)) {
				gpsSensor.setDistanceTraveledWithLightOn((jsonOBj
						.getDouble(jsonDistanceTraveledWithLightOn)));
			}

			if (jsonOBj.has(jsonRelThottlePos)) {
				gpsSensor.setRelThottlePos((jsonOBj
						.getDouble(jsonRelThottlePos)));
			}

			if (jsonOBj.has(jsonAmbientAirTemp)) {
				gpsSensor.setAmbientAirTemp((jsonOBj
						.getDouble(jsonAmbientAirTemp)));
			}
			if (jsonOBj.has(jsonEngineFuelRate)) {
				gpsSensor.setEngineFuelRate((jsonOBj
						.getDouble(jsonEngineFuelRate)));
			}
			if (jsonOBj.has(jsonFuelLevel)) {
				gpsSensor.setFuelLevel((jsonOBj.get(jsonFuelLevel)).toString());
			}

			if (jsonOBj.has(jsonTripId)) {
				gpsSensor.setTripId((jsonOBj.getLong(jsonTripId)));
			}

		} catch (Exception e) {
			LOGGER.error("Exception ", e);
		}
		return gpsSensor;
	}

	private void gpsSaveData(GPSSensorData gpsSensor, String deviceStatus) {
		try {
			if (gpsSensor.getDeviceId() != null) {
				gpsSensor.setCreatedDate(new Date());
				gpsSensorDataDao.saveAndFlush(gpsSensor);
				if (deviceStatus
						.equalsIgnoreCase(IotConstants.PROVISIONED_DEVICE_STATUS)) {
					deviceMasterServiceImpl.changeDeviceStatus(
							gpsSensor.getDeviceId(),
							IotConstants.liveDeviceStatus);
				}

			}
		} catch (Exception e) {
			LOGGER.error("Exception", e);
		}

	}

	// this method is temprary for demo purpose later remove it
	private void saveDataForGPSAlert(JSONObject jsonOBj) {
		if (jsonOBj != null && jsonOBj.has(jsonDeviceId)) {
			AlertData alertData = new AlertData();
			if (jsonOBj.has(jsonDeviceId)) {
				alertData.setDeviceId(jsonOBj.get(jsonDeviceId).toString());
			}
			if (jsonOBj.has(jsonSimulated)) {
				alertData.setSimulated(jsonOBj.get(jsonSimulated).toString());
			}
			if (jsonOBj.has(jsonTemperature)) {
				alertData.setTemperature(jsonOBj.getDouble(jsonTemperature));
			}
			if (jsonOBj.has(jsonHumidity)) {
				alertData.setHumidity(jsonOBj.getDouble(jsonHumidity));
			}
			if (jsonOBj.has(jsonLatitude)) {
				alertData.setLatitude(Double.parseDouble(jsonOBj.get(
						jsonLatitude).toString()));
			}
			if (jsonOBj.has(jsonLongitude)) {
				alertData.setLongitude(Double.parseDouble(jsonOBj.get(
						jsonLongitude).toString()));
			}
			if (jsonOBj.has(jsonSpeed)
					&& !jsonOBj.get(jsonSpeed).toString().isEmpty()) {
				alertData.setSpeed(Double.parseDouble(jsonOBj.get(jsonSpeed)
						.toString()));
			}

			if (jsonOBj.has(jsonHeading)
					&& !jsonOBj.get(jsonHeading).toString().isEmpty()) {
				alertData.setHeading(Double.parseDouble(jsonOBj
						.get(jsonHeading).toString()));
			}

			if (jsonOBj.has(jsonState)) {
				alertData.setState(jsonOBj.getString(jsonState));
			}
			try {
				if (jsonOBj.has(jsonReceivedTime)) {
					alertData.setReceivedTime(DateUtil
							.convertISOStringToLocalDate((jsonOBj
									.getString(jsonReceivedTime))));
				}
			} catch (Exception e) {
				LOGGER.error("unparsable date "
						+ jsonOBj.getString(jsonReceivedTime));
			}

			try {
				if (jsonOBj.has("LastDataReceivedTime")) {
					alertData.setReceivedTime(DateUtil
							.convertISOStringToLocalDate((jsonOBj
									.getString("LastDataReceivedTime"))));
				}
			} catch (Exception e) {
				LOGGER.error("unparsable date "
						+ jsonOBj.getString("LastDataReceivedTime"));
			}

			alertData.setLevel("CRITICAL");
			if (jsonOBj.has(jsonDescription)) {
				alertData.setDescription(jsonOBj.getString(jsonDescription));
			}

			alertData.setAlertType(IotConstants.SPEED_VIOLATION);

			alertData.setCreatedDate(new Date());
			if (jsonOBj.has(jsonTripId)) {
				alertData.setTripId((jsonOBj.getInt(jsonTripId)));
			}

			alertData = alertDataDao.saveAndFlush(alertData);
			LOGGER.info("Alert Data saved");

		}
	}

}
