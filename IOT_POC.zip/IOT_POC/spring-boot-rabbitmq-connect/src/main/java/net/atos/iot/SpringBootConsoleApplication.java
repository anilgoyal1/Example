package net.atos.iot;

import org.apache.log4j.Logger;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan("net.atos.iot")
@EnableJpaRepositories("net.atos.iot")
public class SpringBootConsoleApplication implements CommandLineRunner {

	private static final Logger LOGGER = Logger.getLogger(SpringBootConsoleApplication.class);

	@Value("${spring.rabbitmq.host}")
	private String queueHost;

	@Value("${spring.rabbitmq.port}")
	private Integer queuePort;

	@Value("${spring.rabbitmq.username}")
	private String rabbitMQUsername;

	@Value("${spring.rabbitmq.password}")
	private String rabbitMQPassword;

	@Value("${spring.rabbitmq.directExchangeName}")
	private String directExchangeName;

	@Value("${sensorDataQueueName}")
	private String sensorDataQueueName;

	@Value("${alertDataQueueName}")
	private String alertDataQueueName;

	@Value("${technicalAlertQueueName}")
	private String technicalAlertQueueName;

	@Value("${gpsAlertDataQueueName}")
	private String gpsAlertDataQueueName;

	@Value("${gpsAlertDataRoutingKey}")
	private String gpsAlertDataRoutingKey;

	@Value("${sensorDataRoutingKey}")
	private String sensorDataRoutingKey;

	@Value("${alertDataRoutingKey}")
	private String alertDataRoutingKey;

	@Value("${technicalAlertDataRoutingKey}")
	private String technicalAlertDataRoutingKey;

	public static void main(String[] args) throws Exception {

		SpringApplication app = new SpringApplication(SpringBootConsoleApplication.class);
		app.run(args);
	}

	@Bean
	public ConnectionFactory connectionFactory() {

		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(queueHost);
		connectionFactory.setUsername(rabbitMQUsername);
		connectionFactory.setPassword(rabbitMQPassword);
		connectionFactory.setPort(queuePort);
		return connectionFactory;
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Execution started");
	}

	@Bean
	Queue sensorDataQueue() {
		return new Queue(sensorDataQueueName, true);
	}

	@Bean
	Queue alertDataQueue() {
		return new Queue(alertDataQueueName, true);
	}

	@Bean
	Queue technicalAlertDataQueue() {
		return new Queue(technicalAlertQueueName, true);
	}

	@Bean
	DirectExchange exchange() {
		return new DirectExchange(directExchangeName);
	}

	@Bean
	Binding bindingWithSensorDataQueue(@Qualifier("sensorDataQueue") Queue sensorDataQueue, DirectExchange exchange) {
		return BindingBuilder.bind(sensorDataQueue).to(exchange).with(sensorDataRoutingKey);
	}

	@Bean
	Binding bindingWithAlertDataQueue(@Qualifier("alertDataQueue") Queue alertDataQueue, DirectExchange exchange) {
		return BindingBuilder.bind(alertDataQueue).to(exchange).with(alertDataRoutingKey);
	}

	@Bean
	Binding bindingWithTechnicaleDataQueue(@Qualifier("technicalAlertDataQueue") Queue technicalDataQueue,
			DirectExchange exchange) {
		return BindingBuilder.bind(technicalDataQueue).to(exchange).with(technicalAlertDataRoutingKey);
	}

	@Bean
	SimpleMessageListenerContainer sensorDataListenerContainer(ConnectionFactory connectionFactory,
			@Qualifier("sensorDataListenerAdapter") MessageListenerAdapter listenerAdapter) {
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setQueues(sensorDataQueue());
		container.setMessageListener(listenerAdapter);
		return container;
	}

	@Bean
	MessageListenerAdapter sensorDataListenerAdapter(SensorDataListener receiver) {
		return new MessageListenerAdapter(receiver, "receiveMessage");
	}

	@Bean
	SensorDataListener sensorDataListener() {
		return new SensorDataListener();
	}

	@Bean
	SimpleMessageListenerContainer alertDataListenerContainer(ConnectionFactory connectionFactory,
			@Qualifier("alertDataListenerAdapter") MessageListenerAdapter listenerAdapter) {
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setQueues(alertDataQueue());
		container.setMessageListener(listenerAdapter);
		return container;
	}

	@Bean
	MessageListenerAdapter alertDataListenerAdapter(AlertDataListener receiver) {
		return new MessageListenerAdapter(receiver, "receiveMessage");
	}

	@Bean
	AlertDataListener alertDataListner() {
		return new AlertDataListener();
	}

	@Bean
	SimpleMessageListenerContainer technicleAlertDataListenerContainer(ConnectionFactory connectionFactory,
			@Qualifier("technicalAlertDataListenerAdapter") MessageListenerAdapter listenerAdapter) {
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory);
		container.setQueues(technicalAlertDataQueue());
		container.setMessageListener(listenerAdapter);
		return container;
	}

	@Bean
	MessageListenerAdapter technicalAlertDataListenerAdapter(TechnicalAlertDataListener receiver) {
		return new MessageListenerAdapter(receiver, "receiveMessage");
	}

	@Bean
	TechnicalAlertDataListener technicalAlertDataListner() {
		return new TechnicalAlertDataListener();
	}

}