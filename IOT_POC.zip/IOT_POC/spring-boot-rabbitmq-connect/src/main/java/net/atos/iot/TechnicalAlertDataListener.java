package net.atos.iot;

import net.atos.iot.service.DeviceMasterService;
import net.atos.iot.util.IotConstants;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public class TechnicalAlertDataListener {

	private static final Logger LOGGER = Logger
			.getLogger(TechnicalAlertDataListener.class);

	@Autowired
	SaveAlertData saveAlertData;

	@Autowired
	DeviceMasterService deviceMasterServiceImpl;

	@Value("${jsonDeviceId}")
	private String jsonDeviceId;

	public void receiveMessage(byte[] message) {
		try {
			String queueMessage = new String(message);
			String deviceStatus = null;
			JSONObject json = new JSONObject(queueMessage);
			LOGGER.info("Technical Alert Data Message " + queueMessage);
			if (json != null && json.has(jsonDeviceId)) {
				deviceStatus = deviceMasterServiceImpl.getDeviceStatus(json
						.getString(jsonDeviceId));
				if (deviceStatus == null
						|| (deviceStatus
								.equalsIgnoreCase(IotConstants.NewDeviceStatus)
								|| deviceStatus
										.equalsIgnoreCase(IotConstants.PROVISIONED_DEVICE_STATUS)
								|| deviceStatus
										.equalsIgnoreCase(IotConstants.deadDeviceStatus) || deviceStatus
									.equalsIgnoreCase(IotConstants.RejectedDeviceStatus))) {
					// ignore no need to process data
				} else {
					saveAlertData.saveAlertData(queueMessage);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
